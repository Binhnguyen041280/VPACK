# 📦 Tổng hợp mã nguồn Vtrack Frontend

**Tổng cộng:** 0 file `.py`, 35 file `.js`

---

## 📄 File: `tailwind.config.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/tailwind.config.js`

```javascript
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        'blue-custom': '#0066CC',
        'red-custom': '#E32222',
        'gray-custom': '#3F3F3F',
        'yellow-custom': '#FFD700',
      },
    },
  },
  plugins: [],
};
```
## 📄 File: `postcss.config.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/postcss.config.js`

```javascript
module.exports = {
   plugins: {
     tailwindcss: {},
     autoprefixer: {},
   },
 };
```
## 📄 File: `reportWebVitals.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/reportWebVitals.js`

```javascript
const reportWebVitals = onPerfEntry => {
  if (onPerfEntry && onPerfEntry instanceof Function) {
    import('web-vitals').then(({ getCLS, getFID, getFCP, getLCP, getTTFB }) => {
      getCLS(onPerfEntry);
      getFID(onPerfEntry);
      getFCP(onPerfEntry);
      getLCP(onPerfEntry);
      getTTFB(onPerfEntry);
    });
  }
};

export default reportWebVitals;

```
## 📄 File: `Sidebar.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Sidebar.js`

```javascript
import { Play, Search, Settings, User } from "lucide-react";
import Title from "./Title";

const Sidebar = ({ setActiveMenu, activeMenu }) => (
  <div className="w-64 bg-black text-white min-h-screen p-4 flex flex-col font-montserrat">
    <Title text="V_TRACK UI" />
    <ul>
      {[
        { name: "Chương trình", icon: <Play className="mr-2 text-blue-custom" /> },
        { name: "Truy vấn", icon: <Search className="mr-2 text-red-custom" /> },
        { name: "Cấu hình", icon: <Settings className="mr-2 text-gray-custom" /> },
        { name: "Tài khoản", icon: <User className="mr-2 text-yellow-custom" /> },
      ].map((item) => (
        <li
          key={item.name}
          className={`flex items-center p-3 hover:bg-gray-800 cursor-pointer transition duration-300 ${
            activeMenu === item.name ? "bg-gray-800" : ""
          }`}
          onClick={() => setActiveMenu(item.name)}
        >
          {item.icon} {item.name}
        </li>
      ))}
    </ul>
  </div>
);

export default Sidebar;
```
## 📄 File: `index.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/index.js`

```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import "@fontsource/montserrat";
import "react-datepicker/dist/react-datepicker.css";

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

```
## 📄 File: `QueryComponent.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/QueryComponent.js`

```javascript
import { useState, useEffect } from "react";
import SearchModeSelector from "./components/ui/SearchModeSelector";
import FileInputSection from "./components/query/FileInputSection";
import TextInputSection from "./components/query/TextInputSection";
import TimeAndQuerySection from "./components/query/TimeAndQuerySection";
import ResultList from "./components/result/ResultList";
import VideoCutter from "./components/result/VideoCutter"; // Thay CutVideoSection bằng VideoCutter
import ColumnSelectorModal from "./components/query/ColumnSelectorModal";
import api from "./api";

const QueryComponent = () => {
  const [searchType, setSearchType] = useState("Text");
  const [path, setPath] = useState("");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [results, setResults] = useState([]);
  const [selectedVideos, setSelectedVideos] = useState([]);
  const [cutVideos, setCutVideos] = useState([]);
  const [searchString, setSearchString] = useState("");
  const [defaultDays, setDefaultDays] = useState(30);
  const [fileContent, setFileContent] = useState("");
  const [trackingCodes, setTrackingCodes] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [headers, setHeaders] = useState([]);
  const [selectedColumn, setSelectedColumn] = useState("tracking_codes");
  const [history, setHistory] = useState({
    Shopee: "Mã vận đơn",
    Lazada: "Vận đơn",
    Tiktok: "QR mã vận đơn",
    Custom1: "Custom 1",
    Custom2: "Custom 2",
  });
  const [selectedPlatform, setSelectedPlatform] = useState("Shopee");
  const [shopeeLabel, setShopeeLabel] = useState("Shopee");
  const [lazadaLabel, setLazadaLabel] = useState("Lazada");
  const [tiktokLabel, setTiktokLabel] = useState("Tiktok");
  const [customLabel1, setCustomLabel1] = useState("Custom 1");
  const [customLabel2, setCustomLabel2] = useState("Custom 2");
  const [queryCount, setQueryCount] = useState(0);
  const [trackingCodeCount, setTrackingCodeCount] = useState(0);
  const [foundCount, setFoundCount] = useState(0);
  const [isQuerying, setIsQuerying] = useState(false);
  const [selectedCameras, setSelectedCameras] = useState([]);
  const [availableCameras, setAvailableCameras] = useState([]);
  const [hasQueried, setHasQueried] = useState(false);

  useEffect(() => {
    const savedHistory = localStorage.getItem("trackingColumnHistory");
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
    const savedLabels = localStorage.getItem("platformLabels");
    if (savedLabels) {
      const labels = JSON.parse(savedLabels);
      setShopeeLabel(labels.Shopee || "Shopee");
      setLazadaLabel(labels.Lazada || "Lazada");
      setTiktokLabel(labels.Tiktok || "Tiktok");
      setCustomLabel1(labels.Custom1 || "Custom 1");
      setCustomLabel2(labels.Custom2 || "Custom 2");
    }

    const isConfigSet = localStorage.getItem("configSet");
    if (isConfigSet) {
      const fetchCameras = async () => {
        try {
          const response = await api.get("/get-cameras");
          setAvailableCameras(response.data.cameras || []);
          const savedCameras = localStorage.getItem("selectedCameras");
          if (savedCameras) {
            setSelectedCameras(JSON.parse(savedCameras));
          }
        } catch (error) {
          console.error("Error fetching cameras:", error);
        }
      };
      fetchCameras();
    }
  }, []);

  useEffect(() => {
    let count = 0;
    if (searchString) {
      const lines = searchString.split("\n");
      count = lines.filter(line => line.trim() !== "" && line.split('. ')[1]?.trim()).length;
    }
    setTrackingCodeCount(count);
  }, [searchString]);

  const debounce = (func, delay) => {
    let timeoutId;
    return (...args) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func(...args), delay);
    };
  };

  const handleQuery = async () => {
    setIsQuerying(true);
    setHasQueried(true);
    try {
      const queryData = {
        search_string: searchString,
        default_days: defaultDays,
        from_time: startDate ? startDate.toISOString() : null,
        to_time: endDate ? endDate.toISOString() : null,
        selected_cameras: selectedCameras,
      };

      const response = await api.post("/query", queryData);
      const events = response.data.events || [];

      setResults(events);
      setSelectedVideos(events.map(event => event.event_id));
      setQueryCount(prev => prev + 1);
      setFoundCount(events.length);
    } catch (error) {
      console.error("Error in query:", error);
    } finally {
      setIsQuerying(false);
    }
  };

  const debouncedHandleQuery = debounce(handleQuery, 1000);

  const handleCameraSelection = (camera) => {
    const updatedCameras = selectedCameras.includes(camera)
      ? selectedCameras.filter((c) => c !== camera)
      : [...selectedCameras, camera];
    setSelectedCameras(updatedCameras);
    localStorage.setItem("selectedCameras", JSON.stringify(updatedCameras));
  };

  return (
    <div className="p-6 flex gap-6 w-screen h-screen">
      <div className="w-[26.67%] bg-gray-800 p-6 rounded-lg flex flex-col">
        <h1 className="text-3xl font-bold mb-4">Truy vấn</h1>
        <SearchModeSelector searchType={searchType} setSearchType={setSearchType} />
        {searchType === "File" && (
          <FileInputSection
            path={path}
            setPath={setPath}
            fileContent={fileContent}
            setFileContent={setFileContent}
            setShowModal={setShowModal}
            setHeaders={setHeaders}
          />
        )}
        <TextInputSection
          searchString={searchString}
          setSearchString={setSearchString}
          searchType={searchType}
        />
        <div className="mb-4">
          <label className="block mb-1">Truy vấn tại camera:</label>
          <div className="max-h-24 overflow-y-auto">
            {availableCameras.map((camera) => (
              <label key={camera} className="flex items-center mb-2">
                <input
                  type="checkbox"
                  checked={selectedCameras.includes(camera)}
                  onChange={() => handleCameraSelection(camera)}
                  className="mr-2"
                />
                {camera}
              </label>
            ))}
          </div>
        </div>
        <TimeAndQuerySection
          startDate={startDate}
          setStartDate={setStartDate}
          endDate={endDate}
          setEndDate={setEndDate}
          defaultDays={defaultDays}
          setDefaultDays={setDefaultDays}
          searchString={searchString}
          searchType={searchType}
          fileContent={fileContent}
          results={results}
          setResults={setResults}
          setSelectedVideos={setSelectedVideos}
          setQueryCount={setQueryCount}
          setFoundCount={setFoundCount}
          foundCount={foundCount}
          onQuery={debouncedHandleQuery}
          isQuerying={isQuerying}
        />
      </div>
      <div className="w-[53.33%] bg-gray-800 p-6 rounded-lg flex flex-col">
        <div className="flex items-center mb-4">
          <h1 className="text-3xl font-bold mr-4">Kết quả</h1>
          {(trackingCodeCount > 0 || foundCount > 0) && (
            <span className="text-lg text-gray-300">
              (Truy vấn {trackingCodeCount}/ Tìm được {foundCount})
            </span>
          )}
        </div>
        <ResultList
          results={results}
          selectedVideos={selectedVideos}
          setSelectedVideos={setSelectedVideos}
          hasQueried={hasQueried}
        />
        <VideoCutter
          results={results}
          selectedVideos={selectedVideos}
          setResults={setResults}
          setSelectedVideos={setSelectedVideos}
        /> {/* Thay CutVideoSection bằng VideoCutter */}
      </div>
      <ColumnSelectorModal
        showModal={showModal}
        setShowModal={setShowModal}
        headers={headers}
        selectedColumn={selectedColumn}
        setSelectedColumn={setSelectedColumn}
        history={history}
        setHistory={setHistory}
        selectedPlatform={selectedPlatform}
        setSelectedPlatform={setSelectedPlatform}
        shopeeLabel={shopeeLabel}
        setShopeeLabel={setShopeeLabel}
        lazadaLabel={lazadaLabel}
        setLazadaLabel={setLazadaLabel}
        tiktokLabel={tiktokLabel}
        setTiktokLabel={setTiktokLabel}
        customLabel1={customLabel1}
        setCustomLabel1={setCustomLabel1}
        customLabel2={customLabel2}
        setCustomLabel2={setCustomLabel2}
        path={path}
        fileContent={fileContent}
        setSearchString={setSearchString}
        setSearchType={setSearchType}
      />
    </div>
  );
};

export default QueryComponent;
```
## 📄 File: `Title.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Title.js`

```javascript
const Title = ({ text }) => {
   return <h2 className="text-xl font-bold text-center mb-6 tracking-widest">{text}</h2>;
 };
 
 export default Title;
```
## 📄 File: `Account.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Account.js`

```javascript
const Account = () => {
   return (
     <div className="p-6">
       <h1 className="text-3xl font-bold">Tài khoản</h1>
       <p>Đây là trang Tài khoản. Nội dung sẽ được thêm sau.</p>
     </div>
   );
 };
 
 export default Account;
```
## 📄 File: `App.test.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/App.test.js`

```javascript
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});

```
## 📄 File: `VtrackConfig.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/VtrackConfig.js`

```javascript
import React from "react";
import useVtrackConfig from "./hooks/useVtrackConfig";
import GeneralInfoForm from "./components/config/GeneralInfoForm";
import ConfigForm from "./components/config/ConfigForm";
import CameraDialog from "./components/config/CameraDialog";
import ProcessingRegionForm from "./components/config/ProcessingRegionForm";

const VtrackConfig = () => {
  const {
    fromTime,
    setFromTime,
    toTime,
    setToTime,
    country,
    setCountry,
    timezone,
    setTimezone,
    brandName,
    setBrandName,
    inputPath,
    setInputPath,
    outputPath,
    setOutputPath,
    workingDays,
    setWorkingDays,
    defaultDays,
    setDefaultDays,
    minPackingTime,
    setMinPackingTime,
    maxPackingTime,
    setMaxPackingTime,
    frameRate,
    setFrameRate,
    frameInterval,
    setFrameInterval,
    videoBuffer,
    setVideoBuffer,
    cameras,
    setCameras,
    selectedCameras,
    setSelectedCameras,
    showCameraDialog,
    setShowCameraDialog,
    error,
    setError,
    handleCountryChange,
    handleFromTimeChange,
    handleToTimeChange,
    handleWorkingDayChange,
    handleOpenExplorer,
    handleSaveGeneralInfo,
    handleSaveConfig,
    handleShowCameraDialog,
    handleCameraSelection,
    runDefaultOnStart,
    setRunDefaultOnStart,
  } = useVtrackConfig();

  // ✅ FIX: State để sync cameras từ ConfigForm - INSIDE COMPONENT
  const [configFormCameras, setConfigFormCameras] = React.useState([]);
  const [configFormSelectedCameras, setConfigFormSelectedCameras] = React.useState([]);
  const [activeVideoSource, setActiveVideoSource] = React.useState(null);

  // Thêm state cho ProcessingRegionForm
  const [videoPath, setVideoPath] = React.useState("");
  const [qrSize, setQrSize] = React.useState("");
  
  const handleAnalyzeRegions = () => {
    console.log("Phân tích vùng:", videoPath, qrSize);
  };

  // ✅ FIX: Auto sync inputPath khi activeVideoSource thay đổi - INSIDE COMPONENT
  React.useEffect(() => {
    console.log("=== INPUT PATH SYNC DEBUG ===");
    console.log("activeVideoSource changed:", activeVideoSource);
    
    if (activeVideoSource && activeVideoSource.path) {
      console.log("Auto-syncing inputPath to:", activeVideoSource.path);
      setInputPath(activeVideoSource.path);
    } else {
      console.log("activeVideoSource is null or has no path");
    }
  }, [activeVideoSource, setInputPath]);

  // ✅ FIX: Sync cameras với hook state khi configFormCameras thay đổi - INSIDE COMPONENT  
  React.useEffect(() => {
    if (configFormCameras && configFormCameras.length > 0) {
      const cameraObjects = configFormCameras.map(name => ({
        name: name,
        path: name
      }));
      setCameras(cameraObjects);
      console.log("Synced cameras to hook state:", cameraObjects);
    }
  }, [configFormCameras, setCameras]);

  React.useEffect(() => {
    if (configFormSelectedCameras && configFormSelectedCameras.length > 0) {
      setSelectedCameras(configFormSelectedCameras);
      console.log("Synced selectedCameras to hook state:", configFormSelectedCameras);
    }
  }, [configFormSelectedCameras, setSelectedCameras]);

  // ✅ FIX: Handler để nhận cameras từ ConfigForm - BACKUP ONLY
  const handleCamerasUpdate = React.useCallback((sourceCameras, selectedCameras, activeSource) => {
    console.log("=== CAMERAS UPDATE BACKUP DEBUG ===");
    console.log("sourceCameras:", sourceCameras);
    console.log("selectedCameras:", selectedCameras);
    console.log("activeSource:", activeSource);
    
    // Backup logic - chỉ khi direct setters không work
    if (!activeVideoSource && activeSource) {
      console.log("Backup: Setting activeVideoSource:", activeSource);
      setActiveVideoSource(activeSource);
      setInputPath(activeSource.path);
    }
  }, [activeVideoSource, setInputPath]);

  // ✅ FIX: Custom handleShowCameraDialog với validation
  const handleShowCameraDialogCustom = () => {
    if (!configFormCameras || configFormCameras.length === 0) {
      alert("Không tìm thấy camera nào. Vui lòng:\n1. Kiểm tra video source đã được cấu hình\n2. Đảm bảo có camera folders trong source");
      return;
    }
    
    // Chuyển đổi cameras thành format mong đợi bởi CameraDialog
    const cameraObjects = configFormCameras.map(name => ({
      name: name,
      path: name
    }));
    setCameras(cameraObjects);
    setSelectedCameras(configFormSelectedCameras);
    setShowCameraDialog(true);
  };

  // ✅ FIX: Custom handleSaveConfig với video source validation - SIMPLIFIED
  const handleSaveConfigCustom = () => {
    console.log("=== DEBUG SAVE CONFIG SIMPLIFIED ===");
    console.log("activeVideoSource:", activeVideoSource);
    console.log("configFormCameras:", configFormCameras);
    console.log("configFormSelectedCameras:", configFormSelectedCameras);
    console.log("inputPath:", inputPath);
    
    // ✅ Kiểm tra có cameras được chọn không
    if (!configFormSelectedCameras || configFormSelectedCameras.length === 0) {
      alert("Vui lòng chọn ít nhất một camera.\n\nCameras found: " + configFormCameras.join(", "));
      return;
    }

    // ✅ Kiểm tra và force sync inputPath
    let pathToUse = inputPath;
    
    if (activeVideoSource && activeVideoSource.path) {
      console.log("Using activeVideoSource.path:", activeVideoSource.path);
      pathToUse = activeVideoSource.path;
      setInputPath(pathToUse);
    } else if (!pathToUse || pathToUse.trim() === "") {
      alert("Không tìm thấy video source path.\n\nVui lòng:\n1. Refresh page\n2. Cấu hình lại video source\n3. Thử lại");
      return;
    }

    console.log("Final pathToUse:", pathToUse);

    // ✅ Đóng dialog
    setShowCameraDialog(false);

    // ✅ Call original handler  
    console.log("Calling handleSaveConfig...");
    handleSaveConfig();
  };

  const countries = [
    "Việt Nam", "Nhật Bản", "Hàn Quốc", "Thái Lan", "Singapore",
    "Mỹ", "Anh", "Pháp", "Đức", "Úc"
  ];

  return (
    <div className="p-6 flex gap-6 w-[100%]">
      <GeneralInfoForm
        country={country}
        setCountry={setCountry}
        timezone={timezone}
        setTimezone={setTimezone}
        brandName={brandName}
        setBrandName={setBrandName}
        workingDays={workingDays}
        setWorkingDays={setWorkingDays}
        fromTime={fromTime}
        setFromTime={setFromTime}
        toTime={toTime}
        setToTime={setToTime}
        handleCountryChange={handleCountryChange}
        handleFromTimeChange={handleFromTimeChange}
        handleToTimeChange={handleToTimeChange}
        handleWorkingDayChange={handleWorkingDayChange}
        handleSaveGeneralInfo={handleSaveGeneralInfo}
        countries={countries}
      />
      <ConfigForm
        inputPath={inputPath}
        setInputPath={setInputPath}
        outputPath={outputPath}
        setOutputPath={setOutputPath}
        defaultDays={defaultDays}
        setDefaultDays={setDefaultDays}
        minPackingTime={minPackingTime}
        setMinPackingTime={setMinPackingTime}
        maxPackingTime={maxPackingTime}
        setMaxPackingTime={setMaxPackingTime}
        frameRate={frameRate}
        setFrameRate={setFrameRate}
        frameInterval={frameInterval}
        setFrameInterval={setFrameInterval}
        videoBuffer={videoBuffer}
        setVideoBuffer={setVideoBuffer}
        error={error}
        handleOpenExplorer={handleOpenExplorer}
        handleShowCameraDialog={handleShowCameraDialogCustom}
        runDefaultOnStart={runDefaultOnStart}
        setRunDefaultOnStart={setRunDefaultOnStart}
        // ✅ FIX: Pass state setters để ConfigForm có thể update trực tiếp
        onCamerasUpdate={handleCamerasUpdate}
        setActiveVideoSource={setActiveVideoSource}
        setConfigFormCameras={setConfigFormCameras}
        setConfigFormSelectedCameras={setConfigFormSelectedCameras}
      />
      <ProcessingRegionForm
        videoPath={videoPath}
        setVideoPath={setVideoPath}
        qrSize={qrSize}
        setQrSize={setQrSize}
        handleAnalyzeRegions={handleAnalyzeRegions}
      />
      <CameraDialog
        showCameraDialog={showCameraDialog}
        setShowCameraDialog={setShowCameraDialog}
        cameras={cameras}
        selectedCameras={selectedCameras}
        handleCameraSelection={handleCameraSelection}
        handleSaveConfig={handleSaveConfigCustom}
      />
    </div>
  );
};

export default VtrackConfig;
```
## 📄 File: `Dashboard.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Dashboard.js`

```javascript
import Sidebar from "./Sidebar";
import VtrackConfig from "./VtrackConfig";
import QueryComponent from "./QueryComponent";
import Account from "./Account";
import ProgramTab from "./components/program/ProgramTab";
import useProgramLogic from "./hooks/useProgramLogic";

const Dashboard = ({ setActiveMenu, activeMenu }) => {
  const {
    runningCard,
    fileList,
    customPath,
    showConfirmButton,
    firstRunCompleted,
    handleRunStop,
    handleConfirmRun,
    isRunning,
    setCustomPath,
  } = useProgramLogic();

  return (
    <div className="flex min-h-screen bg-gray-900 text-white font-montserrat">
      <Sidebar setActiveMenu={setActiveMenu} activeMenu={activeMenu} />
      <div className="flex-1 p-6 w-full">
        {activeMenu === "Chương trình" ? (
          <ProgramTab
            runningCard={runningCard}
            fileList={fileList}
            customPath={customPath}
            showConfirmButton={showConfirmButton}
            firstRunCompleted={firstRunCompleted}
            handleRunStop={handleRunStop}
            handleConfirmRun={handleConfirmRun}
            isRunning={isRunning}
            setCustomPath={setCustomPath}
          />
        ) : activeMenu === "Cấu hình" ? (
          <VtrackConfig />
        ) : activeMenu === "Truy vấn" ? (
          <QueryComponent />
        ) : activeMenu === "Tài khoản" ? (
          <Account />
        ) : (
          <div>
            <h1 className="text-3xl font-bold">Đang phát triển: {activeMenu}</h1>
            <p>Nội dung cho {activeMenu} sẽ được thêm sau.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
```
## 📄 File: `api.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/api.js`

```javascript
import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8080",
});

export const getConfig = () => api.get("/config");
export const updateConfig = (configData) => api.post("/config", configData);
export const runQuery = (queryData) => api.post("/query", queryData);
export const runProgram = (programData) => api.post("/program", programData);
export const confirmRun = (confirmData) => api.post("/confirm-run", confirmData);
export const getCameras = () => api.get("/get-cameras");
export const cutVideos = (cutData) => api.post("/cut-videos", cutData);
export const analyzeRegions = (data) => api.post("/analyze-regions", data);
export const getFrames = (data) => api.post("/get-frames", data);
export const submitRois = (data) => api.post("/submit-rois", data);
export const sendHandDetection = (data) => api.post("/api/hand-detection", data);
export const getRoiFrame = () => api.get("/get-roi-frame");
export const getFinalRoiFrame = (cameraId, timestamp) => api.get(`/get-final-roi-frame?camera_id=${cameraId}&timestamp=${timestamp}`);

// Video Sources APIs
export const getSources = () => api.get("/get-sources");
export const addSources = (sourcesData) => api.post("/save-sources", sourcesData);
export const testSourceConnection = (sourceData) => api.post("/test-source", sourceData);
export const updateSource = (id, sourceData) => api.put(`/update-source/${id}`, sourceData);
export const deleteSource = (id) => api.delete(`/delete-source/${id}`);
export const toggleSource = (id, active) => api.post(`/toggle-source/${id}`, { active });

// NEW: Camera Detection APIs
export const detectCameras = (pathData) => api.post("/detect-cameras", pathData);
export const updateSourceCameras = (cameraData) => api.post("/update-source-cameras", cameraData);

export default api;
```
## 📄 File: `setupTests.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/setupTests.js`

```javascript
// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';

```
## 📄 File: `App.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/App.js`

```javascript
import "@fontsource/montserrat";
import { useState } from "react";
import Dashboard from "./Dashboard";

function App() {
  const [activeMenu, setActiveMenu] = useState("Chương trình");
  return (
    <div className="flex min-h-screen bg-gray-900 text-white font-montserrat">
      <Dashboard setActiveMenu={setActiveMenu} activeMenu={activeMenu} />
    </div>
  );
}

export default App;
```
## 📄 File: `SearchModeSelector.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/ui/SearchModeSelector.js`

```javascript
const SearchModeSelector = ({ searchType, setSearchType }) => {
  return (
    <div className="mb-4">
      <label className="block mb-1">Loại tìm kiếm:</label>
      <div className="flex gap-4">
        <label className="flex items-center">
          <input
            type="radio"
            name="searchType"
            value="File"
            className="mr-1"
            checked={searchType === "File"}
            onChange={() => setSearchType("File")}
          />
          File
        </label>
        <label className="flex items-center">
          <input
            type="radio"
            name="searchType"
            value="Text"
            className="mr-1"
            checked={searchType === "Text"}
            onChange={() => setSearchType("Text")}
          />
          Text
        </label>
      </div>
    </div>
  );
};

export default SearchModeSelector;
```
## 📄 File: `Button.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/ui/Button.js`

```javascript
const Button = ({ text }) => {
   return (
     <button className="bg-red-600 text-white font-bold py-2 px-4 rounded mt-4">
       {text}
     </button>
   );
 };
 
 export default Button;
```
## 📄 File: `Card.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/ui/Card.js`

```javascript
import { useState } from "react";

const Card = ({ title, description, isRunning, onRunStop, onPathChange, isLocked }) => {
  const [path, setPath] = useState("");

  const handleOpenExplorer = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.onchange = (e) => {
      const selectedPath = e.target.files[0]?.name || "";
      setPath(selectedPath);
      if (onPathChange) {
        onPathChange(selectedPath);
      }
    };
    input.click();
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg flex flex-col items-center h-full">
      <h3 className="text-lg font-bold mb-2">{title}</h3>
      <p className="mb-4 text-center flex-1">{description}</p>
      <div className="mt-auto w-full flex flex-col items-center">
        {title === "Chỉ định" && (
          <div className="mb-4 w-full">
            <div className="relative w-full">
              <input
                type="text"
                value={path}
                onChange={(e) => {
                  setPath(e.target.value);
                  if (onPathChange) {
                    onPathChange(e.target.value);
                  }
                }}
                placeholder="Nhập đường dẫn file..."
                className="w-full p-2 rounded bg-gray-700 text-white"
              />
              <button
                type="button"
                onClick={handleOpenExplorer}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
              >
                ...
              </button>
            </div>
          </div>
        )}
        {isLocked || (title === "Lần đầu" && isRunning) ? (
          <button
            className="w-1/2 py-2 px-4 rounded font-bold text-white bg-gray-500"
            disabled
          >
            LOCKED
          </button>
        ) : (
          <button
            className={`w-1/2 py-2 px-4 rounded font-bold text-white ${
              isRunning && title !== "Lần đầu" ? "bg-[#E82127]" : "bg-[#00D4FF]"
            }`}
            onClick={onRunStop}
            disabled={title === "Chỉ định" && !path && !isRunning}
          >
            {(isRunning && title !== "Lần đầu") ? "STOP" : "RUN"}
          </button>
        )}
      </div>
    </div>
  );
};

export default Card;
```
## 📄 File: `ResultList.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/result/ResultList.js`

```javascript
import React from "react";

const ResultList = ({ results, selectedVideos, setSelectedVideos, hasQueried }) => {
  const handleSelectVideo = (eventId) => {
    if (selectedVideos.includes(eventId)) {
      setSelectedVideos(selectedVideos.filter((id) => id !== eventId));
    } else {
      setSelectedVideos([...selectedVideos, eventId]);
    }
  };

  React.useEffect(() => {
    if (results.length > 0) {
      const newSelectedVideos = results.map(event => event.event_id);
      setSelectedVideos(newSelectedVideos);
    }
  }, [results]);

  return (
    <div className="flex-1 mb-4 bg-gray-700 rounded p-2 overflow-y-auto">
      {hasQueried ? (
        results.length > 0 ? (
          results.map((event, index) => (
            <label key={event.event_id} className="flex items-center mb-2">
              <input
                type="checkbox"
                className="mr-2"
                checked={selectedVideos.includes(event.event_id)}
                onChange={() => handleSelectVideo(event.event_id)}
              />
              {`${index + 1}. ${event.video_file}`}
            </label>
          ))
        ) : (
          <p>Không có kết quả</p>
        )
      ) : (
        <p>Vui lòng thực hiện truy vấn</p>
      )}
    </div>
  );
};

export default ResultList;

```
## 📄 File: `CutVideoSection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/result/CutVideoSection.js`

```javascript
import api from "../../api"; // Thêm import api để gọi /cut-videos

const CutVideoSection = ({ results, selectedVideos, setResults, setSelectedVideos, cutVideos, setCutVideos }) => {
  const handleCutVideos = async () => {
    if (selectedVideos.length === 0) {
      alert("Vui lòng chọn ít nhất một sự kiện để cắt video.");
      return;
    }
    const videosToCut = results.filter((event) => selectedVideos.includes(event.event_id));
    try {
      const cutData = {
        selected_events: videosToCut,
      };
      const response = await api.post("/cut-videos", cutData); // Gọi API /cut-videos
      const cutFiles = response.data.cut_files || []; // Lấy danh sách file từ phản hồi
      setCutVideos(prev => [...prev, ...cutFiles]); // Tối ưu với prev
      setResults(results.filter((event) => !selectedVideos.includes(event.event_id)));
      setSelectedVideos([]);
    } catch (error) {
      console.error("Error cutting videos:", error);
      alert("Có lỗi xảy ra khi cắt video. Vui lòng thử lại.");
    }
  };

  const handleRefresh = () => {
    setResults([]);
    setSelectedVideos([]);
    setCutVideos([]); // Xóa danh sách video đã cắt
  };

  return (
    <>
      <div className="flex gap-4 mb-4">
        <button
          className="w-1/2 py-2 bg-red-600 text-white font-bold rounded"
          onClick={handleCutVideos}
        >
          Cắt Video
        </button>
        <button
          className="w-1/2 py-2 px-4 rounded font-bold text-white bg-[#00D4FF]"
          onClick={handleRefresh}
        >
          Refresh
        </button>
      </div>
      <div className="flex-1 bg-gray-700 rounded p-2 overflow-y-auto">
        {cutVideos.map((video, index) => (
          <label key={index} className="flex items-center mb-2">
            <input type="checkbox" className="mr-2" />
            {`${index + 1}. ${video}`}
          </label>
        ))}
      </div>
    </>
  );
};

export default CutVideoSection;
```
## 📄 File: `VideoCutter.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/result/VideoCutter.js`

```javascript
import { useState } from "react";
import api from "../../api"; // Điều chỉnh đường dẫn tương đối từ thư mục result

const VideoCutter = ({ results, selectedVideos, setResults, setSelectedVideos }) => {
  const [cutVideos, setCutVideos] = useState([]);
  const [selectedCutVideo, setSelectedCutVideo] = useState(null); // Thêm trạng thái để lưu video đã cắt được chọn

  // Hàm xử lý yêu cầu cắt video
  const handleCutVideos = async () => {
    if (selectedVideos.length === 0) {
      alert("Vui lòng chọn ít nhất một sự kiện để cắt video.");
      return;
    }
    try {
      const selectedEvents = results.filter(event => selectedVideos.includes(event.event_id));
      const cutData = {
        selected_events: selectedEvents,
        // tracking_codes_filter sẽ được thêm sau nếu cần từ QueryComponent
      };

      const response = await api.post("/cut-videos", cutData); // Gọi API cắt video
      const cutFiles = response.data.cut_files || [];

      setCutVideos(prev => [...prev, ...cutFiles]); // Cập nhật danh sách video đã cắt
      setResults(prev => prev.filter(event => !selectedVideos.includes(event.event_id))); // Xóa sự kiện đã cắt
      setSelectedVideos([]); // Reset danh sách chọn
    } catch (error) {
      console.error("Error cutting videos:", error);
      alert("Có lỗi xảy ra khi cắt video. Vui lòng thử lại.");
    }
  };

  const handleRefresh = () => {
    setResults([]);
    setSelectedVideos([]);
    setCutVideos([]);
    setSelectedCutVideo(null); // Reset video đã chọn khi refresh
  };

  // Hàm xử lý khi nhấn nút "Play Video"
  const handlePlayVideo = () => {
    if (!selectedCutVideo) {
      alert("Vui lòng chọn một video để phát");
      return;
    }
    alert(`Đang phát video "${selectedCutVideo}" được chọn`);
  };

  return (
    <>
      <div className="flex gap-4 mb-4">
        <button
          className="w-1/3 py-2 bg-red-600 text-white font-bold rounded"
          onClick={handleCutVideos}
        >
          Cắt Video
        </button>
        <button
          className="w-1/3 py-2 px-4 rounded font-bold text-white bg-[#00D4FF]"
          onClick={handleRefresh}
        >
          Refresh
        </button>
        <button
          className="w-1/3 py-2 px-4 rounded font-bold text-white bg-green-600"
          onClick={handlePlayVideo}
        >
          Play Video
        </button>
      </div>
      <div className="flex-1 bg-gray-700 rounded p-2 overflow-y-auto">
        {cutVideos.map((video, index) => (
          <label
            key={index}
            className="flex items-center mb-2 cursor-pointer hover:bg-gray-600 transition duration-300"
            onClick={() => setSelectedCutVideo(video)}
          >
            <input
              type="radio"
              name="cutVideo"
              className="mr-2"
              checked={selectedCutVideo === video}
              onChange={() => setSelectedCutVideo(video)}
            />
            <span className="flex-1 truncate">{`${index + 1}. ${video}`}</span>
          </label>
        ))}
      </div>
    </>
  );
};

export default VideoCutter;
```
## 📄 File: `ConfigForm.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/ConfigForm.js`

```javascript
import React, { useState, useEffect, useCallback } from 'react';
import AddSourceModal from './AddSourceModal';

const ConfigForm = ({
  inputPath,
  setInputPath,
  outputPath,
  setOutputPath,
  defaultDays,
  setDefaultDays,
  minPackingTime,
  setMinPackingTime,
  maxPackingTime,
  setMaxPackingTime,
  frameRate,
  setFrameRate,
  frameInterval,
  setFrameInterval,
  videoBuffer,
  setVideoBuffer,
  error,
  handleOpenExplorer,
  handleShowCameraDialog,
  // ✅ FIX: Direct state setters thay vì callback
  onCamerasUpdate,
  setActiveVideoSource,
  setConfigFormCameras,
  setConfigFormSelectedCameras,
}) => {
  // State for single active source
  const [activeSource, setActiveSource] = useState(null);
  const [sourceCameras, setSourceCameras] = useState([]);
  const [selectedCameras, setSelectedCameras] = useState([]);
  const [isLoadingSource, setIsLoadingSource] = useState(false);
  const [showAddSourceModal, setShowAddSourceModal] = useState(false);
  const [showUpdateSourceModal, setShowUpdateSourceModal] = useState(false);

  // API functions
  const getSources = async () => {
    const response = await fetch('/get-sources');
    return response.json();
  };

  const addSources = async (sourcesData) => {
    const response = await fetch('/save-sources', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(sourcesData)
    });
    return response.json();
  };

  const deleteSource = async (sourceId) => {
    const response = await fetch(`/delete-source/${sourceId}`, {
      method: 'DELETE'
    });
    return response.json();
  };

  const testSourceConnection = async (sourceData) => {
    const response = await fetch('/test-source', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(sourceData)
    });
    return response.json();
  };

  const detectCameras = async (sourcePath) => {
    const response = await fetch('/detect-cameras', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: sourcePath })
    });
    return response.json();
  };

  const updateSourceCameras = async (sourceId, selectedCameras) => {
    const response = await fetch('/update-source-cameras', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source_id: sourceId, selected_cameras: selectedCameras })
    });
    return response.json();
  };

  // Load active source
  const loadActiveSource = useCallback(async () => {
    setIsLoadingSource(true);
    try {
      const response = await getSources();
      const sources = response.sources || [];
      const active = sources.find(s => s.active);
      setActiveSource(active || null);
      
      let cameras = [];
      let selected = [];
      
      // Load camera info based on source type
      if (active) {
        if (active.source_type === 'local') {
          // Local source: detect camera folders
          try {
            const cameraResponse = await detectCameras(active.path);
            cameras = cameraResponse.cameras || [];
            selected = cameraResponse.selected_cameras || [];
          } catch (cameraError) {
            console.warn('Failed to load camera info:', cameraError);
            cameras = [];
            selected = [];
          }
        } else if (active.source_type === 'nvr') {
          // NVR source: get detected cameras from config, selected cameras from database
          try {
            const nvrConfig = active.config || {};
            const detectedCameras = nvrConfig.detected_cameras || [];
            
            // Convert detected cameras to names
            const detectedCameraNames = detectedCameras.map(cam => 
              cam.name || cam.id || `Camera ${detectedCameras.indexOf(cam) + 1}`
            );
            
            // Get REAL selected cameras from processing_config using detectCameras API
            const cameraResponse = await detectCameras(active.path);
            const realSelectedCameras = cameraResponse.selected_cameras || [];
            
            cameras = detectedCameraNames;
            selected = realSelectedCameras;
            
            console.log('Loaded NVR cameras:', { 
              detected: detectedCameraNames.length, 
              selected: realSelectedCameras.length,
              detectedNames: detectedCameraNames,
              selectedNames: realSelectedCameras
            });
            
          } catch (nvrError) {
            console.warn('Failed to load NVR camera info:', nvrError);
            cameras = [];
            selected = [];
          }
        }
      }
      
      setSourceCameras(cameras);
      setSelectedCameras(selected);
      
    } catch (error) {
      console.error('Error loading active source:', error);
      alert('Failed to load video source');
      setSourceCameras([]);
      setSelectedCameras([]);
    } finally {
      setIsLoadingSource(false);
    }
  }, []);

  useEffect(() => {
    loadActiveSource();
  }, []); // ✅ FIX: Chỉ run một lần khi component mount

  // ✅ FIX: Separate effect để sync với parent state - DIRECT UPDATE
  useEffect(() => {
    console.log("=== CONFIG FORM DIRECT UPDATE DEBUG ===");
    console.log("activeSource:", activeSource);
    console.log("sourceCameras:", sourceCameras);
    console.log("selectedCameras:", selectedCameras);
    
    // ✅ Direct update parent state
    if (setActiveVideoSource) {
      console.log("Setting activeVideoSource directly:", activeSource);
      setActiveVideoSource(activeSource);
    }
    
    if (setConfigFormCameras) {
      console.log("Setting configFormCameras directly:", sourceCameras);
      setConfigFormCameras(sourceCameras);
    }
    
    if (setConfigFormSelectedCameras) {
      console.log("Setting configFormSelectedCameras directly:", selectedCameras);
      setConfigFormSelectedCameras(selectedCameras);
    }
    
    // ✅ Also try callback as backup
    if (onCamerasUpdate) {
      console.log("Also calling onCamerasUpdate callback as backup");
      onCamerasUpdate(sourceCameras, selectedCameras, activeSource);
    }
    
  }, [sourceCameras, selectedCameras, activeSource, setActiveVideoSource, setConfigFormCameras, setConfigFormSelectedCameras, onCamerasUpdate]);

  // Enhanced Add Source Handler (supports NVR)
  const handleAddSource = async (sourceData) => {
    try {
      console.log('Adding source:', sourceData);
      
      // Add source
      await addSources({ sources: [sourceData] });
      
      // Post-processing based on source type
      if (sourceData.source_type === 'local') {
        // Local source: trigger camera detection
        try {
          const cameraResponse = await detectCameras(sourceData.path);
          if (cameraResponse.cameras && cameraResponse.cameras.length > 0) {
            // Auto-select all detected cameras by default
            await updateSourceCameras(cameraResponse.source_id, cameraResponse.cameras);
          }
        } catch (cameraError) {
          console.warn('Camera detection failed:', cameraError);
          // Continue anyway - camera detection is optional
        }
      } else if (sourceData.source_type === 'nvr') {
        // NVR source: cameras already discovered and selected in modal
        const selectedCameras = sourceData.config?.selected_cameras || [];
        if (selectedCameras.length > 0) {
          try {
            // Update processing_config with selected NVR cameras
            await updateSourceCameras('nvr_source', selectedCameras);
            console.log('NVR cameras saved:', selectedCameras);
          } catch (nvrError) {
            console.warn('Failed to save NVR camera selection:', nvrError);
          }
        }
      }
      
      alert(`${sourceData.source_type.toUpperCase()} source added successfully!`);
      loadActiveSource();
    } catch (error) {
      console.error('Error adding source:', error);
      alert('Failed to add source: ' + (error.response?.data?.error || error.message));
    }
  };

  // Update Source Handler
  const handleUpdateSource = () => {
    if (!activeSource) return;
    setShowUpdateSourceModal(true);
  };

  // Change Source Type Handler (reset workflow)
  const handleChangeSourceType = async () => {
    if (!activeSource) return;
    
    const confirmMessage = `This will remove the current source "${activeSource.name}" and reset to add a new source.\n\nAre you sure you want to continue?`;
    
    if (!window.confirm(confirmMessage)) return;
    
    try {
      // Delete current source
      await deleteSource(activeSource.id);
      
      // Reload to show "No source configured" state
      await loadActiveSource();
      
    } catch (error) {
      console.error('Error removing source:', error);
      alert('Failed to remove source');
    }
  };

  const handleUpdateComplete = () => {
    loadActiveSource(); // Reload source and camera info
    setShowUpdateSourceModal(false);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'Unknown';
    try {
      return new Date(dateString).toLocaleString('vi-VN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Asia/Ho_Chi_Minh'
      });
    } catch {
      return dateString;
    }
  };

  // Get source type display info
  const getSourceTypeInfo = (sourceType) => {
    const sourceTypes = {
      local: {
        icon: '📁',
        name: 'LOCAL STORAGE',
        color: 'bg-blue-600'
      },
      nvr: {
        icon: '🔗',
        name: 'NVR/DVR SYSTEM',
        color: 'bg-purple-600'
      },
      cloud: {
        icon: '☁️',
        name: 'CLOUD STORAGE',
        color: 'bg-cyan-600'
      }
    };
    return sourceTypes[sourceType] || { icon: '❓', name: 'UNKNOWN', color: 'bg-gray-600' };
  };

  return (
    <div className="w-[25%] bg-gray-800 p-6 rounded-lg flex flex-col">
      <h1 className="text-3xl font-bold mb-4">Cấu hình</h1>
      {error && <div style={{ color: 'red' }}>{error}</div>}
      
      {/* Single Active Video Source Section */}
      <div className="mb-6 p-4 bg-gray-700 rounded-lg">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-lg font-bold text-white">Current Video Input Source</h3>
        </div>

        {isLoadingSource ? (
          <div className="text-center py-4">
            <div className="text-gray-400 text-sm">Loading source...</div>
          </div>
        ) : activeSource ? (
          <div className="bg-gray-600 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-3">
              <span className="font-medium text-white text-lg">{activeSource.name}</span>
              <span className="px-2 py-1 rounded text-xs bg-green-600 text-white">
                Active
              </span>
            </div>
            
            {/* Enhanced Source Type Display */}
            <div className="flex items-center gap-2 mb-2">
              <span className="text-sm text-gray-300"><strong>Type:</strong></span>
              <div className="flex items-center gap-1">
                <span className="text-sm">{getSourceTypeInfo(activeSource.source_type).icon}</span>
                <span className={`px-2 py-1 rounded text-xs text-white font-medium ${getSourceTypeInfo(activeSource.source_type).color}`}>
                  {getSourceTypeInfo(activeSource.source_type).name}
                </span>
              </div>
            </div>
            
            <div className="text-gray-300 text-sm mb-2 break-all">
              <strong>Path:</strong> {activeSource.path}
            </div>
            
            {/* NVR-specific information */}
            {activeSource.source_type === 'nvr' && activeSource.config && (
              <div className="text-gray-300 text-sm mb-2">
                <strong>Protocol:</strong> {activeSource.config.protocol?.toUpperCase() || 'ONVIF'}
                {activeSource.config.auto_sync && (
                  <span className="ml-2 px-1 py-0.5 bg-green-700 text-green-200 rounded text-xs">
                    Auto-Sync
                  </span>
                )}
              </div>
            )}
            
            <div className="text-gray-300 text-sm mb-2">
              <strong>Added:</strong> {formatDate(activeSource.created_at)}
            </div>
            
            {/* Camera Information */}
            {(activeSource.source_type === 'local' || activeSource.source_type === 'nvr') && (
              <div className="text-gray-300 text-sm mb-3">
                <strong>Cameras:</strong>{' '}
                {sourceCameras.length > 0 ? (
                  <span>
                    {selectedCameras.length} selected of {sourceCameras.length} detected
                    <div className="mt-1 text-xs">
                      {selectedCameras.length > 0 ? (
                        <span className="text-green-300">
                          Active: {selectedCameras.slice(0, 3).join(', ')}
                          {selectedCameras.length > 3 && ` +${selectedCameras.length - 3} more`}
                        </span>
                      ) : (
                        <span className="text-yellow-300">No cameras selected</span>
                      )}
                    </div>
                    {sourceCameras.length > selectedCameras.length && (
                      <div className="text-xs text-gray-400">
                        Available: {sourceCameras.filter(cam => !selectedCameras.includes(cam)).slice(0, 2).join(', ')}
                        {sourceCameras.filter(cam => !selectedCameras.includes(cam)).length > 2 && '...'}
                      </div>
                    )}
                  </span>
                ) : (
                  <span className="text-gray-400">
                    {activeSource.source_type === 'nvr' ? 'No cameras discovered' : 'No camera folders detected'}
                  </span>
                )}
              </div>
            )}
            
            {/* Action Buttons */}
            <div className="flex justify-end gap-2">
              <button
                onClick={handleUpdateSource}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded text-sm font-medium"
              >
                Update
              </button>
              <button
                onClick={handleChangeSourceType}
                className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded text-sm font-medium"
              >
                Change
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center py-6">
            <div className="text-gray-400 text-sm mb-3">
              No video source configured yet.
            </div>
            <button
              onClick={() => setShowAddSourceModal(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded font-medium"
            >
              Add Video Source
            </button>
          </div>
        )}
      </div>

      {/* ✅ FIX: Input Path Section - Hiển thị info từ Video Source */}
      <div className="mb-6 p-4 bg-gray-700 rounded-lg">
        <h3 className="text-lg font-bold text-white mb-3">Input Video Path</h3>
        
        {activeSource ? (
          <div className="bg-gray-600 p-3 rounded">
            <div className="text-sm text-gray-300 mb-1">
              <strong>Source:</strong> {activeSource.name}
            </div>
            <div className="text-sm text-gray-300 mb-1">
              <strong>Path:</strong> {activeSource.path}
            </div>
            <div className="text-sm text-gray-300">
              <strong>Type:</strong> {getSourceTypeInfo(activeSource.source_type).name}
            </div>
            <div className="mt-2 text-xs text-green-300">
              ✅ Input path automatically configured from video source
            </div>
          </div>
        ) : (
          <div className="text-center py-4 bg-gray-600 rounded">
            <div className="text-gray-400 text-sm mb-3">
              No video source configured. Input path will be empty.
            </div>
            <button
              onClick={() => setShowAddSourceModal(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded text-sm font-medium"
            >
              Add Video Source First
            </button>
          </div>
        )}
      </div>

      {/* Legacy Input Path Field - Hidden khi có video source */}
      {!activeSource && (
        <div className="mb-4">
          <label className="block mb-1">Legacy Input Path (Deprecated):</label>
          <div className="relative w-full">
            <input
              type="text"
              value={inputPath}
              onChange={(e) => setInputPath(e.target.value)}
              placeholder="Please add a video source instead"
              className="w-full p-2 rounded bg-gray-700 text-white"
              disabled
            />
            <div className="text-xs text-yellow-400 mt-1">
              ⚠️ Please use "Add Video Source" button above instead
            </div>
          </div>
        </div>
      )}

      <div className="mb-4">
        <label className="block mb-1">Vị trí Output Video:</label>
        <div className="relative w-full">
          <input
            type="text"
            value={outputPath}
            onChange={(e) => setOutputPath(e.target.value)}
            placeholder="Vị trí Output Video (e.g., /Users/annhu/vtrack_app/V_Track/output_clips)"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
          <button
            type="button"
            onClick={() => handleOpenExplorer("output")}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
          >
            ...
          </button>
        </div>
      </div>
      <div className="flex flex-col gap-4 mb-4">
        <div>
          <label className="block mb-1">Thời gian lưu trữ (ngày):</label>
          <input
            type="number"
            value={defaultDays}
            onChange={(e) => setDefaultDays(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Thời gian đóng hàng nhanh nhất (giây):</label>
          <input
            type="number"
            value={minPackingTime}
            onChange={(e) => setMinPackingTime(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Thời gian đóng hàng chậm nhất (giây):</label>
          <input
            type="number"
            value={maxPackingTime}
            onChange={(e) => setMaxPackingTime(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Tốc độ frame:</label>
          <input
            type="number"
            value={frameRate}
            onChange={(e) => setFrameRate(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Khoảng cách Frame:</label>
          <input
            type="number"
            value={frameInterval}
            onChange={(e) => setFrameInterval(Number(e.target.value))}
            min="2"
            max="30"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Buffer Video (giây):</label>
          <input
            type="number"
            value={videoBuffer}
            onChange={(e) => setVideoBuffer(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
      </div>
      <div className="mt-auto flex justify-center">
        <button
          onClick={handleShowCameraDialog}
          className="w-1/2 py-2 bg-blue-600 text-white font-bold rounded"
        >
          Gửi
        </button>
      </div>

      {/* Enhanced AddSourceModal with NVR support */}
      {showAddSourceModal && (
        <AddSourceModal
          show={showAddSourceModal}
          onClose={() => setShowAddSourceModal(false)}
          onAdd={handleAddSource}
          testSourceConnection={testSourceConnection}
        />
      )}

      {/* Simple Update Source Modal */}
      {showUpdateSourceModal && activeSource && (
        <SimpleUpdateSourceModal
          show={showUpdateSourceModal}
          source={activeSource}
          sourceCameras={sourceCameras}
          selectedCameras={selectedCameras}
          onClose={() => setShowUpdateSourceModal(false)}
          onUpdate={handleUpdateComplete}
          testSourceConnection={testSourceConnection}
          detectCameras={detectCameras}
          updateSourceCameras={updateSourceCameras}
        />
      )}
    </div>
  );
};

// Enhanced Update Source Modal Component (supports NVR)
const SimpleUpdateSourceModal = ({ 
  show, 
  source, 
  sourceCameras,
  selectedCameras: initialSelectedCameras,
  onClose, 
  onUpdate, 
  testSourceConnection, 
  detectCameras, 
  updateSourceCameras
}) => {
  const [path] = useState(source.path);
  const [detectedCameras, setDetectedCameras] = useState(sourceCameras);
  const [selectedCameras, setSelectedCameras] = useState(initialSelectedCameras);
  
  // Loading states
  const [isDetecting, setIsDetecting] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    setDetectedCameras(sourceCameras);
    setSelectedCameras(initialSelectedCameras);
  }, [sourceCameras, initialSelectedCameras]);

  const detectCamerasInPath = async () => {
    if (!path) return;
    
    setIsDetecting(true);
    try {
      if (source.source_type === 'local') {
        // Local source: scan for camera folders
        const response = await detectCameras(path);
        if (response.cameras) {
          setDetectedCameras(response.cameras);
          // Keep existing selected cameras that are still available
          const validSelectedCameras = selectedCameras.filter(cam => 
            response.cameras.includes(cam)
          );
          setSelectedCameras(validSelectedCameras);
        }
      } else if (source.source_type === 'nvr') {
        // NVR source: re-test connection to discover cameras
        const testData = {
          source_type: 'nvr',
          path: source.path,
          config: source.config || {}
        };
        
        const response = await testSourceConnection(testData);
        if (response.accessible && response.cameras) {
          const cameraNames = response.cameras.map(cam => 
            cam.name || cam.id || `Camera ${response.cameras.indexOf(cam) + 1}`
          );
          setDetectedCameras(cameraNames);
          
          // Keep existing selected cameras that are still available
          const validSelectedCameras = selectedCameras.filter(cam => 
            cameraNames.includes(cam)
          );
          setSelectedCameras(validSelectedCameras);
        }
      }
    } catch (error) {
      console.error('Camera detection failed:', error);
      setDetectedCameras([]);
      setSelectedCameras([]);
    } finally {
      setIsDetecting(false);
    }
  };

  const handleTestConnection = async () => {
    if (!path) {
      alert('No path to test');
      return;
    }

    setIsLoading(true);
    try {
      const testData = {
        source_type: source.source_type,
        path: path,
        config: source.config || {}
      };
      
      const response = await testSourceConnection(testData);
      setTestResult({
        success: response.accessible,
        message: response.message
      });
      
      // Auto-discover cameras on successful test for NVR
      if (response.accessible && source.source_type === 'nvr' && response.cameras) {
        const cameraNames = response.cameras.map(cam => 
          cam.name || cam.id || `Camera ${response.cameras.indexOf(cam) + 1}`
        );
        setDetectedCameras(cameraNames);
        setTestResult(prev => ({
          ...prev,
          message: `${prev.message} - Found ${response.cameras.length} camera(s)`
        }));
      }
      
    } catch (error) {
      setTestResult({
        success: false,
        message: error.message || 'Connection test failed'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCameraToggle = (cameraName) => {
    setSelectedCameras(prev => 
      prev.includes(cameraName) 
        ? prev.filter(c => c !== cameraName)
        : [...prev, cameraName]
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      // Update camera selection
      await updateSourceCameras(source.id, selectedCameras);
      
      alert('Source updated successfully!');
      onUpdate();
    } catch (error) {
      console.error('Error updating source:', error);
      alert('Failed to update source: ' + (error.response?.data?.error || error.message));
    }
  };

  if (!show) return null;

  const getSourceTypeInfo = (sourceType) => {
    const sourceTypes = {
      local: { icon: '📁', name: 'LOCAL STORAGE' },
      nvr: { icon: '🔗', name: 'NVR/DVR SYSTEM' },
      cloud: { icon: '☁️', name: 'CLOUD STORAGE' }
    };
    return sourceTypes[sourceType] || { icon: '❓', name: 'UNKNOWN' };
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold text-white">🔧 Update Video Source</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white text-2xl"
          >
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Source Type Info */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Source Type
            </label>
            <div className="w-full p-3 border border-gray-600 rounded bg-gray-700 text-white flex items-center">
              <span className="mr-2">{getSourceTypeInfo(source.source_type).icon}</span>
              <span className="font-medium">{getSourceTypeInfo(source.source_type).name}</span>
              <span className="ml-2 text-gray-400 text-sm">(ReadOnly)</span>
            </div>
          </div>

          {/* Path Info */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {source.source_type === 'nvr' ? 'NVR Address' : 'Path'}
            </label>
            <div className="w-full p-3 border border-gray-600 rounded bg-gray-700 text-white break-all">
              {path}
            </div>
          </div>

          {/* NVR Configuration Display */}
          {source.source_type === 'nvr' && source.config && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                NVR Configuration
              </label>
              <div className="p-3 bg-gray-700 rounded space-y-2">
                <div className="text-sm text-gray-300">
                  <strong>Protocol:</strong> {source.config.protocol?.toUpperCase() || 'ONVIF'}
                </div>
                <div className="text-sm text-gray-300">
                  <strong>Username:</strong> {source.config.username || 'Not set'}
                </div>
                <div className="text-sm text-gray-300">
                  <strong>Auto-sync:</strong> {source.config.auto_sync ? 'Enabled' : 'Disabled'}
                </div>
              </div>
            </div>
          )}

          {/* Camera Selection */}
          <div className="mb-4">
            <div className="flex justify-between items-center mb-3">
              <label className="block text-sm font-medium text-gray-300">
                {source.source_type === 'nvr' ? 'Discovered Cameras' : 'Camera Folders'}
              </label>
              <button
                type="button"
                onClick={detectCamerasInPath}
                disabled={isDetecting}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white px-3 py-1 rounded text-xs"
              >
                {isDetecting ? 'Scanning...' : source.source_type === 'nvr' ? 'Rediscover' : 'Rescan'}
              </button>
            </div>
            
            {isDetecting ? (
              <div className="text-center py-4">
                <div className="text-gray-400 text-sm">
                  {source.source_type === 'nvr' ? 'Discovering cameras...' : 'Detecting cameras...'}
                </div>
              </div>
            ) : detectedCameras.length > 0 ? (
              <div className="grid grid-cols-2 gap-2 p-3 bg-gray-700 rounded">
                {detectedCameras.map(camera => (
                  <label key={camera} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedCameras.includes(camera)}
                      onChange={() => handleCameraToggle(camera)}
                      className="rounded"
                    />
                    <span className="text-white text-sm">{camera}</span>
                  </label>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 bg-gray-700 rounded">
                <div className="text-gray-400 text-sm">
                  {source.source_type === 'nvr' ? 'No cameras discovered' : 'No camera folders detected'}
                </div>
              </div>
            )}
            
            {selectedCameras.length > 0 && (
              <div className="mt-2 text-xs text-gray-400">
                Selected: {selectedCameras.length} camera(s)
              </div>
            )}
          </div>

          {/* Test Connection */}
          <div className="mb-4">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isLoading}
              className="bg-yellow-600 hover:bg-yellow-700 disabled:bg-gray-600 text-white px-4 py-2 rounded font-medium"
            >
              {isLoading ? 'Testing...' : 'Test Connection'}
            </button>
            
            {testResult && (
              <div className={`mt-2 p-3 rounded text-sm ${
                testResult.success ? 'bg-green-800 text-green-200' : 'bg-red-800 text-red-200'
              }`}>
                {testResult.message}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded font-medium"
            >
              Save Changes
            </button>
            <button
              type="button"
              onClick={onClose}
              className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded font-medium"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ConfigForm;
```
## 📄 File: `GeneralInfoForm.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/GeneralInfoForm.js`

```javascript
import DatePicker from "react-datepicker";

const GeneralInfoForm = ({
  country,
  setCountry,
  timezone,
  setTimezone,
  brandName,
  setBrandName,
  workingDays,
  setWorkingDays,
  fromTime,
  setFromTime,
  toTime,
  setToTime,
  handleCountryChange,
  handleFromTimeChange,
  handleToTimeChange,
  handleWorkingDayChange,
  handleSaveGeneralInfo,
  countries,
}) => {
  return (
    <div className="w-[25%] bg-gray-800 p-6 rounded-lg flex flex-col">
      <h1 className="text-3xl font-bold mb-4">Thông tin chung</h1>
      <div className="mb-4">
        <label className="block mb-1">Quốc gia:</label>
        <select
          value={country}
          onChange={handleCountryChange}
          className="w-full p-2 rounded bg-gray-700 text-white"
        >
          {countries.map((country) => (
            <option key={country} value={country}>
              {country}
            </option>
          ))}
        </select>
      </div>
      <div className="mb-4">
        <label className="block mb-1">Múi giờ:</label>
        <input
          type="text"
          value={timezone}
          readOnly
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <div className="mb-4">
        <label className="block mb-1">Tên thương hiệu:</label>
        <input
          type="text"
          value={brandName}
          onChange={(e) => setBrandName(e.target.value)}
          placeholder="Nhập tên thương hiệu"
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <div className="mb-4">
        <h3 className="text-lg font-bold mb-2">Ngày làm việc</h3>
        {["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"].map((day) => (
          <label key={day} className="flex items-center mb-2">
            <input
              type="checkbox"
              className="mr-2"
              onChange={() => handleWorkingDayChange(day)}
              checked={workingDays.includes(day)}
            />
            {day}
          </label>
        ))}
      </div>
      <div className="mb-4">
        <h3 className="text-lg font-bold mb-2">Thời gian làm việc</h3>
        <div className="flex gap-4">
          <div className="flex-1">
            <label className="block mb-1">Từ:</label>
            <DatePicker
              selected={fromTime}
              onChange={handleFromTimeChange}
              showTimeSelect
              showTimeSelectOnly
              timeIntervals={30}
              timeCaption="Giờ"
              dateFormat="HH:mm"
              className="w-full p-2 rounded bg-gray-700 text-white"
            />
          </div>
          <div className="flex-1">
            <label className="block mb-1">Đến:</label>
            <DatePicker
              selected={toTime}
              onChange={handleToTimeChange}
              showTimeSelect
              showTimeSelectOnly
              timeIntervals={30}
              timeCaption="Giờ"
              dateFormat="HH:mm"
              className="w-full p-2 rounded bg-gray-700 text-white"
            />
          </div>
        </div>
      </div>
      <div className="mt-auto flex justify-center">
        <button
          onClick={handleSaveGeneralInfo}
          className="w-1/2 py-2 bg-blue-600 text-white font-bold rounded"
        >
          Gửi
        </button>
      </div>
    </div>
  );
};

export default GeneralInfoForm;
```
## 📄 File: `ProcessingRegionForm.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/ProcessingRegionForm.js`

```javascript
import { useState, useEffect } from "react";
import api from "../../api";
import InstructionsPanel from "./InstructionsPanel";

const ProcessingRegionForm = ({ handleAnalyzeRegions }) => {
  const [videoPath, setVideoPath] = useState("");
  const [selectedVideoPath, setSelectedVideoPath] = useState("");
  const [error, setError] = useState("");
  const [analysisResult, setAnalysisResult] = useState(null);
  const [roiFramePath, setRoiFramePath] = useState("");
  const [showResultModal, setShowResultModal] = useState(false);
  const [cameraList, setCameraList] = useState([]);
  const [selectedCamera, setSelectedCamera] = useState("");
  const [processedCameras, setProcessedCameras] = useState([]);

  useEffect(() => {
    handleGetCameras();
  }, []);

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      const path = file.path || file.name;
      setVideoPath(path);
      setSelectedVideoPath(path);
      setError("");
    } else {
      setVideoPath("");
      setSelectedVideoPath("");
    }
  };

  const handleGetCameras = async () => {
    try {
      const response = await api.get("/get-cameras");
      setCameraList(response.data.cameras || []);
      setError("");
    } catch (err) {
      setError("Không thể lấy danh sách camera.");
    }
  };

  const handleSelectCamera = (camera) => {
    setSelectedCamera(camera);
    setVideoPath("");
    setSelectedVideoPath("");
    setError("");
  };

  const handleContinue = async () => {
    if (!videoPath && !selectedVideoPath) {
      setError("Vui lòng chọn video baseline.");
      return;
    }
    if (!selectedCamera) {
      setError("Vui lòng chọn một camera.");
      return;
    }
    try {
      const response = await fetch('http://127.0.0.1:8080/run-select-roi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoPath: selectedVideoPath || videoPath, cameraId: selectedCamera })
      });
      const result = await response.json();
      console.log("Result from run-select-roi:", result);
      if (result.success) {
        const newAnalysisResult = {
          success: true,
          message: result.message || "Hand detection completed successfully",
          roi: result.roi,
          hand_detected: result.hand_detected,
          roi_frame: result.roi_frame
        };
        console.log("Setting analysisResult in handleContinue:", newAnalysisResult);
        setAnalysisResult(newAnalysisResult);
        setRoiFramePath(result.roi_frame); // Lưu roiFramePath
        setShowResultModal(true);
      } else {
        setError(result.error || "Không thể chạy hand detection.");
      }
    } catch (err) {
      setError("Lỗi khi chạy hand detection: " + err.message);
    }
  };

  const handleRetry = async () => {
    if (!selectedVideoPath && !videoPath) {
      setError("Vui lòng chọn video baseline.");
      return;
    }
    try {
      const response = await fetch('http://127.0.0.1:8080/run-select-roi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoPath: selectedVideoPath || videoPath, cameraId: selectedCamera })
      });
      const result = await response.json();
      console.log("Result from run-select-roi (retry):", result);
      if (result.success) {
        const newAnalysisResult = {
          success: true,
          message: result.message || "Hand detection completed successfully",
          roi: result.roi,
          hand_detected: result.hand_detected,
          roi_frame: result.roi_frame
        };
        console.log("Setting analysisResult in handleRetry:", newAnalysisResult);
        setAnalysisResult(newAnalysisResult);
        setRoiFramePath(result.roi_frame); // Cập nhật roiFramePath với file mới nhất
        setShowResultModal(true);
      } else {
        setError(result.error || "Không thể chạy hand detection.");
      }
    } catch (err) {
      setError("Lỗi khi chạy hand detection: " + err.message);
    }
  };

  const handleRoisSubmit = (rois) => {
    setProcessedCameras((prev) => [...new Set([...prev, selectedCamera])]);
    setSelectedCamera("");
  };

  const handleContinueWithAnotherCamera = () => {
    setAnalysisResult(null);
    setRoiFramePath("");
    setShowResultModal(false);
    setSelectedCamera("");
    setVideoPath("");
    setSelectedVideoPath("");
    setError("");
  };

  const handleExit = () => {
    setShowResultModal(false);
    handleAnalyzeRegions({
      success: true,
      message: "Đã hoàn tất xử lý các camera.",
      processedCameras,
    });
  };

  return (
    <div className="w-[25%] bg-gray-800 p-6 rounded-lg flex flex-col">
      <h1 className="text-3xl font-bold mb-4">Vùng xử lý</h1>
      <p className="text-gray-300 mb-4">
        Tải lên video baseline (5s-5 phút) để xác định các vùng xử lý QR và đóng gói.
      </p>
      <div className="mb-4">
        <button
          onClick={handleGetCameras}
          className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded"
        >
          Lấy danh sách camera
        </button>
      </div>
      {cameraList && cameraList.length > 0 && (
        <div className="mb-4">
          <h3 className="text-lg font-bold mb-2">Chọn camera:</h3>
          <div className="max-h-24 overflow-y-auto">
            {cameraList.map((camera) => (
              <label key={camera} className="flex items-center mb-2">
                <input
                  type="radio"
                  name="camera"
                  className="mr-2"
                  checked={selectedCamera === camera}
                  onChange={() => handleSelectCamera(camera)}
                  disabled={processedCameras.includes(camera)}
                />
                {camera}
                {processedCameras.includes(camera) && (
                  <span className="ml-2 text-green-500">✔ Đã xử lý</span>
                )}
              </label>
            ))}
          </div>
        </div>
      )}
      <div className="mb-4">
        <label className="block mb-1">Video baseline:</label>
        <div className="relative w-full">
          <input
            type="text"
            value={videoPath}
            onChange={(e) => {
              setVideoPath(e.target.value);
              setSelectedVideoPath(e.target.value);
            }}
            placeholder="Chọn video (e.g., /Users/annhu/vtrack_app/V_Track/baseline.mp4)"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
          <button
            type="button"
            onClick={() => {
              const input = document.createElement("input");
              input.type = "file";
              input.accept = "video/*";
              input.onchange = handleFileSelect;
              input.click();
            }}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
          >
            ...
          </button>
        </div>
      </div>
      {videoPath && selectedCamera && (
        <div className="mb-4 flex justify-center">
          <button
            onClick={handleContinue}
            className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded"
          >
            Tiếp tục
          </button>
        </div>
      )}
      {showResultModal && analysisResult && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg w-3/4 h-3/4 flex">
            <InstructionsPanel
              customInstruction={
                analysisResult.qr_detected
                  ? "Tiếp tục xác định vùng trigger."
                  : "Vẽ lại vùng mã vận đơn hoặc nhấn Tiếp tục để đồng ý với vùng hiện tại."
              }
              analysisResult={analysisResult}
              handDetected={analysisResult.hand_detected}
              qrDetected={analysisResult.qr_detected}
              onClose={handleExit}
              onSave={handleContinueWithAnotherCamera}
              onRetry={handleRetry}
              errorMessage={error}
              videoPath={selectedVideoPath || videoPath}
              cameraId={selectedCamera}
              onSubmit={handleRoisSubmit}
              setAnalysisResult={setAnalysisResult}
              roiFramePath={roiFramePath}
            />
          </div>
        </div>
      )}
      {error && (
        <div className="mb-4 text-red-500 text-sm">{error}</div>
      )}
    </div>
  );
};

export default ProcessingRegionForm;

```
## 📄 File: `AddSourceModal.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/AddSourceModal.js`

```javascript
// components/config/AddSourceModal.js - Fixed ZoneMinder Auth
import React, { useState } from 'react';

const AddSourceModal = ({ show, onClose, onAdd, testSourceConnection }) => {
  const [sourceType, setSourceType] = useState('local');
  const [path, setPath] = useState('');
  const [config, setConfig] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState(null);
  
  // 🆕 NVR-specific states
  const [nvrCameras, setNvrCameras] = useState([]);
  const [selectedNvrCameras, setSelectedNvrCameras] = useState([]);
  const [isDiscoveringCameras, setIsDiscoveringCameras] = useState(false);

  const generateSourceName = (path, sourceType) => {
    if (!path) return '';
    
    if (sourceType === 'nvr') {
      // Extract hostname or IP from URL
      try {
        const url = new URL(path.startsWith('http') ? path : `http://${path}`);
        const hostname = url.hostname || path;
        return `nvr_${hostname.replace(/\./g, '_')}`;
      } catch {
        const cleanPath = path.replace(/[^\w\d]/g, '_');
        return `nvr_${cleanPath}`;
      }
    } else {
      const folderName = path.split('/').pop() || path.split('\\').pop() || 'source';
      return `${sourceType}_${folderName}`;
    }
  };

  const resetForm = () => {
    setSourceType('local');
    setPath('');
    setConfig({});
    setTestResult(null);
    setNvrCameras([]);
    setSelectedNvrCameras([]);
  };

  // 🔧 FIXED: Enhanced validation - ZM credentials optional
  const validateNvrConfig = () => {
    if (!config.url) {
      return { valid: false, message: 'Please enter NVR address first' };
    }
    
    // 🆕 For ZoneMinder, credentials are optional
    if (config.protocol === 'zoneminder') {
      return { valid: true, message: 'Ready to test (ZM auth optional)' };
    }
    
    // For other protocols, credentials required
    if (!config.username || !config.password) {
      return { valid: false, message: 'Please fill in username and password for this protocol' };
    }
    
    return { valid: true, message: 'Ready to test' };
  };

  const handleTestConnection = async () => {
    if (sourceType === 'local' && !path) {
      alert('Please enter a path first');
      return;
    }

    // 🔧 FIXED: Use enhanced validation
    if (sourceType === 'nvr') {
      const validation = validateNvrConfig();
      if (!validation.valid) {
        alert(validation.message);
        return;
      }
    }

    if (sourceType === 'cloud') {
      alert('Cloud storage not implemented yet');
      return;
    }

    setIsLoading(true);
    setIsDiscoveringCameras(true);
    setTestResult(null);
    setNvrCameras([]);
    
    try {
      const testData = {
        source_type: sourceType,
        path: sourceType === 'local' ? path : config.url,
        config: sourceType === 'nvr' ? {
          ...config,
          protocol: config.protocol || 'zoneminder',
          // 🆕 Send empty credentials if not provided for ZM
          username: config.username || '',
          password: config.password || ''
        } : config
      };

      const response = await testSourceConnection(testData);
      
      setTestResult({
        success: response.accessible,
        message: response.message
      });

      // 🆕 Handle NVR camera discovery
      if (response.accessible && sourceType === 'nvr' && response.cameras) {
        setNvrCameras(response.cameras);
        // Auto-select all discovered cameras by default
        setSelectedNvrCameras(response.cameras.map(cam => cam.name || cam.id || `Camera ${response.cameras.indexOf(cam) + 1}`));
        
        setTestResult(prev => ({
          ...prev,
          message: `${prev.message} - Found ${response.cameras.length} camera(s)`
        }));
      }
      
    } catch (error) {
      setTestResult({
        success: false,
        message: error.message || 'Connection test failed'
      });
    } finally {
      setIsLoading(false);
      setIsDiscoveringCameras(false);
    }
  };

  // 🆕 NVR Camera Selection Handler
  const handleNvrCameraToggle = (cameraName) => {
    setSelectedNvrCameras(prev => 
      prev.includes(cameraName) 
        ? prev.filter(name => name !== cameraName)
        : [...prev, cameraName]
    );
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (sourceType === 'local' && !path) {
      alert('Please enter a path');
      return;
    }
    
    // 🔧 FIXED: Use enhanced validation for submit too
    if (sourceType === 'nvr') {
      const validation = validateNvrConfig();
      if (!validation.valid) {
        alert(validation.message);
        return;
      }
    }

    if (sourceType === 'cloud') {
      alert('Cloud storage integration coming soon!');
      return;
    }

    const autoName = sourceType === 'local' 
      ? generateSourceName(path, sourceType)
      : generateSourceName(config.url || 'nvr', sourceType);

    const newSource = {
      source_type: sourceType,
      name: autoName,
      path: sourceType === 'local' ? path : config.url,
      config: sourceType === 'nvr' ? {
        ...config,
        protocol: config.protocol || 'zoneminder',
        // 🆕 Include empty credentials for ZM if not provided
        username: config.username || '',
        password: config.password || '',
        detected_cameras: nvrCameras,
        selected_cameras: selectedNvrCameras
      } : {}
    };

    onAdd(newSource);
    resetForm();
    onClose();
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-4xl mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-white">Add New Video Source</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white text-2xl"
          >
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Source Type Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
            
            {/* Local Storage Card */}
            <div 
              className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                sourceType === 'local' 
                  ? 'border-blue-500 bg-blue-900' 
                  : 'border-gray-600 bg-gray-700 hover:border-gray-500'
              }`}
              onClick={() => setSourceType('local')}
            >
              <div className="flex items-center mb-3">
                <span className="text-3xl mr-3">📁</span>
                <div>
                  <h4 className="font-semibold text-white text-lg">Browse Files Directly</h4>
                  <p className="text-sm text-gray-300">Access folders containing videos</p>
                </div>
              </div>
              <div className="text-xs text-gray-400 leading-relaxed">
                • Local server folders<br/>
                • Mounted network drives (NAS, SMB, NFS)<br/>
                • Mounted NVR file shares<br/>
                • Any accessible folder path<br/>
                <span className="text-yellow-300 font-medium">📍 Mount network sources first</span>
              </div>
            </div>

            {/* NVR/DVR Card - Enhanced */}
            <div 
              className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                sourceType === 'nvr' 
                  ? 'border-blue-500 bg-blue-900' 
                  : 'border-gray-600 bg-gray-700 hover:border-gray-500'
              }`}
              onClick={() => setSourceType('nvr')}
            >
              <div className="flex items-center mb-3">
                <span className="text-3xl mr-3">🔗</span>
                <div>
                  <h4 className="font-semibold text-white text-lg">Connect & Auto-Download</h4>
                  <p className="text-sm text-gray-300">Direct NVR/DVR camera discovery</p>
                </div>
              </div>
              <div className="text-xs text-gray-400 leading-relaxed">
                • NVR/DVR systems (ONVIF)<br/>
                • IP Camera networks (RTSP)<br/>
                • Security management platforms<br/>
                • Auto-discover cameras<br/>
                <span className="text-green-300 font-medium">🔄 Real-time camera detection</span>
              </div>
            </div>

            {/* Cloud Storage Card */}
            <div 
              className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                sourceType === 'cloud' 
                  ? 'border-blue-500 bg-blue-900' 
                  : 'border-gray-600 bg-gray-700 hover:border-gray-500'
              }`}
              onClick={() => setSourceType('cloud')}
            >
              <div className="flex items-center mb-3">
                <span className="text-3xl mr-3">☁️</span>
                <div>
                  <h4 className="font-semibold text-white text-lg">Sync Cloud Storage</h4>
                  <p className="text-sm text-gray-300">Connect online storage accounts</p>
                </div>
              </div>
              <div className="text-xs text-gray-400 leading-relaxed">
                • Google Drive integration<br/>
                • Dropbox synchronization<br/>
                • OneDrive access<br/>
                • Cloud camera platforms<br/>
                <span className="text-yellow-400 font-medium">🚧 Available in future updates</span>
              </div>
            </div>
          </div>

          {/* Local Files Form */}
          {sourceType === 'local' && (
            <div className="bg-gray-700 rounded-lg p-6 mb-6">
              <h4 className="font-semibold text-white mb-4 text-lg">📁 Browse Files Directly Configuration</h4>
              
              <div className="bg-yellow-800 border border-yellow-600 rounded-lg p-4 mb-6">
                <div className="text-yellow-200">
                  <div className="font-semibold mb-2">📍 Network Storage Setup Guide:</div>
                  <div className="text-sm mb-2">For network sources (NAS, NVR file shares), mount them first:</div>
                  <div className="font-mono text-xs bg-black bg-opacity-30 p-2 rounded">
                    # SMB Example (NAS/NVR):<br/>
                    mount -t smbfs //server/share /mnt/folder<br/><br/>
                    # NFS Example:<br/>
                    mount -t nfs server:/export /mnt/folder
                  </div>
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Folder Path *
                </label>
                <input
                  type="text"
                  value={path}
                  onChange={(e) => setPath(e.target.value)}
                  placeholder="/Users/videos or /mnt/nas-storage or /mnt/nvr-files"
                  className="w-full p-3 border border-gray-600 rounded-lg bg-gray-800 text-white text-sm"
                  required
                />
                <div className="text-xs text-gray-400 mt-2">
                  Local path or mounted network folder containing camera subfolders
                </div>
              </div>

              {path && (
                <div className="bg-gray-600 p-4 rounded-lg">
                  <div className="text-xs text-gray-400 mb-1">Auto-generated source name:</div>
                  <div className="text-lg text-white font-medium">{generateSourceName(path, sourceType)}</div>
                </div>
              )}
            </div>
          )}

          {/* 🆕 Enhanced NVR/DVR Form - FIXED AUTH */}
          {sourceType === 'nvr' && (
            <div className="bg-gray-700 rounded-lg p-6 mb-6">
              <h4 className="font-semibold text-white mb-4 text-lg">🔗 NVR/DVR Connection Configuration</h4>

              {/* Protocol & URL Row */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Protocol *
                  </label>
                  <select
                    value={config.protocol || 'zoneminder'}
                    onChange={(e) => setConfig(prev => ({...prev, protocol: e.target.value}))}
                    className="w-full p-3 border border-gray-600 rounded-lg bg-gray-800 text-white"
                    required
                  >
                    <option value="zoneminder">ZoneMinder API (Open Source NVR)</option>
                    <option value="onvif">ONVIF (Universal Standard)</option>
                    <option value="rtsp">RTSP Direct Stream</option>
                    <option value="hikvision">Hikvision API</option>
                    <option value="dahua">Dahua API</option>
                    <option value="generic">Generic HTTP API</option>
                  </select>
                  <div className="text-xs text-gray-400 mt-1">
                    ZoneMinder recommended for open source NVR systems
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    NVR/DVR Address *
                  </label>
                  <input
                    type="text"
                    value={config.url || ''}
                    onChange={(e) => setConfig(prev => ({...prev, url: e.target.value}))}
                    placeholder="localhost:5050 or 192.168.1.100:8080"
                    className="w-full p-3 border border-gray-600 rounded-lg bg-gray-800 text-white"
                    required
                  />
                  <div className="text-xs text-gray-400 mt-1">
                    IP address or hostname (port optional)
                  </div>
                </div>
              </div>

              {/* 🔧 FIXED: Conditional Credentials Section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Username {config.protocol === 'zoneminder' ? '(Optional)' : '*'}
                  </label>
                  <input
                    type="text"
                    value={config.username || ''}
                    onChange={(e) => setConfig(prev => ({...prev, username: e.target.value}))}
                    placeholder={config.protocol === 'zoneminder' ? 'admin (leave blank if no auth)' : 'admin'}
                    className="w-full p-3 border border-gray-600 rounded-lg bg-gray-800 text-white"
                    required={config.protocol !== 'zoneminder'}
                  />
                  {config.protocol === 'zoneminder' && (
                    <div className="text-xs text-green-300 mt-1">
                      ✅ ZoneMinder auth is optional - can be left blank
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Password {config.protocol === 'zoneminder' ? '(Optional)' : '*'}
                  </label>
                  <input
                    type="password"
                    value={config.password || ''}
                    onChange={(e) => setConfig(prev => ({...prev, password: e.target.value}))}
                    placeholder={config.protocol === 'zoneminder' ? '••••••••  (leave blank if no auth)' : '••••••••'}
                    className="w-full p-3 border border-gray-600 rounded-lg bg-gray-800 text-white"
                    required={config.protocol !== 'zoneminder'}
                  />
                  {config.protocol === 'zoneminder' && (
                    <div className="text-xs text-green-300 mt-1">
                      ✅ ZoneMinder auth is optional - can be left blank
                    </div>
                  )}
                </div>
              </div>

              {/* 🆕 ZoneMinder Auth Hint */}
              {config.protocol === 'zoneminder' && (
                <div className="mb-6 p-4 bg-green-800 border border-green-600 rounded-lg">
                  <div className="text-green-200 text-sm">
                    <div className="font-semibold mb-2">💡 ZoneMinder Authentication:</div>
                    <div className="text-xs">
                      • <strong>Leave blank:</strong> If ZM has authentication disabled (most common)<br/>
                      • <strong>Fill in:</strong> If ZM requires login credentials<br/>
                      • <strong>Try both:</strong> Test will show which method works
                    </div>
                  </div>
                </div>
              )}

              {/* Advanced Options */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-3">
                  <label className="text-sm font-medium text-gray-300">Advanced Options</label>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Custom Port</label>
                    <input
                      type="number"
                      value={config.port || ''}
                      onChange={(e) => setConfig(prev => ({...prev, port: e.target.value}))}
                      placeholder="80, 8080, 554..."
                      className="w-full p-2 border border-gray-600 rounded bg-gray-800 text-white text-sm"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Connection Timeout (sec)</label>
                    <input
                      type="number"
                      value={config.timeout || 10}
                      onChange={(e) => setConfig(prev => ({...prev, timeout: parseInt(e.target.value)}))}
                      min="5"
                      max="60"
                      className="w-full p-2 border border-gray-600 rounded bg-gray-800 text-white text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Auto-sync Option */}
              <div className="mb-6">
                <label className="flex items-center p-3 bg-gray-600 rounded-lg cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.auto_sync || false}
                    onChange={(e) => setConfig(prev => ({...prev, auto_sync: e.target.checked}))}
                    className="mr-3"
                  />
                  <div>
                    <span className="text-sm text-gray-300 font-medium">Enable automatic video synchronization</span>
                    <div className="text-xs text-gray-400">Download new recordings automatically in background</div>
                  </div>
                </label>
              </div>

              {/* 🆕 Discovered Cameras Section */}
              {testResult?.success && nvrCameras.length > 0 && (
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <h5 className="font-medium text-white">📹 Discovered Cameras ({nvrCameras.length})</h5>
                    {isDiscoveringCameras && (
                      <div className="text-xs text-blue-300">Discovering cameras...</div>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-4 bg-gray-600 rounded-lg max-h-48 overflow-y-auto">
                    {nvrCameras.map((camera, index) => {
                      const cameraName = camera.name || camera.id || `Camera ${index + 1}`;
                      
                      return (
                        <label 
                          key={cameraName}
                          className="flex items-start space-x-3 p-2 bg-gray-700 rounded cursor-pointer hover:bg-gray-650"
                        >
                          <input
                            type="checkbox"
                            checked={selectedNvrCameras.includes(cameraName)}
                            onChange={() => handleNvrCameraToggle(cameraName)}
                            className="mt-1"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="text-white text-sm font-medium truncate">
                              {cameraName}
                            </div>
                            {camera.stream_url && (
                              <div className="text-xs text-gray-400 truncate">
                                {camera.stream_url}
                              </div>
                            )}
                            {camera.resolution && (
                              <div className="text-xs text-blue-300">
                                {camera.resolution} • {camera.codec || 'H264'}
                              </div>
                            )}
                          </div>
                        </label>
                      );
                    })}
                  </div>
                  
                  <div className="mt-2 text-xs text-gray-400">
                    Selected: {selectedNvrCameras.length} of {nvrCameras.length} cameras
                  </div>
                </div>
              )}

              {/* Source Name Preview */}
              {config.url && (
                <div className="bg-gray-600 p-4 rounded-lg">
                  <div className="text-xs text-gray-400 mb-1">Auto-generated source name:</div>
                  <div className="text-lg text-white font-medium">{generateSourceName(config.url, sourceType)}</div>
                </div>
              )}
            </div>
          )}

          {/* Cloud Storage Form */}
          {sourceType === 'cloud' && (
            <div className="bg-gray-700 rounded-lg p-6 mb-6">
              <h4 className="font-semibold text-white mb-4 text-lg">☁️ Sync Cloud Storage Configuration</h4>
              
              <div className="bg-blue-800 border border-blue-600 rounded-lg p-6 text-center">
                <div className="text-blue-200 text-xl font-medium mb-3">🚧 Coming Soon</div>
                <div className="text-blue-300">
                  Cloud storage integration will be available in future updates.<br/>
                  <strong>Temporary solution:</strong> Download cloud files locally and use "Browse Files Directly".
                </div>
              </div>
            </div>
          )}

          {/* Test Connection */}
          <div className="mb-6">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isLoading || 
                (sourceType === 'local' && !path) || 
                (sourceType === 'nvr' && !validateNvrConfig().valid) ||
                sourceType === 'cloud'
              }
              className="bg-yellow-600 hover:bg-yellow-700 disabled:bg-gray-600 text-white px-6 py-3 rounded-lg font-medium mr-4"
            >
              {isLoading ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  {sourceType === 'nvr' ? 'Discovering Cameras...' : 'Testing...'}
                </span>
              ) : (
                'Test Connection'
              )}
            </button>
            
            {testResult && (
              <div className={`inline-block p-4 rounded-lg text-sm ${
                testResult.success 
                  ? 'bg-green-800 text-green-200 border border-green-600' 
                  : 'bg-red-800 text-red-200 border border-red-600'
              }`}>
                <div className="font-medium mb-1">
                  {testResult.success ? '✅ Connection Successful' : '❌ Connection Failed'}
                </div>
                <div>{testResult.message}</div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-4 border-t border-gray-600">
            <button
              type="submit"
              disabled={!testResult?.success}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-8 py-3 rounded-lg font-medium flex-1"
            >
              Add Source
            </button>
            <button
              type="button"
              onClick={() => {
                resetForm();
                onClose();
              }}
              className="bg-gray-600 hover:bg-gray-700 text-white px-8 py-3 rounded-lg font-medium flex-1"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddSourceModal;
```
## 📄 File: `InstructionsPanel.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/InstructionsPanel.js`

```javascript
import React, { useState, useEffect } from 'react';
import { getFinalRoiFrame } from "../../api";

const InstructionsPanel = ({
  step,
  customInstruction,
  analysisResult,
  errorMessage,
  onSave,
  onClose,
  onRetry,
  handDetected,
  videoPath,
  cameraId,
  onSubmit,
  setAnalysisResult,
  roiFramePath,
}) => {
  const [roiFrameSrc, setRoiFrameSrc] = useState(null);
  const [finalRoiFrameSrc, setFinalRoiFrameSrc] = useState(null);
  const [rois, setRois] = useState([]);
  const [internalError, setInternalError] = useState("");
  const [currentStep, setCurrentStep] = useState("packing");
  const [roiImageState, setRoiImageState] = useState({
    step: "packing",
    file: "roi_packing.jpg",
    ready: false,
  });
  const [imageAspectRatio, setImageAspectRatio] = useState(null);

  const loadRoiImage = async (fileSuffix, retryCount = 0, maxRetries = 3) => {
    try {
      if (!cameraId) {
        console.error("Missing cameraId", { cameraId });
        setInternalError("Thiếu cameraId.");
        return;
      }

      console.log(`Loading ROI image with camera_id: ${cameraId}, file: ${fileSuffix}`);
      const timestamp = new Date().getTime();
      const url = `http://localhost:8080/get-roi-frame?camera_id=${cameraId}&file=${fileSuffix}&t=${timestamp}`;
      const response = await fetch(url, {
        headers: { 'Cache-Control': 'no-cache' },
      });
      if (!response.ok && response.status !== 304) {
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }
      console.log("Response from /get-roi-frame:", response);
      setRoiFrameSrc(url);
      setRoiImageState({ step: currentStep, file: fileSuffix, ready: true });
      console.log("roiFrameSrc updated to:", url);
    } catch (error) {
      console.error("Error loading ROI image:", error);
      if (retryCount < maxRetries) {
        console.log(`Retrying loadRoiImage (${retryCount + 1}/${maxRetries})...`);
        setTimeout(() => loadRoiImage(fileSuffix, retryCount + 1, maxRetries), 500);
      } else {
        setInternalError(`Không thể tải ảnh tạm: ${error.message}. Vui lòng thử lại.`);
      }
    }
  };

  useEffect(() => {
    console.log("useEffect triggered with analysisResult:", analysisResult, "currentStep:", currentStep, "roiImageState:", roiImageState);
    if (analysisResult && analysisResult.roi_frame && roiImageState.ready) {
      loadRoiImage(roiImageState.file);
    } else if (currentStep === "packing" && analysisResult?.roi_frame) {
      loadRoiImage("roi_packing.jpg");
    }
  }, [analysisResult, currentStep, roiImageState.ready]);

  const fetchFinalRoiFrame = async () => {
    try {
      console.log(`Calling /get-final-roi-frame with camera_id: ${cameraId}`);
      const timestamp = new Date().getTime();
      const url = `http://localhost:8080/get-final-roi-frame?camera_id=${cameraId}&t=${timestamp}`;
      const response = await fetch(url, {
        headers: { 'Cache-Control': 'no-cache' },
      });
      if (!response.ok && response.status !== 304) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      console.log("Response from /get-final-roi-frame:", response);
      setFinalRoiFrameSrc(url);
    } catch (error) {
      console.error("Error fetching final ROI frame:", error);
      setInternalError("Không thể tải ảnh tổng hợp. Vui lòng thử lại.");
    }
  };

  const handleConfirmRoi = async () => {
    if (currentStep === "packing" && analysisResult?.roi) {
      if (!analysisResult || typeof analysisResult.hand_detected === "undefined") {
        setInternalError("Không tìm thấy thông tin phát hiện tay từ backend. Vui lòng thử lại.");
        return;
      }
      if (!analysisResult.hand_detected) {
        setInternalError("Không phát hiện tay. Vui lòng vẽ lại vùng packing hoặc thoát.");
        return;
      }
      if (!analysisResult.roi_frame) {
        setInternalError("Thiếu đường dẫn ảnh tạm packing. Vui lòng thử lại.");
        return;
      }

      const newRoi = { type: currentStep, ...analysisResult.roi };
      const updatedRois = [...rois, newRoi];
      setRois(updatedRois);
      setCurrentStep("mvd");
      setRoiImageState({ step: "mvd", file: "roi_packing.jpg", ready: true });
      try {
        console.log("Calling /run-qr-detector for mvd step with videoPath:", videoPath, "cameraId:", cameraId, "roiFramePath:", analysisResult.roi_frame);
        const response = await fetch('http://localhost:8080/run-qr-detector', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ videoPath, cameraId, roiFramePath: analysisResult.roi_frame }),
        });
        const result = await response.json();
        console.log("Result from /run-qr-detector (mvd):", result);
        if (result.success) {
          const tempResult = {
            success: true,
            message: result.message || "QR detection completed successfully",
            rois: result.rois,
            qr_detected: result.qr_detected,
            qr_detected_roi1: result.qr_detected_roi1,
            qr_detected_roi2: result.qr_detected_roi2,
            roi_frame: result.roi_frame,
            qr_content: result.qr_content,
            trigger_detected: result.trigger_detected,
            table_type: result.table_type,
          };
        
          if (result.roi_frame) {
            setRoiImageState({ step: "mvd", file: "roi_MVD.jpg", ready: true });
            await loadRoiImage("roi_MVD.jpg");
            setAnalysisResult(tempResult); // Chỉ set sau khi ảnh tải xong
          } else {
            console.log("No roi_frame in result, keeping roi_packing.jpg");
            setAnalysisResult(tempResult);
          }
        } else {
          setInternalError(result.error || "Không thể vẽ vùng mã vận đơn.");
        }
      } catch (error) {
        setInternalError("Lỗi khi vẽ vùng mã vận đơn: " + error.message);
      }
    } else if (currentStep === "mvd" && analysisResult?.rois) {
      if (!analysisResult || typeof analysisResult.qr_detected === "undefined") {
        setInternalError("Không tìm thấy thông tin phát hiện QR từ backend. Vui lòng thử lại.");
        return;
      }
      if (!analysisResult.qr_detected) {
        setInternalError("Không phát hiện mã QR. Vui lòng vẽ lại vùng MVD hoặc thoát.");
        return;
      }
      if (!analysisResult.roi_frame) {
        setInternalError("Thiếu đường dẫn ảnh tạm MVD. Vui lòng thử lại.");
        return;
      }

      const newRois = analysisResult.rois.map((roi) => ({ type: currentStep, ...roi }));
      const updatedRois = [...rois, ...newRois];
      setRois(updatedRois);
      setCurrentStep("done");
      try {
        const response = await fetch('http://localhost:8080/finalize-roi', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ videoPath, cameraId, rois: updatedRois }),
        });
        const result = await response.json();
        if (result.success) {
          await fetchFinalRoiFrame();
          onSubmit(updatedRois);
          onSave();
        } else {
          setInternalError(result.error || "Không thể tạo ảnh tổng hợp.");
        }
      } catch (error) {
        setInternalError("Lỗi khi tạo ảnh tổng hợp: " + error.message);
      }
    }
    if (currentStep === "done") {
      onSave();
    }
  };

  const handleRetryStep = async () => {
    if (!videoPath || !cameraId) {
      setInternalError("Thiếu videoPath hoặc cameraId.");
      return;
    }

    try {
      if (currentStep === "packing") {
        console.log("Calling /run-select-roi for retry with videoPath:", videoPath, "cameraId:", cameraId);
        const response = await fetch('http://localhost:8080/run-select-roi', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ videoPath, cameraId }),
        });
        const result = await response.json();
        console.log("Result from /run-select-roi (retry):", result);
        if (result.success) {
          const newAnalysisResult = {
            success: true,
            message: result.message || "Hand detection completed successfully",
            roi: result.roi,
            hand_detected: result.hand_detected,
            roi_frame: result.roi_frame,
          };
          setAnalysisResult(newAnalysisResult);
          if (result.roi_frame) {
            setRoiImageState({ step: "packing", file: "roi_packing.jpg", ready: true });
            await loadRoiImage("roi_packing.jpg");
          }
        } else {
          setInternalError(result.error || `Không thể chạy lại hand detection.`);
        }
      } else if (currentStep === "mvd") {
        console.log("Calling /run-qr-detector for retry with videoPath:", videoPath, "cameraId:", cameraId, "roiFramePath:", analysisResult.roi_frame);
        const response = await fetch('http://localhost:8080/run-qr-detector', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ videoPath, cameraId, roiFramePath: analysisResult.roi_frame }),
        });
        const result = await response.json();
        console.log("Result from /run-qr-detector (retry):", result);
        if (result.success) {
          const newAnalysisResult = {
            success: true,
            message: result.message || "QR detection completed successfully",
            rois: result.rois,
            qr_detected: result.qr_detected,
            qr_detected_roi1: result.qr_detected_roi1,
            qr_detected_roi2: result.qr_detected_roi2,
            qr_content: result.qr_content,
            roi_frame: result.roi_frame,
            trigger_detected: result.trigger_detected,
            table_type: result.table_type,
          };
          setAnalysisResult(newAnalysisResult);
          if (result.roi_frame && result.qr_detected) {
            setRoiImageState({ step: "mvd", file: "roi_MVD.jpg", ready: true });
            await loadRoiImage("roi_MVD.jpg");
          } else {
            setInternalError("Không thể tải ảnh hoặc không phát hiện QR.");
          }
        } else {
          setInternalError(result.error || `Không thể chạy lại QR detection.`);
        }
      }
    } catch (error) {
      setInternalError(`Lỗi khi chạy lại: ${error.message}`);
    }
  };

  const handleImageLoad = (e) => {
    const { width, height } = e.target;
    setImageAspectRatio(width / height);
  };

  return (
    <div className="flex w-full h-full">
      <div className="w-1/4 pr-4 flex flex-col border-r-2 border-gray-500">
        <div className="mb-4">
          <h3 className="text-2xl font-bold mb-2 text-white">Kết quả</h3>
          {currentStep === "mvd" ? (
            <>
              {analysisResult?.table_type === "standard" ? (
                <>
                  <div className={`p-2 rounded text-white flex items-center ${analysisResult?.trigger_detected ? 'bg-green-600' : 'bg-red-600'}`}>
                    <span className="mr-2">{analysisResult?.trigger_detected ? '✔' : '✘'}</span>
                    <p>ROI Trigger: {analysisResult?.trigger_detected ? 'Có' : 'Không'}</p>
                  </div>
                  <div className={`p-2 rounded text-white flex items-center mt-2 ${analysisResult?.qr_detected_roi1 ? 'bg-green-600' : 'bg-red-600'}`}>
                    <span className="mr-2">{analysisResult?.qr_detected_roi1 ? '✔' : '✘'}</span>
                    <p>ROI MVD: {analysisResult?.qr_detected_roi1 ? 'Có' : 'Không'}</p>
                  </div>
                </>
              ) : (
                <>
                  {typeof analysisResult?.qr_detected_roi1 !== 'undefined' && (
                    <div className={`p-2 rounded text-white flex items-center ${analysisResult?.qr_detected_roi1 ? 'bg-green-600' : 'bg-red-600'}`}>
                      <span className="mr-2">{analysisResult?.qr_detected_roi1 ? '✔' : '✘'}</span>
                      <p>ROI 1: {analysisResult?.qr_detected_roi1 ? 'Có' : 'Không'}</p>
                    </div>
                  )}
                </>
              )}
            </>
          ) : (
            <div className={`p-2 rounded text-white flex items-center ${handDetected ? 'bg-green-600' : 'bg-red-600'}`}>
              <span className="mr-2">{handDetected ? '✔' : '✘'}</span>
              <p>{handDetected ? `Xác nhận vùng ${currentStep}` : 'Không phát hiện chuyển động'}</p>
            </div>
          )}
          {errorMessage && (
            <div className="mt-2 p-2 bg-red-600 rounded text-white">
              <p>{errorMessage}</p>
            </div>
          )}
          {internalError && (
            <div className="mt-2 p-2 bg-red-600 rounded text-white">
              <p>{internalError}</p>
            </div>
          )}
        </div>
        <div className="mb-4 flex-1">
          <h3 className="text-xl font-bold mb-2 text-white">Hướng dẫn</h3>
          <p className="text-gray-300 text-lg">
            {currentStep === "done"
              ? "Đã hoàn tất vẽ vùng và phát hiện mã QR. Nhấn Thoát để tiếp tục."
              : currentStep === "mvd"
                ? analysisResult?.qr_detected
                  ? "Đã tìm thấy mã QR. Nhấn Hoàn tất để lưu và tiếp tục."
                  : "Vẽ lại vùng mã vận đơn hoặc thoát."
                : handDetected
                  ? "Tiếp tục xác định vùng mã vận đơn."
                  : "Vẽ lại vùng packing hoặc thoát."}
          </p>
        </div>
        <div className="mt-auto space-y-2">
          {currentStep !== "done" && (
            <button
              onClick={handleRetryStep}
              className="w-full py-2 bg-yellow-600 hover:bg-yellow-700 text-white font-bold rounded"
            >
              Vẽ lại
            </button>
          )}
          {currentStep === "mvd" && analysisResult?.qr_detected && (
            <button
              onClick={handleConfirmRoi}
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded"
            >
              Hoàn tất
            </button>
          )}
          {currentStep === "packing" && handDetected && (
            <button
              onClick={handleConfirmRoi}
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded"
            >
              Tiếp tục
            </button>
          )}
          <button
            onClick={onClose}
            className="w-full py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded"
          >
            Thoát
          </button>
        </div>
      </div>
      <div className="w-3/4 pl-4 flex flex-col">
        <div className="mb-4 flex justify-center items-center" style={{ maxHeight: 'calc(75vh - 2rem)', overflow: 'hidden' }}>
          {console.log("Rendering ROI frame with roiFrameSrc:", roiFrameSrc, "roiImageState:", roiImageState)}
          {roiFrameSrc && (
            <img 
              src={roiFrameSrc} 
              alt="ROI Frame" 
              className={`max-w-full max-h-full rounded ${imageAspectRatio && imageAspectRatio < 1 ? 'portrait' : 'landscape'}`}
              onLoad={handleImageLoad}
            />
          )}
        </div>
        {finalRoiFrameSrc && currentStep === "done" && (
          <div className="mb-4 flex justify-center items-center" style={{ maxHeight: 'calc(75vh - 2rem)', overflow: 'hidden' }}>
            <h4 className="text-lg font-bold text-white">Ảnh tổng hợp:</h4>
            <img 
              src={finalRoiFrameSrc} 
              alt="Final ROI Frame" 
              className={`max-w-full max-h-full rounded ${imageAspectRatio && imageAspectRatio < 1 ? 'portrait' : 'landscape'}`}
              onLoad={handleImageLoad}
            />
          </div>
        )}
      </div>
      <style jsx>{`
        .max-w-full {
          max-width: 100%;
        }
        .max-h-full {
          max-height: 100%;
        }
        .landscape {
          object-fit: contain;
          width: 100%;
        }
        .portrait {
          object-fit: contain;
          height: 100%;
        }
      `}</style>
    </div>
  );
};

export default InstructionsPanel;
```
## 📄 File: `SourceCard.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/SourceCard.js`

```javascript
// components/config/SourceCard.js
import React from 'react';

const SourceCard = ({ source, onEdit, onDelete, onToggle }) => {
  const getSourceTypeIcon = (type) => {
    const icons = {
      'local': '💻',
      'network': '🌐', 
      'camera': '📹',
      'cloud': '☁️'
    };
    return icons[type] || '📁';
  };

  return (
    <div className="bg-gray-800 border border-gray-600 rounded-lg p-4 mb-3">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xl">{getSourceTypeIcon(source.source_type)}</span>
            <h4 className="text-lg font-medium text-white">{source.name}</h4>
            <span className={`px-2 py-1 rounded text-xs font-medium ${
              source.active ? 'bg-green-600 text-white' : 'bg-red-600 text-white'
            }`}>
              {source.active ? 'Active' : 'Inactive'}
            </span>
          </div>
          <p className="text-gray-300 text-sm mb-1">
            <strong>Type:</strong> {source.source_type.toUpperCase()}
          </p>
          <p className="text-gray-300 text-sm break-all">
            <strong>Path:</strong> {source.path}
          </p>
        </div>
        
        <div className="flex gap-2 ml-4">
          <button
            onClick={() => onToggle(source.id, !source.active)}
            className={`px-3 py-1 rounded text-sm font-medium ${
              source.active 
                ? 'bg-yellow-600 hover:bg-yellow-700 text-white' 
                : 'bg-green-600 hover:bg-green-700 text-white'
            }`}
          >
            {source.active ? 'Disable' : 'Enable'}
          </button>
          <button
            onClick={() => onEdit(source)}
            className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-sm font-medium"
          >
            Edit
          </button>
          <button
            onClick={() => onDelete(source.id)}
            className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-sm font-medium"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default SourceCard;
```
## 📄 File: `CameraDialog.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/CameraDialog.js`

```javascript
const CameraDialog = ({
  showCameraDialog,
  setShowCameraDialog,
  cameras,
  selectedCameras,
  handleCameraSelection,
  handleSaveConfig,
}) => {
  if (!showCameraDialog) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-gray-800 p-6 rounded-lg w-1/2">
        <h2 className="text-2xl font-bold mb-4 text-white">Xác nhận camera</h2>
        <div className="max-h-64 overflow-y-auto">
          {cameras.map((camera) => (
            <label key={camera.name} className="flex items-center mb-2 text-white">
              <input
                type="checkbox"
                className="mr-2"
                checked={selectedCameras.includes(camera.name)}
                onChange={() => handleCameraSelection(camera.name)}
              />
              {camera.name} ({camera.path})
            </label>
          ))}
        </div>
        <div className="mt-4 flex justify-end gap-4">
          <button
            onClick={() => setShowCameraDialog(false)}
            className="py-2 px-4 bg-gray-600 text-white font-bold rounded"
          >
            Hủy
          </button>
          <button
            onClick={handleSaveConfig}
            className="py-2 px-4 bg-blue-600 text-white font-bold rounded"
          >
            Xác nhận
          </button>
        </div>
      </div>
    </div>
  );
};
export default CameraDialog;
```
## 📄 File: `FileList.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/program/FileList.js`

```javascript
const FileList = ({ fileList }) => {
  if (!fileList || fileList.length === 0) {
    return (
      <div className="mt-4">
        <h3 className="text-lg font-bold">Kết quả:</h3>
        <p>Không có file nào để hiển thị.</p>
      </div>
    );
  }

  return (
    <div className="mt-4">
      <h3 className="text-lg font-bold">Kết quả:</h3>
      <ul className="list-disc pl-5">
        {fileList.map((item, index) => (
          <li key={index}>{`${item.file}: ${item.status}`}</li>
        ))}
      </ul>
    </div>
  );
};

export default FileList;
```
## 📄 File: `ProgramTab.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/program/ProgramTab.js`

```javascript
import { useState, useEffect } from "react";
import Card from "../ui/Card";
import FileList from "./FileList";

const ProgramTab = ({
  runningCard,
  fileList,
  customPath,
  firstRunCompleted,
  handleRunStop,
  isRunning,
  setCustomPath,
}) => {
  const [updatedFileList, setUpdatedFileList] = useState(fileList);

  useEffect(() => {
    const fetchProgress = async () => {
      try {
        const response = await fetch("http://localhost:8080/program-progress", {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        });
        const data = await response.json();
        if (response.ok) {
          setUpdatedFileList(data.files);
        } else {
          console.error("Failed to fetch program progress:", data.error);
        }
      } catch (error) {
        console.error("Error fetching program progress:", error);
      }
    };

    fetchProgress();
    const intervalId = setInterval(fetchProgress, 10000);
    const timeoutId = setTimeout(() => {
      clearInterval(intervalId);
      console.log("Stopped polling /program-progress after 2 minutes");
    }, 120000);

    return () => {
      clearInterval(intervalId);
      clearTimeout(timeoutId);
    };
  }, [runningCard]);

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-3 gap-6">
        {!firstRunCompleted && (
          <Card
            title="Lần đầu"
            description="Chạy lần đầu để xử lý dữ liệu cơ sở."
            isRunning={isRunning("Lần đầu")}
            onRunStop={firstRunCompleted ? null : () => handleRunStop("Lần đầu")}
            isLocked={firstRunCompleted}
          />
        )}
        <Card
          title="Mặc định"
          description="Chạy khi khởi động, chạy nền."
          isRunning={isRunning("Mặc định")}
          onRunStop={() => handleRunStop("Mặc định")}
        />
        <Card
          title="Chỉ định"
          description="Chỉ định file cụ thể."
          isRunning={isRunning("Chỉ định")}
          onRunStop={() => handleRunStop("Chỉ định", customPath)}
          onPathChange={(path) => setCustomPath(path)}
        />
      </div>
      <FileList fileList={updatedFileList} />
    </div>
  );
};

export default ProgramTab;
```
## 📄 File: `TextInputSection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/TextInputSection.js`

```javascript
const TextInputSection = ({ searchString, setSearchString, searchType }) => {
  const handleTextInputChange = (e) => {
    const value = e.target.value;
    const lines = value.split("\n");
    const codes = [];
    
    lines.forEach(line => {
      const trimmedLine = line.trim();
      if (!trimmedLine) return;
      const match = trimmedLine.match(/^\d+\.\s*(.+)$/);
      const lineContent = match ? match[1].trim() : trimmedLine;
      const lineCodes = lineContent.split(";").map(code => code.trim()).filter(code => code);
      codes.push(...lineCodes);
    });

    let formattedCodes = codes
      .map((code, index) => `${index + 1}. ${code}`)
      .join("\n");

    if (value.endsWith("\n")) {
      formattedCodes += `\n${codes.length + 1}. `;
    }

    setSearchString(formattedCodes);
  };

  return (
    <textarea
      value={searchString}
      onChange={handleTextInputChange}
      placeholder="Nhập chuỗi tìm kiếm (mỗi mã trên một dòng)"
      className="w-full p-2 mb-4 rounded bg-gray-700 text-white h-1/2 overflow-y-auto whitespace-pre-wrap resize-none"
      disabled={searchType === "File"}
    />
  );
};

export default TextInputSection;
```
## 📄 File: `TimeAndQuerySection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/TimeAndQuerySection.js`

```javascript
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const TimeAndQuerySection = ({
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  defaultDays,
  setDefaultDays,
  searchString,
  searchType,
  fileContent,
  results,
  setResults,
  setSelectedVideos,
  setQueryCount,
  setFoundCount,
  foundCount,
  onQuery, // Prop để nhận hàm debounce từ QueryComponent
  isQuerying, // Prop để vô hiệu hóa nút
}) => {
  const handleStartDateChange = (date) => {
    setStartDate(date);
    if (endDate) {
      const diffDays = (endDate - date) / (1000 * 60 * 60 * 24);
      if (diffDays > 30) {
        setEndDate(new Date(date.getTime() + 30 * 24 * 60 * 60 * 1000));
      } else if (date > endDate) {
        setEndDate(date);
      }
    }
  };

  const handleEndDateChange = (date) => {
    const today = new Date();
    if (date > today) {
      date = today;
    }
    if (startDate) {
      const diffDays = (date - startDate) / (1000 * 60 * 60 * 24);
      if (diffDays > 30) {
        setStartDate(new Date(date.getTime() - 30 * 24 * 60 * 60 * 1000));
      } else if (date < startDate) {
        setStartDate(date);
      }
    }
    setEndDate(date);
  };

  return (
    <>
      <div className="mb-4">
        <label className="block mb-1">Thời gian mặc định (ngày):</label>
        <input
          type="number"
          value={defaultDays}
          onChange={(e) => setDefaultDays(Number(e.target.value))}
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <div className="flex gap-4 mb-4">
        <div className="flex-1">
          <label className="block mb-1">Từ:</label>
          <DatePicker
            selected={startDate}
            onChange={handleStartDateChange}
            showTimeSelect
            timeIntervals={60}
            dateFormat="Pp"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div className="flex-1">
          <label className="block mb-1">Đến:</label>
          <DatePicker
            selected={endDate}
            onChange={handleEndDateChange}
            showTimeSelect
            timeIntervals={60}
            dateFormat="Pp"
            maxDate={new Date()}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
      </div>
      <button
        onClick={onQuery} // Dùng onQuery từ props
        disabled={isQuerying} // Vô hiệu hóa nút khi đang xử lý
        className={`w-full py-2 bg-green-600 text-white font-bold rounded ${isQuerying ? "opacity-50 cursor-not-allowed" : ""}`}
      >
        Truy vấn
      </button>
    </>
  );
};

export default TimeAndQuerySection;
```
## 📄 File: `FileInputSection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/FileInputSection.js`

```javascript
const FileInputSection = ({ path, setPath, fileContent, setFileContent, setShowModal, setHeaders }) => {
  const handleOpenExplorer = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".csv,.xlsx";
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const fileName = file.name.toLowerCase();
      const fileType = file.type;

      // Kiểm tra đuôi file
      if (!fileName.endsWith(".csv") && !fileName.endsWith(".xlsx")) {
        alert("Vui lòng chọn file CSV hoặc Excel (.csv, .xlsx)");
        return;
      }

      // Kiểm tra MIME type
      const validCsvMimeTypes = ["text/csv", "application/csv"];
      const validXlsxMimeTypes = [
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-excel",
      ];
      if (fileName.endsWith(".csv") && !validCsvMimeTypes.includes(fileType)) {
        alert("File không đúng định dạng CSV. Vui lòng chọn file CSV hợp lệ.");
        return;
      }
      if (fileName.endsWith(".xlsx") && !validXlsxMimeTypes.includes(fileType)) {
        alert("File không đúng định dạng Excel. Vui lòng chọn file XLSX hợp lệ.");
        return;
      }

      setPath(file.name);

      const reader = new FileReader();
      reader.onload = (event) => {
        const arrayBuffer = event.target.result;
        const bytes = new Uint8Array(arrayBuffer);
        const binary = Array.from(bytes).map((b) => String.fromCharCode(b)).join("");
        const base64 = btoa(binary); // Base64 encode từ nhị phân
        setFileContent(base64);
      };
      reader.onerror = () => {
        alert("Lỗi khi đọc file");
      };
      reader.readAsArrayBuffer(file); // Đọc raw binary
    };
    input.click();
  };

  const handleConfirmFile = async () => {
    if (!path) {
      alert("Vui lòng chọn file CSV hoặc nhập đường dẫn");
      return;
    }
    try {
      const response = await fetch("http://localhost:8080/get-csv-headers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          file_path: path,
          file_content: fileContent || "",
          is_excel: path.toLowerCase().endsWith(".xlsx"),
        }),
      });
      const result = await response.json();
      if (response.ok) {
        setHeaders(result.headers || []);
        setShowModal(true);
      } else {
        throw new Error(result.error || "Failed to get CSV headers");
      }
    } catch (error) {
      console.error("Error getting CSV headers:", error);
      alert(error.message || "Failed to get CSV headers");
    }
  };

  return (
    <div className="mb-4">
      <div className="relative w-full mb-2">
        <input
          type="text"
          value={path}
          onChange={(e) => setPath(e.target.value)}
          placeholder="Chọn file định dạng *.csv hoặc *.xlsx"
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
        <button
          type="button"
          onClick={handleOpenExplorer}
          className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
        >
          ...
        </button>
      </div>
      <button
        onClick={handleConfirmFile}
        className="w-full py-2 bg-yellow-500 text-white font-bold rounded"
      >
        Xác nhận
      </button>
    </div>
  );
};

export default FileInputSection;
```
## 📄 File: `ColumnSelectorModal.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/ColumnSelectorModal.js`

```javascript
const ColumnSelectorModal = ({
  showModal,
  setShowModal,
  headers,
  selectedColumn,
  setSelectedColumn,
  history,
  setHistory,
  selectedPlatform,
  setSelectedPlatform,
  shopeeLabel,
  setShopeeLabel,
  lazadaLabel,
  setLazadaLabel,
  tiktokLabel,
  setTiktokLabel,
  customLabel1,
  setCustomLabel1,
  customLabel2,
  setCustomLabel2,
  path,
  fileContent,
  setSearchString,
  setSearchType,
}) => {
  const handleModalConfirm = async () => {
    const columnName = history[selectedPlatform] || "tracking_codes";
    const data = {
      file_path: path,
      file_content: fileContent || "",
      column_name: columnName,
      is_excel: path.toLowerCase().endsWith(".xlsx"), // Thêm logic xác định is_excel dựa trên path
    };
    try {
      console.log("Sending file data:", data);
      const response = await fetch("http://localhost:8080/parse-csv", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      console.log("Response from parse-csv:", result);
      if (response.ok) {
        const trackingCodes = result.tracking_codes || [];
        const formattedCodes = trackingCodes
          .map((code, index) => `${index + 1}. ${code}`)
          .join("\n");
        setSearchString(formattedCodes);
        setSearchType("Text");
        setShowModal(false);
      } else {
        throw new Error(result.error || "Failed to parse CSV");
      }
    } catch (error) {
      console.error("Error parsing CSV:", error);
      alert(error.message || "Failed to parse CSV");
    }
  };

  const handleUpdateColumn = () => {
    const newColumn = selectedColumn;
    const updatedHistory = { ...history };
    updatedHistory[selectedPlatform] = newColumn;
    setHistory(updatedHistory);
    localStorage.setItem("trackingColumnHistory", JSON.stringify(updatedHistory));

    const updatedLabels = {
      Shopee: shopeeLabel,
      Lazada: lazadaLabel,
      Tiktok: tiktokLabel,
      Custom1: customLabel1,
      Custom2: customLabel2,
    };
    localStorage.setItem("platformLabels", JSON.stringify(updatedLabels));
  };

  const handlePlatformChange = (platform) => {
    setSelectedPlatform(platform);
    setSelectedColumn(history[platform] || "tracking_codes");
  };

  if (!showModal) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-gray-800 p-6 rounded-lg w-1/2">
        <h2 className="text-xl font-bold mb-4">Chọn cột mã vận đơn</h2>
        <div className="mb-4">
          <label className="block mb-1">Chọn từ danh sách:</label>
          <select
            value={selectedColumn}
            onChange={(e) => setSelectedColumn(e.target.value)}
            className="w-full p-2 rounded bg-gray-700 text-white"
          >
            {headers.map((header, index) => (
              <option key={index} value={header}>{header}</option>
            ))}
          </select>
        </div>
        <div className="mb-4">
          <button
            onClick={handleUpdateColumn}
            className="w-full py-2 bg-blue-600 text-white font-bold rounded"
          >
            Cập nhật
          </button>
        </div>
        <div className="mb-4">
          <h3 className="text-lg font-bold mb-2">Lịch sử lựa chọn:</h3>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Shopee"
              checked={selectedPlatform === "Shopee"}
              onChange={() => handlePlatformChange("Shopee")}
              className="mr-2"
            />
            <input
              type="text"
              value={shopeeLabel}
              onChange={(e) => setShopeeLabel(e.target.value)}
              placeholder="Tên Shopee"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Shopee}
              onChange={(e) => setHistory({ ...history, Shopee: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Lazada"
              checked={selectedPlatform === "Lazada"}
              onChange={() => handlePlatformChange("Lazada")}
              className="mr-2"
            />
            <input
              type="text"
              value={lazadaLabel}
              onChange={(e) => setLazadaLabel(e.target.value)}
              placeholder="Tên Lazada"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Lazada}
              onChange={(e) => setHistory({ ...history, Lazada: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Tiktok"
              checked={selectedPlatform === "Tiktok"}
              onChange={() => handlePlatformChange("Tiktok")}
              className="mr-2"
            />
            <input
              type="text"
              value={tiktokLabel}
              onChange={(e) => setTiktokLabel(e.target.value)}
              placeholder="Tên Tiktok"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Tiktok}
              onChange={(e) => setHistory({ ...history, Tiktok: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Custom1"
              checked={selectedPlatform === "Custom1"}
              onChange={() => handlePlatformChange("Custom1")}
              className="mr-2"
            />
            <input
              type="text"
              value={customLabel1}
              onChange={(e) => setCustomLabel1(e.target.value)}
              placeholder="Tên tùy chỉnh 1"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Custom1}
              onChange={(e) => setHistory({ ...history, Custom1: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Custom2"
              checked={selectedPlatform === "Custom2"}
              onChange={() => handlePlatformChange("Custom2")}
              className="mr-2"
            />
            <input
              type="text"
              value={customLabel2}
              onChange={(e) => setCustomLabel2(e.target.value)}
              placeholder="Tên tùy chỉnh 2"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Custom2}
              onChange={(e) => setHistory({ ...history, Custom2: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
        </div>
        <div className="flex justify-end gap-4">
          <button
            onClick={() => setShowModal(false)}
            className="py-2 px-4 bg-gray-600 text-white rounded"
          >
            Hủy
          </button>
          <button
            onClick={handleModalConfirm}
            className="py-2 px-4 bg-green-600 text-white rounded"
          >
            Xác nhận
          </button>
        </div>
      </div>
    </div>
  );
};

export default ColumnSelectorModal;
```
## 📄 File: `useVtrackConfig.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/hooks/useVtrackConfig.js`

```javascript
import { useState, useEffect } from "react";

const useVtrackConfig = () => {
  const [fromTime, setFromTime] = useState(null);
  const [toTime, setToTime] = useState(null);
  const [country, setCountry] = useState("Việt Nam");
  const [timezone, setTimezone] = useState("UTC+7");
  const [brandName, setBrandName] = useState("");
  const [inputPath, setInputPath] = useState("");
  const [outputPath, setOutputPath] = useState("");
  const [workingDays, setWorkingDays] = useState([]);
  const [defaultDays, setDefaultDays] = useState(30);
  const [minPackingTime, setMinPackingTime] = useState(10);
  const [maxPackingTime, setMaxPackingTime] = useState(120);
  const [frameRate, setFrameRate] = useState(30);
  const [frameInterval, setFrameInterval] = useState(5);
  const [videoBuffer, setVideoBuffer] = useState(2);
  const [cameras, setCameras] = useState([]);
  const [selectedCameras, setSelectedCameras] = useState([]);
  const [showCameraDialog, setShowCameraDialog] = useState(false);
  const [error, setError] = useState(null);
  const [runDefaultOnStart, setRunDefaultOnStart] = useState(false);

  const countries = [
    "Việt Nam", "Nhật Bản", "Hàn Quốc", "Thái Lan", "Singapore",
    "Mỹ", "Anh", "Pháp", "Đức", "Úc"
  ];

  const countryTimezones = {
    "Việt Nam": "UTC+7", "Nhật Bản": "UTC+9", "Hàn Quốc": "UTC+9",
    "Thái Lan": "UTC+7", "Singapore": "UTC+8", "Mỹ": "UTC-5",
    "Anh": "UTC+0", "Pháp": "UTC+1", "Đức": "UTC+1", "Úc": "UTC+10"
  };

  const BASE_DIR = "/Users/annhu/vtrack_app/V_Track";

  useEffect(() => {
    const fetchCameraFolders = async () => {
      try {
        const response = await fetch("http://localhost:8080/get-camera-folders");
        const data = await response.json();
        if (Array.isArray(data.folders)) {
          setCameras(data.folders);
          setError(null);
        } else {
          setCameras([]);
          setError(data.error || "Failed to load camera folders");
        }
      } catch (error) {
        console.error("Error fetching camera folders:", error);
        setError("Error fetching camera folders: " + error.message);
      }
    };
    fetchCameraFolders();
  }, []);

  const handleCountryChange = (e) => {
    const selectedCountry = e.target.value;
    setCountry(selectedCountry);
    setTimezone(countryTimezones[selectedCountry] || "UTC+0");
  };

  const handleFromTimeChange = (time) => {
    setFromTime(time);
    if (toTime && time > toTime) setToTime(time);
  };

  const handleToTimeChange = (time) => {
    if (fromTime && time < fromTime) setFromTime(time);
    setToTime(time);
  };

  const handleWorkingDayChange = (day) => {
    setWorkingDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };

  useEffect(() => {
    console.log("workingDays updated:", workingDays);
  }, [workingDays]);

  const handleOpenExplorer = (type) => {
    const input = document.createElement("input");
    input.type = "file";
    input.webkitdirectory = true;
    input.onchange = (e) => {
      const files = e.target.files;
      if (files.length > 0) {
        const file = files[0];
        let selectedPath = file.path || file.webkitRelativePath || file.name || "";
        if (!selectedPath.startsWith('/')) {
          selectedPath = `${BASE_DIR}/${selectedPath}`;
        }
        selectedPath = selectedPath.split('/').slice(0, -1).join('/');
        if (selectedPath.includes('.DS_Store')) {
          selectedPath = selectedPath.replace('/.DS_Store', '');
        }
        console.log(`Selected ${type} path:`, selectedPath);
        if (type === "input") setInputPath(selectedPath);
        else setOutputPath(selectedPath);
      }
    };
    input.click();
  };

  const handleSaveGeneralInfo = async () => {
    const data = {
      country,
      timezone,
      brand_name: brandName,
      working_days: workingDays.length > 0 ? workingDays : ["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"],
      from_time: fromTime ? fromTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false }) : "07:00",
      to_time: toTime ? toTime.toLocaleTimeString('en-GB', { hour: "2-digit", minute: "2-digit", hour12: false }) : "23:00",
    };
    console.log("Data sent to /save-general-info:", data);
    try {
      const response = await fetch("http://localhost:8080/save-general-info", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (response.ok) alert("General info saved successfully");
      else throw new Error("Failed to save general info");
    } catch (error) {
      console.error("Error saving general info:", error);
      alert("Failed to save general info");
    }
  };

  const handleSaveConfig = async () => {
    let normalizedInputPath = inputPath.trim();
    if (!normalizedInputPath) {
      alert("Input path cannot be empty");
      return;
    }
    if (!normalizedInputPath.startsWith('/')) {
      normalizedInputPath = `${BASE_DIR}/${normalizedInputPath}`;
    }
    if (normalizedInputPath.includes('.DS_Store')) {
      normalizedInputPath = normalizedInputPath.replace('/.DS_Store', '');
    }

    let normalizedOutputPath = outputPath.trim();
    if (!normalizedOutputPath) {
      normalizedOutputPath = `${BASE_DIR}/output_clips`;
    }
    if (!normalizedOutputPath.startsWith('/')) {
      normalizedOutputPath = `${BASE_DIR}/${normalizedOutputPath}`;
    }
    if (normalizedOutputPath.includes('.DS_Store')) {
      normalizedOutputPath = normalizedOutputPath.replace('/.DS_Store', '');
    }

    const data = {
      video_root: normalizedInputPath,
      output_path: normalizedOutputPath,
      db_path: "/Users/annhu/Downloads/V_Track project/events.db",
      default_days: defaultDays,
      min_packing_time: minPackingTime,
      max_packing_time: maxPackingTime,
      frame_rate: frameRate,
      frame_interval: frameInterval,
      video_buffer: videoBuffer,
      selected_cameras: selectedCameras,
    };
    console.log("Data sent to /save-config:", data);
    try {
      const response = await fetch("http://localhost:8080/save-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      if (response.ok) {
        localStorage.setItem("configSet", "true");
        alert("Configuration saved successfully");
        setShowCameraDialog(false);
        const cameraResponse = await fetch("http://localhost:8080/get-cameras");
        const cameraData = await cameraResponse.json();
        if (cameraData && Array.isArray(cameraData.cameras)) {
          setCameras(cameraData.cameras.map(name => ({ name, path: "" })));
          setError(null);
        } else {
          setCameras([]);
          setError(cameraData?.error || "Failed to load cameras");
        }
      } else {
        throw new Error(result.error || "Failed to save config");
      }
    } catch (error) {
      console.error("Error saving config:", error);
      alert("Failed to save config: " + error.message);
    }
  };

  const handleShowCameraDialog = () => {
    setShowCameraDialog(true);
  };

  const handleCameraSelection = (cameraName) => {
    setSelectedCameras((prev) =>
      prev.includes(cameraName) ? prev.filter((c) => c !== cameraName) : [...prev, cameraName]
    );
  };

  return {
    fromTime,
    setFromTime,
    toTime,
    setToTime,
    country,
    setCountry,
    timezone,
    setTimezone,
    brandName,
    setBrandName,
    inputPath,
    setInputPath,
    outputPath,
    setOutputPath,
    workingDays,
    setWorkingDays,
    defaultDays,
    setDefaultDays,
    minPackingTime,
    setMinPackingTime,
    maxPackingTime,
    setMaxPackingTime,
    frameRate,
    setFrameRate,
    frameInterval,
    setFrameInterval,
    videoBuffer,
    setVideoBuffer,
    cameras,
    setCameras,
    selectedCameras,
    setSelectedCameras,
    showCameraDialog,
    setShowCameraDialog,
    error,
    setError,
    handleCountryChange,
    handleFromTimeChange,
    handleToTimeChange,
    handleWorkingDayChange,
    handleOpenExplorer,
    handleSaveGeneralInfo,
    handleSaveConfig,
    handleShowCameraDialog,
    handleCameraSelection,
    runDefaultOnStart,
    setRunDefaultOnStart,
  };
};

export default useVtrackConfig;
```
## 📄 File: `useProgramLogic.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/hooks/useProgramLogic.js`

```javascript
import { useState, useEffect } from "react";
import { runProgram, confirmRun } from "../api";

const useProgramLogic = () => {
  const [runningCard, setRunningCard] = useState("Mặc định");
  const [fileList, setFileList] = useState([]);
  const [customPath, setCustomPath] = useState("");
  const [showConfirmButton, setShowConfirmButton] = useState(false);
  const [firstRunCompleted, setFirstRunCompleted] = useState(false);
  const [isLocked, setIsLocked] = useState(false);

  const checkFirstRun = async () => {
    try {
      const response = await fetch("http://localhost:8080/check-first-run");
      const data = await response.json();
      setFirstRunCompleted(data.first_run_completed);
    } catch (error) {
      console.error("Error checking first run:", error);
    }
  };

  const checkDefaultRunning = async () => {
    try {
      const response = await fetch("http://localhost:8080/program", {
        method: "GET",
      });
      const data = await response.json();
      setRunningCard("Mặc định"); // Ép Mặc định khi refresh
      setIsLocked(false);
    } catch (error) {
      console.error("Error checking default running state:", error);
      setRunningCard("Mặc định"); // Ép Mặc định nếu lỗi
      setIsLocked(false);
    }
  };

  useEffect(() => {
    const initializeState = async () => {
      await checkFirstRun();
      await checkDefaultRunning();
    };
    initializeState();
  }, []);

  const handleRunStop = async (cardTitle, path = "") => {
    if (cardTitle === "Lần đầu" && firstRunCompleted) {
      return;
    }

    if (isLocked) {
      alert("Hệ thống đang xử lý, vui lòng đợi!");
      return;
    }

    try {
      let days = null;
      if (cardTitle === "Lần đầu" && !isRunning(cardTitle)) {
        days = prompt("Bạn muốn xử lý bao nhiêu ngày? (Tối đa 30 ngày)", "30");
        days = parseInt(days);
        if (isNaN(days) || days <= 0 || days > 30) {
          alert("Số ngày không hợp lệ. Vui lòng nhập từ 1 đến 30.");
          return;
        }
      } else if (cardTitle === "Chỉ định" && !isRunning(cardTitle)) {
        if (!path) {
          alert("Vui lòng chọn đường dẫn cho chương trình Chỉ định.");
          return;
        }
        setIsLocked(true);
      }

      const response = await runProgram({
        card: cardTitle,
        action: isRunning(cardTitle) ? "stop" : "run",
        days: days,
        custom_path: cardTitle === "Chỉ định" ? path : ""
      });

      if (response.status === 200) {
        if (isRunning(cardTitle)) {
          if (cardTitle === "Mặc định") {
            setRunningCard(null);
            setFileList([]);
            alert(`Đã dừng chương trình ${cardTitle}`);
          }
        } else {
          if (cardTitle !== "Lần đầu" || !firstRunCompleted) {
            setRunningCard(cardTitle);
            setShowConfirmButton(true);
            if (cardTitle !== "Chỉ định") {
              setIsLocked(false);
            }
          }
        }
      }
    } catch (error) {
      console.error("Error calling API:", error);
      setIsLocked(false);
      if (error.response?.status === 400) {
        alert(error.response.data.error);
      } else {
        alert("Có lỗi xảy ra khi gọi API. Vui lòng kiểm tra server.");
      }
    }
  };

  const handleConfirmRun = async () => {
    try {
      const response = await confirmRun({ card: runningCard });
      if (response.status === 200) {
        setShowConfirmButton(false);
        setFileList(response.data.files || []);
        if (runningCard === "Lần đầu") {
          setFirstRunCompleted(true);
          await checkFirstRun();
        }
        if (runningCard === "Chỉ định") {
          setIsLocked(false);
          await checkDefaultRunning();
        }
      }
    } catch (error) {
      console.error("Error confirming run:", error);
      setIsLocked(false);
      alert("Có lỗi xảy ra khi xác nhận chạy chương trình.");
    }
  };

  const isRunning = (cardTitle) => runningCard === cardTitle;

  return {
    runningCard,
    setRunningCard,
    fileList,
    setFileList,
    customPath,
    setCustomPath,
    showConfirmButton,
    setShowConfirmButton,
    firstRunCompleted,
    setFirstRunCompleted,
    handleRunStop,
    handleConfirmRun,
    isRunning,
    isLocked
  };
};

export default useProgramLogic;
```