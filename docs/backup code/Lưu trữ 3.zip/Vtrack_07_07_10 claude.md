# 📦 Tổng hợp mã nguồn Vtrack

**Tổng cộng:** 44 file `.py`, 33 file `.js`

---

## 📄 File: `tailwind.config.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/tailwind.config.js`

```javascript
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        'blue-custom': '#0066CC',
        'red-custom': '#E32222',
        'gray-custom': '#3F3F3F',
        'yellow-custom': '#FFD700',
      },
    },
  },
  plugins: [],
};
```
## 📄 File: `postcss.config.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/postcss.config.js`

```javascript
module.exports = {
   plugins: {
     tailwindcss: {},
     autoprefixer: {},
   },
 };
```
## 📄 File: `reportWebVitals.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/reportWebVitals.js`

```javascript
const reportWebVitals = onPerfEntry => {
  if (onPerfEntry && onPerfEntry instanceof Function) {
    import('web-vitals').then(({ getCLS, getFID, getFCP, getLCP, getTTFB }) => {
      getCLS(onPerfEntry);
      getFID(onPerfEntry);
      getFCP(onPerfEntry);
      getLCP(onPerfEntry);
      getTTFB(onPerfEntry);
    });
  }
};

export default reportWebVitals;

```
## 📄 File: `Sidebar.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Sidebar.js`

```javascript
import { Play, Search, Settings, User } from "lucide-react";
import Title from "./Title";

const Sidebar = ({ setActiveMenu, activeMenu }) => (
  <div className="w-64 bg-black text-white min-h-screen p-4 flex flex-col font-montserrat">
    <Title text="V_TRACK UI" />
    <ul>
      {[
        { name: "Chương trình", icon: <Play className="mr-2 text-blue-custom" /> },
        { name: "Truy vấn", icon: <Search className="mr-2 text-red-custom" /> },
        { name: "Cấu hình", icon: <Settings className="mr-2 text-gray-custom" /> },
        { name: "Tài khoản", icon: <User className="mr-2 text-yellow-custom" /> },
      ].map((item) => (
        <li
          key={item.name}
          className={`flex items-center p-3 hover:bg-gray-800 cursor-pointer transition duration-300 ${
            activeMenu === item.name ? "bg-gray-800" : ""
          }`}
          onClick={() => setActiveMenu(item.name)}
        >
          {item.icon} {item.name}
        </li>
      ))}
    </ul>
  </div>
);

export default Sidebar;
```
## 📄 File: `index.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/index.js`

```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import "@fontsource/montserrat";
import "react-datepicker/dist/react-datepicker.css";

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

```
## 📄 File: `QueryComponent.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/QueryComponent.js`

```javascript
import { useState, useEffect } from "react";
import SearchModeSelector from "./components/ui/SearchModeSelector";
import FileInputSection from "./components/query/FileInputSection";
import TextInputSection from "./components/query/TextInputSection";
import TimeAndQuerySection from "./components/query/TimeAndQuerySection";
import ResultList from "./components/result/ResultList";
import VideoCutter from "./components/result/VideoCutter"; // Thay CutVideoSection bằng VideoCutter
import ColumnSelectorModal from "./components/query/ColumnSelectorModal";
import api from "./api";

const QueryComponent = () => {
  const [searchType, setSearchType] = useState("Text");
  const [path, setPath] = useState("");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [results, setResults] = useState([]);
  const [selectedVideos, setSelectedVideos] = useState([]);
  const [cutVideos, setCutVideos] = useState([]);
  const [searchString, setSearchString] = useState("");
  const [defaultDays, setDefaultDays] = useState(30);
  const [fileContent, setFileContent] = useState("");
  const [trackingCodes, setTrackingCodes] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [headers, setHeaders] = useState([]);
  const [selectedColumn, setSelectedColumn] = useState("tracking_codes");
  const [history, setHistory] = useState({
    Shopee: "Mã vận đơn",
    Lazada: "Vận đơn",
    Tiktok: "QR mã vận đơn",
    Custom1: "Custom 1",
    Custom2: "Custom 2",
  });
  const [selectedPlatform, setSelectedPlatform] = useState("Shopee");
  const [shopeeLabel, setShopeeLabel] = useState("Shopee");
  const [lazadaLabel, setLazadaLabel] = useState("Lazada");
  const [tiktokLabel, setTiktokLabel] = useState("Tiktok");
  const [customLabel1, setCustomLabel1] = useState("Custom 1");
  const [customLabel2, setCustomLabel2] = useState("Custom 2");
  const [queryCount, setQueryCount] = useState(0);
  const [trackingCodeCount, setTrackingCodeCount] = useState(0);
  const [foundCount, setFoundCount] = useState(0);
  const [isQuerying, setIsQuerying] = useState(false);
  const [selectedCameras, setSelectedCameras] = useState([]);
  const [availableCameras, setAvailableCameras] = useState([]);
  const [hasQueried, setHasQueried] = useState(false);

  useEffect(() => {
    const savedHistory = localStorage.getItem("trackingColumnHistory");
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
    const savedLabels = localStorage.getItem("platformLabels");
    if (savedLabels) {
      const labels = JSON.parse(savedLabels);
      setShopeeLabel(labels.Shopee || "Shopee");
      setLazadaLabel(labels.Lazada || "Lazada");
      setTiktokLabel(labels.Tiktok || "Tiktok");
      setCustomLabel1(labels.Custom1 || "Custom 1");
      setCustomLabel2(labels.Custom2 || "Custom 2");
    }

    const isConfigSet = localStorage.getItem("configSet");
    if (isConfigSet) {
      const fetchCameras = async () => {
        try {
          const response = await api.get("/get-cameras");
          setAvailableCameras(response.data.cameras || []);
          const savedCameras = localStorage.getItem("selectedCameras");
          if (savedCameras) {
            setSelectedCameras(JSON.parse(savedCameras));
          }
        } catch (error) {
          console.error("Error fetching cameras:", error);
        }
      };
      fetchCameras();
    }
  }, []);

  useEffect(() => {
    let count = 0;
    if (searchString) {
      const lines = searchString.split("\n");
      count = lines.filter(line => line.trim() !== "" && line.split('. ')[1]?.trim()).length;
    }
    setTrackingCodeCount(count);
  }, [searchString]);

  const debounce = (func, delay) => {
    let timeoutId;
    return (...args) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func(...args), delay);
    };
  };

  const handleQuery = async () => {
    setIsQuerying(true);
    setHasQueried(true);
    try {
      const queryData = {
        search_string: searchString,
        default_days: defaultDays,
        from_time: startDate ? startDate.toISOString() : null,
        to_time: endDate ? endDate.toISOString() : null,
        selected_cameras: selectedCameras,
      };

      const response = await api.post("/query", queryData);
      const events = response.data.events || [];

      setResults(events);
      setSelectedVideos(events.map(event => event.event_id));
      setQueryCount(prev => prev + 1);
      setFoundCount(events.length);
    } catch (error) {
      console.error("Error in query:", error);
    } finally {
      setIsQuerying(false);
    }
  };

  const debouncedHandleQuery = debounce(handleQuery, 1000);

  const handleCameraSelection = (camera) => {
    const updatedCameras = selectedCameras.includes(camera)
      ? selectedCameras.filter((c) => c !== camera)
      : [...selectedCameras, camera];
    setSelectedCameras(updatedCameras);
    localStorage.setItem("selectedCameras", JSON.stringify(updatedCameras));
  };

  return (
    <div className="p-6 flex gap-6 w-screen h-screen">
      <div className="w-[26.67%] bg-gray-800 p-6 rounded-lg flex flex-col">
        <h1 className="text-3xl font-bold mb-4">Truy vấn</h1>
        <SearchModeSelector searchType={searchType} setSearchType={setSearchType} />
        {searchType === "File" && (
          <FileInputSection
            path={path}
            setPath={setPath}
            fileContent={fileContent}
            setFileContent={setFileContent}
            setShowModal={setShowModal}
            setHeaders={setHeaders}
          />
        )}
        <TextInputSection
          searchString={searchString}
          setSearchString={setSearchString}
          searchType={searchType}
        />
        <div className="mb-4">
          <label className="block mb-1">Truy vấn tại camera:</label>
          <div className="max-h-24 overflow-y-auto">
            {availableCameras.map((camera) => (
              <label key={camera} className="flex items-center mb-2">
                <input
                  type="checkbox"
                  checked={selectedCameras.includes(camera)}
                  onChange={() => handleCameraSelection(camera)}
                  className="mr-2"
                />
                {camera}
              </label>
            ))}
          </div>
        </div>
        <TimeAndQuerySection
          startDate={startDate}
          setStartDate={setStartDate}
          endDate={endDate}
          setEndDate={setEndDate}
          defaultDays={defaultDays}
          setDefaultDays={setDefaultDays}
          searchString={searchString}
          searchType={searchType}
          fileContent={fileContent}
          results={results}
          setResults={setResults}
          setSelectedVideos={setSelectedVideos}
          setQueryCount={setQueryCount}
          setFoundCount={setFoundCount}
          foundCount={foundCount}
          onQuery={debouncedHandleQuery}
          isQuerying={isQuerying}
        />
      </div>
      <div className="w-[53.33%] bg-gray-800 p-6 rounded-lg flex flex-col">
        <div className="flex items-center mb-4">
          <h1 className="text-3xl font-bold mr-4">Kết quả</h1>
          {(trackingCodeCount > 0 || foundCount > 0) && (
            <span className="text-lg text-gray-300">
              (Truy vấn {trackingCodeCount}/ Tìm được {foundCount})
            </span>
          )}
        </div>
        <ResultList
          results={results}
          selectedVideos={selectedVideos}
          setSelectedVideos={setSelectedVideos}
          hasQueried={hasQueried}
        />
        <VideoCutter
          results={results}
          selectedVideos={selectedVideos}
          setResults={setResults}
          setSelectedVideos={setSelectedVideos}
        /> {/* Thay CutVideoSection bằng VideoCutter */}
      </div>
      <ColumnSelectorModal
        showModal={showModal}
        setShowModal={setShowModal}
        headers={headers}
        selectedColumn={selectedColumn}
        setSelectedColumn={setSelectedColumn}
        history={history}
        setHistory={setHistory}
        selectedPlatform={selectedPlatform}
        setSelectedPlatform={setSelectedPlatform}
        shopeeLabel={shopeeLabel}
        setShopeeLabel={setShopeeLabel}
        lazadaLabel={lazadaLabel}
        setLazadaLabel={setLazadaLabel}
        tiktokLabel={tiktokLabel}
        setTiktokLabel={setTiktokLabel}
        customLabel1={customLabel1}
        setCustomLabel1={setCustomLabel1}
        customLabel2={customLabel2}
        setCustomLabel2={setCustomLabel2}
        path={path}
        fileContent={fileContent}
        setSearchString={setSearchString}
        setSearchType={setSearchType}
      />
    </div>
  );
};

export default QueryComponent;
```
## 📄 File: `Title.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Title.js`

```javascript
const Title = ({ text }) => {
   return <h2 className="text-xl font-bold text-center mb-6 tracking-widest">{text}</h2>;
 };
 
 export default Title;
```
## 📄 File: `Account.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Account.js`

```javascript
const Account = () => {
   return (
     <div className="p-6">
       <h1 className="text-3xl font-bold">Tài khoản</h1>
       <p>Đây là trang Tài khoản. Nội dung sẽ được thêm sau.</p>
     </div>
   );
 };
 
 export default Account;
```
## 📄 File: `App.test.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/App.test.js`

```javascript
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});

```
## 📄 File: `VtrackConfig.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/VtrackConfig.js`

```javascript
import React from "react"; // Thêm import React
import useVtrackConfig from "./hooks/useVtrackConfig";
import GeneralInfoForm from "./components/config/GeneralInfoForm";
import ConfigForm from "./components/config/ConfigForm";
import CameraDialog from "./components/config/CameraDialog";
import ProcessingRegionForm from "./components/config/ProcessingRegionForm"; // Thêm import

const VtrackConfig = () => {
  const {
    fromTime,
    setFromTime,
    toTime,
    setToTime,
    country,
    setCountry,
    timezone,
    setTimezone,
    brandName,
    setBrandName,
    inputPath,
    setInputPath,
    outputPath,
    setOutputPath,
    workingDays,
    setWorkingDays,
    defaultDays,
    setDefaultDays,
    minPackingTime,
    setMinPackingTime,
    maxPackingTime,
    setMaxPackingTime,
    frameRate,
    setFrameRate,
    frameInterval,
    setFrameInterval,
    videoBuffer,
    setVideoBuffer,
    cameras,
    setCameras,
    selectedCameras,
    setSelectedCameras,
    showCameraDialog,
    setShowCameraDialog,
    error,
    setError,
    handleCountryChange,
    handleFromTimeChange,
    handleToTimeChange,
    handleWorkingDayChange,
    handleOpenExplorer,
    handleSaveGeneralInfo,
    handleSaveConfig,
    handleShowCameraDialog,
    handleCameraSelection,
    runDefaultOnStart,
    setRunDefaultOnStart,
  } = useVtrackConfig();

  // Thêm state cho ProcessingRegionForm
  const [videoPath, setVideoPath] = React.useState("");
  const [qrSize, setQrSize] = React.useState("");
  const handleAnalyzeRegions = () => {
    // Hàm tạm thời cho Bước 1
    console.log("Phân tích vùng:", videoPath, qrSize);
  };

  const countries = [
    "Việt Nam", "Nhật Bản", "Hàn Quốc", "Thái Lan", "Singapore",
    "Mỹ", "Anh", "Pháp", "Đức", "Úc"
  ];

  return (
    <div className="p-6 flex gap-6 w-[100%]">
      <GeneralInfoForm
        country={country}
        setCountry={setCountry}
        timezone={timezone}
        setTimezone={setTimezone}
        brandName={brandName}
        setBrandName={setBrandName}
        workingDays={workingDays}
        setWorkingDays={setWorkingDays}
        fromTime={fromTime}
        setFromTime={setFromTime}
        toTime={toTime}
        setToTime={setToTime}
        handleCountryChange={handleCountryChange}
        handleFromTimeChange={handleFromTimeChange}
        handleToTimeChange={handleToTimeChange}
        handleWorkingDayChange={handleWorkingDayChange}
        handleSaveGeneralInfo={handleSaveGeneralInfo}
        countries={countries}
      />
      <ConfigForm
        inputPath={inputPath}
        setInputPath={setInputPath}
        outputPath={outputPath}
        setOutputPath={setOutputPath}
        defaultDays={defaultDays}
        setDefaultDays={setDefaultDays}
        minPackingTime={minPackingTime}
        setMinPackingTime={setMinPackingTime}
        maxPackingTime={maxPackingTime}
        setMaxPackingTime={setMaxPackingTime}
        frameRate={frameRate}
        setFrameRate={setFrameRate}
        frameInterval={frameInterval}
        setFrameInterval={setFrameInterval}
        videoBuffer={videoBuffer}
        setVideoBuffer={setVideoBuffer}
        error={error}
        handleOpenExplorer={handleOpenExplorer}
        handleShowCameraDialog={handleShowCameraDialog}
        runDefaultOnStart={runDefaultOnStart}
        setRunDefaultOnStart={setRunDefaultOnStart}
      />
      <ProcessingRegionForm // Thêm component
        videoPath={videoPath}
        setVideoPath={setVideoPath}
        qrSize={qrSize}
        setQrSize={setQrSize}
        handleAnalyzeRegions={handleAnalyzeRegions}
      />
      <CameraDialog
        showCameraDialog={showCameraDialog}
        setShowCameraDialog={setShowCameraDialog}
        cameras={cameras}
        selectedCameras={selectedCameras}
        handleCameraSelection={handleCameraSelection}
        handleSaveConfig={handleSaveConfig}
      />
    </div>
  );
};

export default VtrackConfig;
```
## 📄 File: `Dashboard.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Dashboard.js`

```javascript
import Sidebar from "./Sidebar";
import VtrackConfig from "./VtrackConfig";
import QueryComponent from "./QueryComponent";
import Account from "./Account";
import ProgramTab from "./components/program/ProgramTab";
import useProgramLogic from "./hooks/useProgramLogic";

const Dashboard = ({ setActiveMenu, activeMenu }) => {
  const {
    runningCard,
    fileList,
    customPath,
    showConfirmButton,
    firstRunCompleted,
    handleRunStop,
    handleConfirmRun,
    isRunning,
    setCustomPath,
  } = useProgramLogic();

  return (
    <div className="flex min-h-screen bg-gray-900 text-white font-montserrat">
      <Sidebar setActiveMenu={setActiveMenu} activeMenu={activeMenu} />
      <div className="flex-1 p-6 w-full">
        {activeMenu === "Chương trình" ? (
          <ProgramTab
            runningCard={runningCard}
            fileList={fileList}
            customPath={customPath}
            showConfirmButton={showConfirmButton}
            firstRunCompleted={firstRunCompleted}
            handleRunStop={handleRunStop}
            handleConfirmRun={handleConfirmRun}
            isRunning={isRunning}
            setCustomPath={setCustomPath}
          />
        ) : activeMenu === "Cấu hình" ? (
          <VtrackConfig />
        ) : activeMenu === "Truy vấn" ? (
          <QueryComponent />
        ) : activeMenu === "Tài khoản" ? (
          <Account />
        ) : (
          <div>
            <h1 className="text-3xl font-bold">Đang phát triển: {activeMenu}</h1>
            <p>Nội dung cho {activeMenu} sẽ được thêm sau.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
```
## 📄 File: `api.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/api.js`

```javascript
import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8080",
});

export const getConfig = () => api.get("/config");
export const updateConfig = (configData) => api.post("/config", configData);
export const runQuery = (queryData) => api.post("/query", queryData);
export const runProgram = (programData) => api.post("/program", programData);
export const confirmRun = (confirmData) => api.post("/confirm-run", confirmData);
export const getCameras = () => api.get("/get-cameras");
export const cutVideos = (cutData) => api.post("/cut-videos", cutData);
export const analyzeRegions = (data) => api.post("/analyze-regions", data);
export const getFrames = (data) => api.post("/get-frames", data);
export const submitRois = (data) => api.post("/submit-rois", data);
export const sendHandDetection = (data) => api.post("/api/hand-detection", data);
export const getRoiFrame = () => api.get("/get-roi-frame");
export const getFinalRoiFrame = (cameraId, timestamp) => api.get(`/get-final-roi-frame?camera_id=${cameraId}&timestamp=${timestamp}`);

export default api;
```
## 📄 File: `setupTests.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/setupTests.js`

```javascript
// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';

```
## 📄 File: `App.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/App.js`

```javascript
import "@fontsource/montserrat";
import { useState } from "react";
import Dashboard from "./Dashboard";

function App() {
  const [activeMenu, setActiveMenu] = useState("Chương trình");
  return (
    <div className="flex min-h-screen bg-gray-900 text-white font-montserrat">
      <Dashboard setActiveMenu={setActiveMenu} activeMenu={activeMenu} />
    </div>
  );
}

export default App;
```
## 📄 File: `SearchModeSelector.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/ui/SearchModeSelector.js`

```javascript
const SearchModeSelector = ({ searchType, setSearchType }) => {
  return (
    <div className="mb-4">
      <label className="block mb-1">Loại tìm kiếm:</label>
      <div className="flex gap-4">
        <label className="flex items-center">
          <input
            type="radio"
            name="searchType"
            value="File"
            className="mr-1"
            checked={searchType === "File"}
            onChange={() => setSearchType("File")}
          />
          File
        </label>
        <label className="flex items-center">
          <input
            type="radio"
            name="searchType"
            value="Text"
            className="mr-1"
            checked={searchType === "Text"}
            onChange={() => setSearchType("Text")}
          />
          Text
        </label>
      </div>
    </div>
  );
};

export default SearchModeSelector;
```
## 📄 File: `Button.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/ui/Button.js`

```javascript
const Button = ({ text }) => {
   return (
     <button className="bg-red-600 text-white font-bold py-2 px-4 rounded mt-4">
       {text}
     </button>
   );
 };
 
 export default Button;
```
## 📄 File: `Card.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/ui/Card.js`

```javascript
import { useState } from "react";

const Card = ({ title, description, isRunning, onRunStop, onPathChange, isLocked }) => {
  const [path, setPath] = useState("");

  const handleOpenExplorer = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.onchange = (e) => {
      const selectedPath = e.target.files[0]?.name || "";
      setPath(selectedPath);
      if (onPathChange) {
        onPathChange(selectedPath);
      }
    };
    input.click();
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg flex flex-col items-center h-full">
      <h3 className="text-lg font-bold mb-2">{title}</h3>
      <p className="mb-4 text-center flex-1">{description}</p>
      <div className="mt-auto w-full flex flex-col items-center">
        {title === "Chỉ định" && (
          <div className="mb-4 w-full">
            <div className="relative w-full">
              <input
                type="text"
                value={path}
                onChange={(e) => {
                  setPath(e.target.value);
                  if (onPathChange) {
                    onPathChange(e.target.value);
                  }
                }}
                placeholder="Nhập đường dẫn file..."
                className="w-full p-2 rounded bg-gray-700 text-white"
              />
              <button
                type="button"
                onClick={handleOpenExplorer}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
              >
                ...
              </button>
            </div>
          </div>
        )}
        {isLocked || (title === "Lần đầu" && isRunning) ? (
          <button
            className="w-1/2 py-2 px-4 rounded font-bold text-white bg-gray-500"
            disabled
          >
            LOCKED
          </button>
        ) : (
          <button
            className={`w-1/2 py-2 px-4 rounded font-bold text-white ${
              isRunning && title !== "Lần đầu" ? "bg-[#E82127]" : "bg-[#00D4FF]"
            }`}
            onClick={onRunStop}
            disabled={title === "Chỉ định" && !path && !isRunning}
          >
            {(isRunning && title !== "Lần đầu") ? "STOP" : "RUN"}
          </button>
        )}
      </div>
    </div>
  );
};

export default Card;
```
## 📄 File: `ResultList.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/result/ResultList.js`

```javascript
import React from "react";

const ResultList = ({ results, selectedVideos, setSelectedVideos, hasQueried }) => {
  const handleSelectVideo = (eventId) => {
    if (selectedVideos.includes(eventId)) {
      setSelectedVideos(selectedVideos.filter((id) => id !== eventId));
    } else {
      setSelectedVideos([...selectedVideos, eventId]);
    }
  };

  React.useEffect(() => {
    if (results.length > 0) {
      const newSelectedVideos = results.map(event => event.event_id);
      setSelectedVideos(newSelectedVideos);
    }
  }, [results]);

  return (
    <div className="flex-1 mb-4 bg-gray-700 rounded p-2 overflow-y-auto">
      {hasQueried ? (
        results.length > 0 ? (
          results.map((event, index) => (
            <label key={event.event_id} className="flex items-center mb-2">
              <input
                type="checkbox"
                className="mr-2"
                checked={selectedVideos.includes(event.event_id)}
                onChange={() => handleSelectVideo(event.event_id)}
              />
              {`${index + 1}. ${event.video_file}`}
            </label>
          ))
        ) : (
          <p>Không có kết quả</p>
        )
      ) : (
        <p>Vui lòng thực hiện truy vấn</p>
      )}
    </div>
  );
};

export default ResultList;

```
## 📄 File: `CutVideoSection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/result/CutVideoSection.js`

```javascript
import api from "../../api"; // Thêm import api để gọi /cut-videos

const CutVideoSection = ({ results, selectedVideos, setResults, setSelectedVideos, cutVideos, setCutVideos }) => {
  const handleCutVideos = async () => {
    if (selectedVideos.length === 0) {
      alert("Vui lòng chọn ít nhất một sự kiện để cắt video.");
      return;
    }
    const videosToCut = results.filter((event) => selectedVideos.includes(event.event_id));
    try {
      const cutData = {
        selected_events: videosToCut,
      };
      const response = await api.post("/cut-videos", cutData); // Gọi API /cut-videos
      const cutFiles = response.data.cut_files || []; // Lấy danh sách file từ phản hồi
      setCutVideos(prev => [...prev, ...cutFiles]); // Tối ưu với prev
      setResults(results.filter((event) => !selectedVideos.includes(event.event_id)));
      setSelectedVideos([]);
    } catch (error) {
      console.error("Error cutting videos:", error);
      alert("Có lỗi xảy ra khi cắt video. Vui lòng thử lại.");
    }
  };

  const handleRefresh = () => {
    setResults([]);
    setSelectedVideos([]);
    setCutVideos([]); // Xóa danh sách video đã cắt
  };

  return (
    <>
      <div className="flex gap-4 mb-4">
        <button
          className="w-1/2 py-2 bg-red-600 text-white font-bold rounded"
          onClick={handleCutVideos}
        >
          Cắt Video
        </button>
        <button
          className="w-1/2 py-2 px-4 rounded font-bold text-white bg-[#00D4FF]"
          onClick={handleRefresh}
        >
          Refresh
        </button>
      </div>
      <div className="flex-1 bg-gray-700 rounded p-2 overflow-y-auto">
        {cutVideos.map((video, index) => (
          <label key={index} className="flex items-center mb-2">
            <input type="checkbox" className="mr-2" />
            {`${index + 1}. ${video}`}
          </label>
        ))}
      </div>
    </>
  );
};

export default CutVideoSection;
```
## 📄 File: `VideoCutter.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/result/VideoCutter.js`

```javascript
import { useState } from "react";
import api from "../../api"; // Điều chỉnh đường dẫn tương đối từ thư mục result

const VideoCutter = ({ results, selectedVideos, setResults, setSelectedVideos }) => {
  const [cutVideos, setCutVideos] = useState([]);
  const [selectedCutVideo, setSelectedCutVideo] = useState(null); // Thêm trạng thái để lưu video đã cắt được chọn

  // Hàm xử lý yêu cầu cắt video
  const handleCutVideos = async () => {
    if (selectedVideos.length === 0) {
      alert("Vui lòng chọn ít nhất một sự kiện để cắt video.");
      return;
    }
    try {
      const selectedEvents = results.filter(event => selectedVideos.includes(event.event_id));
      const cutData = {
        selected_events: selectedEvents,
        // tracking_codes_filter sẽ được thêm sau nếu cần từ QueryComponent
      };

      const response = await api.post("/cut-videos", cutData); // Gọi API cắt video
      const cutFiles = response.data.cut_files || [];

      setCutVideos(prev => [...prev, ...cutFiles]); // Cập nhật danh sách video đã cắt
      setResults(prev => prev.filter(event => !selectedVideos.includes(event.event_id))); // Xóa sự kiện đã cắt
      setSelectedVideos([]); // Reset danh sách chọn
    } catch (error) {
      console.error("Error cutting videos:", error);
      alert("Có lỗi xảy ra khi cắt video. Vui lòng thử lại.");
    }
  };

  const handleRefresh = () => {
    setResults([]);
    setSelectedVideos([]);
    setCutVideos([]);
    setSelectedCutVideo(null); // Reset video đã chọn khi refresh
  };

  // Hàm xử lý khi nhấn nút "Play Video"
  const handlePlayVideo = () => {
    if (!selectedCutVideo) {
      alert("Vui lòng chọn một video để phát");
      return;
    }
    alert(`Đang phát video "${selectedCutVideo}" được chọn`);
  };

  return (
    <>
      <div className="flex gap-4 mb-4">
        <button
          className="w-1/3 py-2 bg-red-600 text-white font-bold rounded"
          onClick={handleCutVideos}
        >
          Cắt Video
        </button>
        <button
          className="w-1/3 py-2 px-4 rounded font-bold text-white bg-[#00D4FF]"
          onClick={handleRefresh}
        >
          Refresh
        </button>
        <button
          className="w-1/3 py-2 px-4 rounded font-bold text-white bg-green-600"
          onClick={handlePlayVideo}
        >
          Play Video
        </button>
      </div>
      <div className="flex-1 bg-gray-700 rounded p-2 overflow-y-auto">
        {cutVideos.map((video, index) => (
          <label
            key={index}
            className="flex items-center mb-2 cursor-pointer hover:bg-gray-600 transition duration-300"
            onClick={() => setSelectedCutVideo(video)}
          >
            <input
              type="radio"
              name="cutVideo"
              className="mr-2"
              checked={selectedCutVideo === video}
              onChange={() => setSelectedCutVideo(video)}
            />
            <span className="flex-1 truncate">{`${index + 1}. ${video}`}</span>
          </label>
        ))}
      </div>
    </>
  );
};

export default VideoCutter;
```
## 📄 File: `ConfigForm.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/ConfigForm.js`

```javascript
const ConfigForm = ({
  inputPath,
  setInputPath,
  outputPath,
  setOutputPath,
  defaultDays,
  setDefaultDays,
  minPackingTime,
  setMinPackingTime,
  maxPackingTime,
  setMaxPackingTime,
  frameRate,
  setFrameRate,
  frameInterval,
  setFrameInterval,
  videoBuffer,
  setVideoBuffer,
  error,
  handleOpenExplorer,
  handleShowCameraDialog,
}) => {
  return (
    <div className="w-[25%] bg-gray-800 p-6 rounded-lg flex flex-col">
      <h1 className="text-3xl font-bold mb-4">Cấu hình</h1>
      {error && <div style={{ color: 'red' }}>{error}</div>}
      <div className="mb-4">
        <label className="block mb-1">Vị trí Input Video:</label>
        <div className="relative w-full">
          <input
            type="text"
            value={inputPath}
            onChange={(e) => setInputPath(e.target.value)}
            placeholder="Vị trí Input Video (e.g., /Users/annhu/vtrack_app/V_Track/Inputvideo)"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
          <button
            type="button"
            onClick={() => handleOpenExplorer("input")}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
          >
            ...
          </button>
        </div>
      </div>
      <div className="mb-4">
        <label className="block mb-1">Vị trí Output Video:</label>
        <div className="relative w-full">
          <input
            type="text"
            value={outputPath}
            onChange={(e) => setOutputPath(e.target.value)}
            placeholder="Vị trí Output Video (e.g., /Users/annhu/vtrack_app/V_Track/output_clips)"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
          <button
            type="button"
            onClick={() => handleOpenExplorer("output")}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
          >
            ...
          </button>
        </div>
      </div>
      <div className="flex flex-col gap-4 mb-4">
        <div>
          <label className="block mb-1">Thời gian lưu trữ (ngày):</label>
          <input
            type="number"
            value={defaultDays}
            onChange={(e) => setDefaultDays(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Thời gian đóng hàng nhanh nhất (giây):</label>
          <input
            type="number"
            value={minPackingTime}
            onChange={(e) => setMinPackingTime(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Thời gian đóng hàng chậm nhất (giây):</label>
          <input
            type="number"
            value={maxPackingTime}
            onChange={(e) => setMaxPackingTime(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Tốc độ frame:</label>
          <input
            type="number"
            value={frameRate}
            onChange={(e) => setFrameRate(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Khoảng cách Frame:</label>
          <input
            type="number"
            value={frameInterval}
            onChange={(e) => setFrameInterval(Number(e.target.value))}
            min="2"
            max="30"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Buffer Video (giây):</label>
          <input
            type="number"
            value={videoBuffer}
            onChange={(e) => setVideoBuffer(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
      </div>
      <div className="mt-auto flex justify-center">
        <button
          onClick={handleShowCameraDialog}
          className="w-1/2 py-2 bg-blue-600 text-white font-bold rounded"
        >
          Gửi
        </button>
      </div>
    </div>
  );
};

export default ConfigForm;
```
## 📄 File: `GeneralInfoForm.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/GeneralInfoForm.js`

```javascript
import DatePicker from "react-datepicker";

const GeneralInfoForm = ({
  country,
  setCountry,
  timezone,
  setTimezone,
  brandName,
  setBrandName,
  workingDays,
  setWorkingDays,
  fromTime,
  setFromTime,
  toTime,
  setToTime,
  handleCountryChange,
  handleFromTimeChange,
  handleToTimeChange,
  handleWorkingDayChange,
  handleSaveGeneralInfo,
  countries,
}) => {
  return (
    <div className="w-[25%] bg-gray-800 p-6 rounded-lg flex flex-col">
      <h1 className="text-3xl font-bold mb-4">Thông tin chung</h1>
      <div className="mb-4">
        <label className="block mb-1">Quốc gia:</label>
        <select
          value={country}
          onChange={handleCountryChange}
          className="w-full p-2 rounded bg-gray-700 text-white"
        >
          {countries.map((country) => (
            <option key={country} value={country}>
              {country}
            </option>
          ))}
        </select>
      </div>
      <div className="mb-4">
        <label className="block mb-1">Múi giờ:</label>
        <input
          type="text"
          value={timezone}
          readOnly
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <div className="mb-4">
        <label className="block mb-1">Tên thương hiệu:</label>
        <input
          type="text"
          value={brandName}
          onChange={(e) => setBrandName(e.target.value)}
          placeholder="Nhập tên thương hiệu"
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <div className="mb-4">
        <h3 className="text-lg font-bold mb-2">Ngày làm việc</h3>
        {["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"].map((day) => (
          <label key={day} className="flex items-center mb-2">
            <input
              type="checkbox"
              className="mr-2"
              onChange={() => handleWorkingDayChange(day)}
              checked={workingDays.includes(day)}
            />
            {day}
          </label>
        ))}
      </div>
      <div className="mb-4">
        <h3 className="text-lg font-bold mb-2">Thời gian làm việc</h3>
        <div className="flex gap-4">
          <div className="flex-1">
            <label className="block mb-1">Từ:</label>
            <DatePicker
              selected={fromTime}
              onChange={handleFromTimeChange}
              showTimeSelect
              showTimeSelectOnly
              timeIntervals={30}
              timeCaption="Giờ"
              dateFormat="HH:mm"
              className="w-full p-2 rounded bg-gray-700 text-white"
            />
          </div>
          <div className="flex-1">
            <label className="block mb-1">Đến:</label>
            <DatePicker
              selected={toTime}
              onChange={handleToTimeChange}
              showTimeSelect
              showTimeSelectOnly
              timeIntervals={30}
              timeCaption="Giờ"
              dateFormat="HH:mm"
              className="w-full p-2 rounded bg-gray-700 text-white"
            />
          </div>
        </div>
      </div>
      <div className="mt-auto flex justify-center">
        <button
          onClick={handleSaveGeneralInfo}
          className="w-1/2 py-2 bg-blue-600 text-white font-bold rounded"
        >
          Gửi
        </button>
      </div>
    </div>
  );
};

export default GeneralInfoForm;
```
## 📄 File: `ProcessingRegionForm.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/ProcessingRegionForm.js`

```javascript
import { useState, useEffect } from "react";
import api from "../../api";
import InstructionsPanel from "./InstructionsPanel";

const ProcessingRegionForm = ({ handleAnalyzeRegions }) => {
  const [videoPath, setVideoPath] = useState("");
  const [selectedVideoPath, setSelectedVideoPath] = useState("");
  const [error, setError] = useState("");
  const [analysisResult, setAnalysisResult] = useState(null);
  const [roiFramePath, setRoiFramePath] = useState("");
  const [showResultModal, setShowResultModal] = useState(false);
  const [cameraList, setCameraList] = useState([]);
  const [selectedCamera, setSelectedCamera] = useState("");
  const [processedCameras, setProcessedCameras] = useState([]);

  useEffect(() => {
    handleGetCameras();
  }, []);

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      const path = file.path || file.name;
      setVideoPath(path);
      setSelectedVideoPath(path);
      setError("");
    } else {
      setVideoPath("");
      setSelectedVideoPath("");
    }
  };

  const handleGetCameras = async () => {
    try {
      const response = await api.get("/get-cameras");
      setCameraList(response.data.cameras || []);
      setError("");
    } catch (err) {
      setError("Không thể lấy danh sách camera.");
    }
  };

  const handleSelectCamera = (camera) => {
    setSelectedCamera(camera);
    setVideoPath("");
    setSelectedVideoPath("");
    setError("");
  };

  const handleContinue = async () => {
    if (!videoPath && !selectedVideoPath) {
      setError("Vui lòng chọn video baseline.");
      return;
    }
    if (!selectedCamera) {
      setError("Vui lòng chọn một camera.");
      return;
    }
    try {
      const response = await fetch('http://127.0.0.1:8080/run-select-roi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoPath: selectedVideoPath || videoPath, cameraId: selectedCamera })
      });
      const result = await response.json();
      console.log("Result from run-select-roi:", result);
      if (result.success) {
        const newAnalysisResult = {
          success: true,
          message: result.message || "Hand detection completed successfully",
          roi: result.roi,
          hand_detected: result.hand_detected,
          roi_frame: result.roi_frame
        };
        console.log("Setting analysisResult in handleContinue:", newAnalysisResult);
        setAnalysisResult(newAnalysisResult);
        setRoiFramePath(result.roi_frame); // Lưu roiFramePath
        setShowResultModal(true);
      } else {
        setError(result.error || "Không thể chạy hand detection.");
      }
    } catch (err) {
      setError("Lỗi khi chạy hand detection: " + err.message);
    }
  };

  const handleRetry = async () => {
    if (!selectedVideoPath && !videoPath) {
      setError("Vui lòng chọn video baseline.");
      return;
    }
    try {
      const response = await fetch('http://127.0.0.1:8080/run-select-roi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoPath: selectedVideoPath || videoPath, cameraId: selectedCamera })
      });
      const result = await response.json();
      console.log("Result from run-select-roi (retry):", result);
      if (result.success) {
        const newAnalysisResult = {
          success: true,
          message: result.message || "Hand detection completed successfully",
          roi: result.roi,
          hand_detected: result.hand_detected,
          roi_frame: result.roi_frame
        };
        console.log("Setting analysisResult in handleRetry:", newAnalysisResult);
        setAnalysisResult(newAnalysisResult);
        setRoiFramePath(result.roi_frame); // Cập nhật roiFramePath với file mới nhất
        setShowResultModal(true);
      } else {
        setError(result.error || "Không thể chạy hand detection.");
      }
    } catch (err) {
      setError("Lỗi khi chạy hand detection: " + err.message);
    }
  };

  const handleRoisSubmit = (rois) => {
    setProcessedCameras((prev) => [...new Set([...prev, selectedCamera])]);
    setSelectedCamera("");
  };

  const handleContinueWithAnotherCamera = () => {
    setAnalysisResult(null);
    setRoiFramePath("");
    setShowResultModal(false);
    setSelectedCamera("");
    setVideoPath("");
    setSelectedVideoPath("");
    setError("");
  };

  const handleExit = () => {
    setShowResultModal(false);
    handleAnalyzeRegions({
      success: true,
      message: "Đã hoàn tất xử lý các camera.",
      processedCameras,
    });
  };

  return (
    <div className="w-[25%] bg-gray-800 p-6 rounded-lg flex flex-col">
      <h1 className="text-3xl font-bold mb-4">Vùng xử lý</h1>
      <p className="text-gray-300 mb-4">
        Tải lên video baseline (5s-5 phút) để xác định các vùng xử lý QR và đóng gói.
      </p>
      <div className="mb-4">
        <button
          onClick={handleGetCameras}
          className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded"
        >
          Lấy danh sách camera
        </button>
      </div>
      {cameraList && cameraList.length > 0 && (
        <div className="mb-4">
          <h3 className="text-lg font-bold mb-2">Chọn camera:</h3>
          <div className="max-h-24 overflow-y-auto">
            {cameraList.map((camera) => (
              <label key={camera} className="flex items-center mb-2">
                <input
                  type="radio"
                  name="camera"
                  className="mr-2"
                  checked={selectedCamera === camera}
                  onChange={() => handleSelectCamera(camera)}
                  disabled={processedCameras.includes(camera)}
                />
                {camera}
                {processedCameras.includes(camera) && (
                  <span className="ml-2 text-green-500">✔ Đã xử lý</span>
                )}
              </label>
            ))}
          </div>
        </div>
      )}
      <div className="mb-4">
        <label className="block mb-1">Video baseline:</label>
        <div className="relative w-full">
          <input
            type="text"
            value={videoPath}
            onChange={(e) => {
              setVideoPath(e.target.value);
              setSelectedVideoPath(e.target.value);
            }}
            placeholder="Chọn video (e.g., /Users/annhu/vtrack_app/V_Track/baseline.mp4)"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
          <button
            type="button"
            onClick={() => {
              const input = document.createElement("input");
              input.type = "file";
              input.accept = "video/*";
              input.onchange = handleFileSelect;
              input.click();
            }}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
          >
            ...
          </button>
        </div>
      </div>
      {videoPath && selectedCamera && (
        <div className="mb-4 flex justify-center">
          <button
            onClick={handleContinue}
            className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded"
          >
            Tiếp tục
          </button>
        </div>
      )}
      {showResultModal && analysisResult && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg w-3/4 h-3/4 flex">
            <InstructionsPanel
              customInstruction={
                analysisResult.qr_detected
                  ? "Tiếp tục xác định vùng trigger."
                  : "Vẽ lại vùng mã vận đơn hoặc nhấn Tiếp tục để đồng ý với vùng hiện tại."
              }
              analysisResult={analysisResult}
              handDetected={analysisResult.hand_detected}
              qrDetected={analysisResult.qr_detected}
              onClose={handleExit}
              onSave={handleContinueWithAnotherCamera}
              onRetry={handleRetry}
              errorMessage={error}
              videoPath={selectedVideoPath || videoPath}
              cameraId={selectedCamera}
              onSubmit={handleRoisSubmit}
              setAnalysisResult={setAnalysisResult}
              roiFramePath={roiFramePath}
            />
          </div>
        </div>
      )}
      {error && (
        <div className="mb-4 text-red-500 text-sm">{error}</div>
      )}
    </div>
  );
};

export default ProcessingRegionForm;

```
## 📄 File: `InstructionsPanel.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/InstructionsPanel.js`

```javascript
import React, { useState, useEffect } from 'react';
import { getFinalRoiFrame } from "../../api";

const InstructionsPanel = ({
  step,
  customInstruction,
  analysisResult,
  errorMessage,
  onSave,
  onClose,
  onRetry,
  handDetected,
  videoPath,
  cameraId,
  onSubmit,
  setAnalysisResult,
  roiFramePath,
}) => {
  const [roiFrameSrc, setRoiFrameSrc] = useState(null);
  const [finalRoiFrameSrc, setFinalRoiFrameSrc] = useState(null);
  const [rois, setRois] = useState([]);
  const [internalError, setInternalError] = useState("");
  const [currentStep, setCurrentStep] = useState("packing");
  const [roiImageState, setRoiImageState] = useState({
    step: "packing",
    file: "roi_packing.jpg",
    ready: false,
  });
  const [imageAspectRatio, setImageAspectRatio] = useState(null);

  const loadRoiImage = async (fileSuffix, retryCount = 0, maxRetries = 3) => {
    try {
      if (!cameraId) {
        console.error("Missing cameraId", { cameraId });
        setInternalError("Thiếu cameraId.");
        return;
      }

      console.log(`Loading ROI image with camera_id: ${cameraId}, file: ${fileSuffix}`);
      const timestamp = new Date().getTime();
      const url = `http://localhost:8080/get-roi-frame?camera_id=${cameraId}&file=${fileSuffix}&t=${timestamp}`;
      const response = await fetch(url, {
        headers: { 'Cache-Control': 'no-cache' },
      });
      if (!response.ok && response.status !== 304) {
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }
      console.log("Response from /get-roi-frame:", response);
      setRoiFrameSrc(url);
      setRoiImageState({ step: currentStep, file: fileSuffix, ready: true });
      console.log("roiFrameSrc updated to:", url);
    } catch (error) {
      console.error("Error loading ROI image:", error);
      if (retryCount < maxRetries) {
        console.log(`Retrying loadRoiImage (${retryCount + 1}/${maxRetries})...`);
        setTimeout(() => loadRoiImage(fileSuffix, retryCount + 1, maxRetries), 500);
      } else {
        setInternalError(`Không thể tải ảnh tạm: ${error.message}. Vui lòng thử lại.`);
      }
    }
  };

  useEffect(() => {
    console.log("useEffect triggered with analysisResult:", analysisResult, "currentStep:", currentStep, "roiImageState:", roiImageState);
    if (analysisResult && analysisResult.roi_frame && roiImageState.ready) {
      loadRoiImage(roiImageState.file);
    } else if (currentStep === "packing" && analysisResult?.roi_frame) {
      loadRoiImage("roi_packing.jpg");
    }
  }, [analysisResult, currentStep, roiImageState.ready]);

  const fetchFinalRoiFrame = async () => {
    try {
      console.log(`Calling /get-final-roi-frame with camera_id: ${cameraId}`);
      const timestamp = new Date().getTime();
      const url = `http://localhost:8080/get-final-roi-frame?camera_id=${cameraId}&t=${timestamp}`;
      const response = await fetch(url, {
        headers: { 'Cache-Control': 'no-cache' },
      });
      if (!response.ok && response.status !== 304) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      console.log("Response from /get-final-roi-frame:", response);
      setFinalRoiFrameSrc(url);
    } catch (error) {
      console.error("Error fetching final ROI frame:", error);
      setInternalError("Không thể tải ảnh tổng hợp. Vui lòng thử lại.");
    }
  };

  const handleConfirmRoi = async () => {
    if (currentStep === "packing" && analysisResult?.roi) {
      if (!analysisResult || typeof analysisResult.hand_detected === "undefined") {
        setInternalError("Không tìm thấy thông tin phát hiện tay từ backend. Vui lòng thử lại.");
        return;
      }
      if (!analysisResult.hand_detected) {
        setInternalError("Không phát hiện tay. Vui lòng vẽ lại vùng packing hoặc thoát.");
        return;
      }
      if (!analysisResult.roi_frame) {
        setInternalError("Thiếu đường dẫn ảnh tạm packing. Vui lòng thử lại.");
        return;
      }

      const newRoi = { type: currentStep, ...analysisResult.roi };
      const updatedRois = [...rois, newRoi];
      setRois(updatedRois);
      setCurrentStep("mvd");
      setRoiImageState({ step: "mvd", file: "roi_packing.jpg", ready: true });
      try {
        console.log("Calling /run-qr-detector for mvd step with videoPath:", videoPath, "cameraId:", cameraId, "roiFramePath:", analysisResult.roi_frame);
        const response = await fetch('http://localhost:8080/run-qr-detector', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ videoPath, cameraId, roiFramePath: analysisResult.roi_frame }),
        });
        const result = await response.json();
        console.log("Result from /run-qr-detector (mvd):", result);
        if (result.success) {
          const tempResult = {
            success: true,
            message: result.message || "QR detection completed successfully",
            rois: result.rois,
            qr_detected: result.qr_detected,
            qr_detected_roi1: result.qr_detected_roi1,
            qr_detected_roi2: result.qr_detected_roi2,
            roi_frame: result.roi_frame,
            qr_content: result.qr_content,
            trigger_detected: result.trigger_detected,
            table_type: result.table_type,
          };
        
          if (result.roi_frame) {
            setRoiImageState({ step: "mvd", file: "roi_MVD.jpg", ready: true });
            await loadRoiImage("roi_MVD.jpg");
            setAnalysisResult(tempResult); // Chỉ set sau khi ảnh tải xong
          } else {
            console.log("No roi_frame in result, keeping roi_packing.jpg");
            setAnalysisResult(tempResult);
          }
        } else {
          setInternalError(result.error || "Không thể vẽ vùng mã vận đơn.");
        }
      } catch (error) {
        setInternalError("Lỗi khi vẽ vùng mã vận đơn: " + error.message);
      }
    } else if (currentStep === "mvd" && analysisResult?.rois) {
      if (!analysisResult || typeof analysisResult.qr_detected === "undefined") {
        setInternalError("Không tìm thấy thông tin phát hiện QR từ backend. Vui lòng thử lại.");
        return;
      }
      if (!analysisResult.qr_detected) {
        setInternalError("Không phát hiện mã QR. Vui lòng vẽ lại vùng MVD hoặc thoát.");
        return;
      }
      if (!analysisResult.roi_frame) {
        setInternalError("Thiếu đường dẫn ảnh tạm MVD. Vui lòng thử lại.");
        return;
      }

      const newRois = analysisResult.rois.map((roi) => ({ type: currentStep, ...roi }));
      const updatedRois = [...rois, ...newRois];
      setRois(updatedRois);
      setCurrentStep("done");
      try {
        const response = await fetch('http://localhost:8080/finalize-roi', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ videoPath, cameraId, rois: updatedRois }),
        });
        const result = await response.json();
        if (result.success) {
          await fetchFinalRoiFrame();
          onSubmit(updatedRois);
          onSave();
        } else {
          setInternalError(result.error || "Không thể tạo ảnh tổng hợp.");
        }
      } catch (error) {
        setInternalError("Lỗi khi tạo ảnh tổng hợp: " + error.message);
      }
    }
    if (currentStep === "done") {
      onSave();
    }
  };

  const handleRetryStep = async () => {
    if (!videoPath || !cameraId) {
      setInternalError("Thiếu videoPath hoặc cameraId.");
      return;
    }

    try {
      if (currentStep === "packing") {
        console.log("Calling /run-select-roi for retry with videoPath:", videoPath, "cameraId:", cameraId);
        const response = await fetch('http://localhost:8080/run-select-roi', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ videoPath, cameraId }),
        });
        const result = await response.json();
        console.log("Result from /run-select-roi (retry):", result);
        if (result.success) {
          const newAnalysisResult = {
            success: true,
            message: result.message || "Hand detection completed successfully",
            roi: result.roi,
            hand_detected: result.hand_detected,
            roi_frame: result.roi_frame,
          };
          setAnalysisResult(newAnalysisResult);
          if (result.roi_frame) {
            setRoiImageState({ step: "packing", file: "roi_packing.jpg", ready: true });
            await loadRoiImage("roi_packing.jpg");
          }
        } else {
          setInternalError(result.error || `Không thể chạy lại hand detection.`);
        }
      } else if (currentStep === "mvd") {
        console.log("Calling /run-qr-detector for retry with videoPath:", videoPath, "cameraId:", cameraId, "roiFramePath:", analysisResult.roi_frame);
        const response = await fetch('http://localhost:8080/run-qr-detector', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ videoPath, cameraId, roiFramePath: analysisResult.roi_frame }),
        });
        const result = await response.json();
        console.log("Result from /run-qr-detector (retry):", result);
        if (result.success) {
          const newAnalysisResult = {
            success: true,
            message: result.message || "QR detection completed successfully",
            rois: result.rois,
            qr_detected: result.qr_detected,
            qr_detected_roi1: result.qr_detected_roi1,
            qr_detected_roi2: result.qr_detected_roi2,
            qr_content: result.qr_content,
            roi_frame: result.roi_frame,
            trigger_detected: result.trigger_detected,
            table_type: result.table_type,
          };
          setAnalysisResult(newAnalysisResult);
          if (result.roi_frame && result.qr_detected) {
            setRoiImageState({ step: "mvd", file: "roi_MVD.jpg", ready: true });
            await loadRoiImage("roi_MVD.jpg");
          } else {
            setInternalError("Không thể tải ảnh hoặc không phát hiện QR.");
          }
        } else {
          setInternalError(result.error || `Không thể chạy lại QR detection.`);
        }
      }
    } catch (error) {
      setInternalError(`Lỗi khi chạy lại: ${error.message}`);
    }
  };

  const handleImageLoad = (e) => {
    const { width, height } = e.target;
    setImageAspectRatio(width / height);
  };

  return (
    <div className="flex w-full h-full">
      <div className="w-1/4 pr-4 flex flex-col border-r-2 border-gray-500">
        <div className="mb-4">
          <h3 className="text-2xl font-bold mb-2 text-white">Kết quả</h3>
          {currentStep === "mvd" ? (
            <>
              {analysisResult?.table_type === "standard" ? (
                <>
                  <div className={`p-2 rounded text-white flex items-center ${analysisResult?.trigger_detected ? 'bg-green-600' : 'bg-red-600'}`}>
                    <span className="mr-2">{analysisResult?.trigger_detected ? '✔' : '✘'}</span>
                    <p>ROI Trigger: {analysisResult?.trigger_detected ? 'Có' : 'Không'}</p>
                  </div>
                  <div className={`p-2 rounded text-white flex items-center mt-2 ${analysisResult?.qr_detected_roi1 ? 'bg-green-600' : 'bg-red-600'}`}>
                    <span className="mr-2">{analysisResult?.qr_detected_roi1 ? '✔' : '✘'}</span>
                    <p>ROI MVD: {analysisResult?.qr_detected_roi1 ? 'Có' : 'Không'}</p>
                  </div>
                </>
              ) : (
                <>
                  {typeof analysisResult?.qr_detected_roi1 !== 'undefined' && (
                    <div className={`p-2 rounded text-white flex items-center ${analysisResult?.qr_detected_roi1 ? 'bg-green-600' : 'bg-red-600'}`}>
                      <span className="mr-2">{analysisResult?.qr_detected_roi1 ? '✔' : '✘'}</span>
                      <p>ROI 1: {analysisResult?.qr_detected_roi1 ? 'Có' : 'Không'}</p>
                    </div>
                  )}
                </>
              )}
            </>
          ) : (
            <div className={`p-2 rounded text-white flex items-center ${handDetected ? 'bg-green-600' : 'bg-red-600'}`}>
              <span className="mr-2">{handDetected ? '✔' : '✘'}</span>
              <p>{handDetected ? `Xác nhận vùng ${currentStep}` : 'Không phát hiện chuyển động'}</p>
            </div>
          )}
          {errorMessage && (
            <div className="mt-2 p-2 bg-red-600 rounded text-white">
              <p>{errorMessage}</p>
            </div>
          )}
          {internalError && (
            <div className="mt-2 p-2 bg-red-600 rounded text-white">
              <p>{internalError}</p>
            </div>
          )}
        </div>
        <div className="mb-4 flex-1">
          <h3 className="text-xl font-bold mb-2 text-white">Hướng dẫn</h3>
          <p className="text-gray-300 text-lg">
            {currentStep === "done"
              ? "Đã hoàn tất vẽ vùng và phát hiện mã QR. Nhấn Thoát để tiếp tục."
              : currentStep === "mvd"
                ? analysisResult?.qr_detected
                  ? "Đã tìm thấy mã QR. Nhấn Hoàn tất để lưu và tiếp tục."
                  : "Vẽ lại vùng mã vận đơn hoặc thoát."
                : handDetected
                  ? "Tiếp tục xác định vùng mã vận đơn."
                  : "Vẽ lại vùng packing hoặc thoát."}
          </p>
        </div>
        <div className="mt-auto space-y-2">
          {currentStep !== "done" && (
            <button
              onClick={handleRetryStep}
              className="w-full py-2 bg-yellow-600 hover:bg-yellow-700 text-white font-bold rounded"
            >
              Vẽ lại
            </button>
          )}
          {currentStep === "mvd" && analysisResult?.qr_detected && (
            <button
              onClick={handleConfirmRoi}
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded"
            >
              Hoàn tất
            </button>
          )}
          {currentStep === "packing" && handDetected && (
            <button
              onClick={handleConfirmRoi}
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded"
            >
              Tiếp tục
            </button>
          )}
          <button
            onClick={onClose}
            className="w-full py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded"
          >
            Thoát
          </button>
        </div>
      </div>
      <div className="w-3/4 pl-4 flex flex-col">
        <div className="mb-4 flex justify-center items-center" style={{ maxHeight: 'calc(75vh - 2rem)', overflow: 'hidden' }}>
          {console.log("Rendering ROI frame with roiFrameSrc:", roiFrameSrc, "roiImageState:", roiImageState)}
          {roiFrameSrc && (
            <img 
              src={roiFrameSrc} 
              alt="ROI Frame" 
              className={`max-w-full max-h-full rounded ${imageAspectRatio && imageAspectRatio < 1 ? 'portrait' : 'landscape'}`}
              onLoad={handleImageLoad}
            />
          )}
        </div>
        {finalRoiFrameSrc && currentStep === "done" && (
          <div className="mb-4 flex justify-center items-center" style={{ maxHeight: 'calc(75vh - 2rem)', overflow: 'hidden' }}>
            <h4 className="text-lg font-bold text-white">Ảnh tổng hợp:</h4>
            <img 
              src={finalRoiFrameSrc} 
              alt="Final ROI Frame" 
              className={`max-w-full max-h-full rounded ${imageAspectRatio && imageAspectRatio < 1 ? 'portrait' : 'landscape'}`}
              onLoad={handleImageLoad}
            />
          </div>
        )}
      </div>
      <style jsx>{`
        .max-w-full {
          max-width: 100%;
        }
        .max-h-full {
          max-height: 100%;
        }
        .landscape {
          object-fit: contain;
          width: 100%;
        }
        .portrait {
          object-fit: contain;
          height: 100%;
        }
      `}</style>
    </div>
  );
};

export default InstructionsPanel;
```
## 📄 File: `CameraDialog.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/CameraDialog.js`

```javascript
const CameraDialog = ({
  showCameraDialog,
  setShowCameraDialog,
  cameras,
  selectedCameras,
  handleCameraSelection,
  handleSaveConfig,
}) => {
  if (!showCameraDialog) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-gray-800 p-6 rounded-lg w-1/2">
        <h2 className="text-2xl font-bold mb-4 text-white">Xác nhận camera</h2>
        <div className="max-h-64 overflow-y-auto">
          {cameras.map((camera) => (
            <label key={camera.name} className="flex items-center mb-2 text-white">
              <input
                type="checkbox"
                className="mr-2"
                checked={selectedCameras.includes(camera.name)}
                onChange={() => handleCameraSelection(camera.name)}
              />
              {camera.name} ({camera.path})
            </label>
          ))}
        </div>
        <div className="mt-4 flex justify-end gap-4">
          <button
            onClick={() => setShowCameraDialog(false)}
            className="py-2 px-4 bg-gray-600 text-white font-bold rounded"
          >
            Hủy
          </button>
          <button
            onClick={handleSaveConfig}
            className="py-2 px-4 bg-blue-600 text-white font-bold rounded"
          >
            Xác nhận
          </button>
        </div>
      </div>
    </div>
  );
};

export default CameraDialog;
```
## 📄 File: `FileList.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/program/FileList.js`

```javascript
const FileList = ({ fileList }) => {
  if (!fileList || fileList.length === 0) {
    return (
      <div className="mt-4">
        <h3 className="text-lg font-bold">Kết quả:</h3>
        <p>Không có file nào để hiển thị.</p>
      </div>
    );
  }

  return (
    <div className="mt-4">
      <h3 className="text-lg font-bold">Kết quả:</h3>
      <ul className="list-disc pl-5">
        {fileList.map((item, index) => (
          <li key={index}>{`${item.file}: ${item.status}`}</li>
        ))}
      </ul>
    </div>
  );
};

export default FileList;
```
## 📄 File: `ProgramTab.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/program/ProgramTab.js`

```javascript
import { useState, useEffect } from "react";
import Card from "../ui/Card";
import FileList from "./FileList";

const ProgramTab = ({
  runningCard,
  fileList,
  customPath,
  firstRunCompleted,
  handleRunStop,
  isRunning,
  setCustomPath,
}) => {
  const [updatedFileList, setUpdatedFileList] = useState(fileList);

  useEffect(() => {
    const fetchProgress = async () => {
      try {
        const response = await fetch("http://localhost:8080/program-progress", {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        });
        const data = await response.json();
        if (response.ok) {
          setUpdatedFileList(data.files);
        } else {
          console.error("Failed to fetch program progress:", data.error);
        }
      } catch (error) {
        console.error("Error fetching program progress:", error);
      }
    };

    fetchProgress();
    const intervalId = setInterval(fetchProgress, 10000);
    const timeoutId = setTimeout(() => {
      clearInterval(intervalId);
      console.log("Stopped polling /program-progress after 2 minutes");
    }, 120000);

    return () => {
      clearInterval(intervalId);
      clearTimeout(timeoutId);
    };
  }, [runningCard]);

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-3 gap-6">
        {!firstRunCompleted && (
          <Card
            title="Lần đầu"
            description="Chạy lần đầu để xử lý dữ liệu cơ sở."
            isRunning={isRunning("Lần đầu")}
            onRunStop={firstRunCompleted ? null : () => handleRunStop("Lần đầu")}
            isLocked={firstRunCompleted}
          />
        )}
        <Card
          title="Mặc định"
          description="Chạy khi khởi động, chạy nền."
          isRunning={isRunning("Mặc định")}
          onRunStop={() => handleRunStop("Mặc định")}
        />
        <Card
          title="Chỉ định"
          description="Chỉ định file cụ thể."
          isRunning={isRunning("Chỉ định")}
          onRunStop={() => handleRunStop("Chỉ định", customPath)}
          onPathChange={(path) => setCustomPath(path)}
        />
      </div>
      <FileList fileList={updatedFileList} />
    </div>
  );
};

export default ProgramTab;
```
## 📄 File: `TextInputSection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/TextInputSection.js`

```javascript
const TextInputSection = ({ searchString, setSearchString, searchType }) => {
  const handleTextInputChange = (e) => {
    const value = e.target.value;
    const lines = value.split("\n");
    const codes = [];
    
    lines.forEach(line => {
      const trimmedLine = line.trim();
      if (!trimmedLine) return;
      const match = trimmedLine.match(/^\d+\.\s*(.+)$/);
      const lineContent = match ? match[1].trim() : trimmedLine;
      const lineCodes = lineContent.split(";").map(code => code.trim()).filter(code => code);
      codes.push(...lineCodes);
    });

    let formattedCodes = codes
      .map((code, index) => `${index + 1}. ${code}`)
      .join("\n");

    if (value.endsWith("\n")) {
      formattedCodes += `\n${codes.length + 1}. `;
    }

    setSearchString(formattedCodes);
  };

  return (
    <textarea
      value={searchString}
      onChange={handleTextInputChange}
      placeholder="Nhập chuỗi tìm kiếm (mỗi mã trên một dòng)"
      className="w-full p-2 mb-4 rounded bg-gray-700 text-white h-1/2 overflow-y-auto whitespace-pre-wrap resize-none"
      disabled={searchType === "File"}
    />
  );
};

export default TextInputSection;
```
## 📄 File: `TimeAndQuerySection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/TimeAndQuerySection.js`

```javascript
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const TimeAndQuerySection = ({
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  defaultDays,
  setDefaultDays,
  searchString,
  searchType,
  fileContent,
  results,
  setResults,
  setSelectedVideos,
  setQueryCount,
  setFoundCount,
  foundCount,
  onQuery, // Prop để nhận hàm debounce từ QueryComponent
  isQuerying, // Prop để vô hiệu hóa nút
}) => {
  const handleStartDateChange = (date) => {
    setStartDate(date);
    if (endDate) {
      const diffDays = (endDate - date) / (1000 * 60 * 60 * 24);
      if (diffDays > 30) {
        setEndDate(new Date(date.getTime() + 30 * 24 * 60 * 60 * 1000));
      } else if (date > endDate) {
        setEndDate(date);
      }
    }
  };

  const handleEndDateChange = (date) => {
    const today = new Date();
    if (date > today) {
      date = today;
    }
    if (startDate) {
      const diffDays = (date - startDate) / (1000 * 60 * 60 * 24);
      if (diffDays > 30) {
        setStartDate(new Date(date.getTime() - 30 * 24 * 60 * 60 * 1000));
      } else if (date < startDate) {
        setStartDate(date);
      }
    }
    setEndDate(date);
  };

  return (
    <>
      <div className="mb-4">
        <label className="block mb-1">Thời gian mặc định (ngày):</label>
        <input
          type="number"
          value={defaultDays}
          onChange={(e) => setDefaultDays(Number(e.target.value))}
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <div className="flex gap-4 mb-4">
        <div className="flex-1">
          <label className="block mb-1">Từ:</label>
          <DatePicker
            selected={startDate}
            onChange={handleStartDateChange}
            showTimeSelect
            timeIntervals={60}
            dateFormat="Pp"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div className="flex-1">
          <label className="block mb-1">Đến:</label>
          <DatePicker
            selected={endDate}
            onChange={handleEndDateChange}
            showTimeSelect
            timeIntervals={60}
            dateFormat="Pp"
            maxDate={new Date()}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
      </div>
      <button
        onClick={onQuery} // Dùng onQuery từ props
        disabled={isQuerying} // Vô hiệu hóa nút khi đang xử lý
        className={`w-full py-2 bg-green-600 text-white font-bold rounded ${isQuerying ? "opacity-50 cursor-not-allowed" : ""}`}
      >
        Truy vấn
      </button>
    </>
  );
};

export default TimeAndQuerySection;
```
## 📄 File: `FileInputSection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/FileInputSection.js`

```javascript
const FileInputSection = ({ path, setPath, fileContent, setFileContent, setShowModal, setHeaders }) => {
  const handleOpenExplorer = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".csv,.xlsx";
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const fileName = file.name.toLowerCase();
      const fileType = file.type;

      // Kiểm tra đuôi file
      if (!fileName.endsWith(".csv") && !fileName.endsWith(".xlsx")) {
        alert("Vui lòng chọn file CSV hoặc Excel (.csv, .xlsx)");
        return;
      }

      // Kiểm tra MIME type
      const validCsvMimeTypes = ["text/csv", "application/csv"];
      const validXlsxMimeTypes = [
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-excel",
      ];
      if (fileName.endsWith(".csv") && !validCsvMimeTypes.includes(fileType)) {
        alert("File không đúng định dạng CSV. Vui lòng chọn file CSV hợp lệ.");
        return;
      }
      if (fileName.endsWith(".xlsx") && !validXlsxMimeTypes.includes(fileType)) {
        alert("File không đúng định dạng Excel. Vui lòng chọn file XLSX hợp lệ.");
        return;
      }

      setPath(file.name);

      const reader = new FileReader();
      reader.onload = (event) => {
        const arrayBuffer = event.target.result;
        const bytes = new Uint8Array(arrayBuffer);
        const binary = Array.from(bytes).map((b) => String.fromCharCode(b)).join("");
        const base64 = btoa(binary); // Base64 encode từ nhị phân
        setFileContent(base64);
      };
      reader.onerror = () => {
        alert("Lỗi khi đọc file");
      };
      reader.readAsArrayBuffer(file); // Đọc raw binary
    };
    input.click();
  };

  const handleConfirmFile = async () => {
    if (!path) {
      alert("Vui lòng chọn file CSV hoặc nhập đường dẫn");
      return;
    }
    try {
      const response = await fetch("http://localhost:8080/get-csv-headers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          file_path: path,
          file_content: fileContent || "",
          is_excel: path.toLowerCase().endsWith(".xlsx"),
        }),
      });
      const result = await response.json();
      if (response.ok) {
        setHeaders(result.headers || []);
        setShowModal(true);
      } else {
        throw new Error(result.error || "Failed to get CSV headers");
      }
    } catch (error) {
      console.error("Error getting CSV headers:", error);
      alert(error.message || "Failed to get CSV headers");
    }
  };

  return (
    <div className="mb-4">
      <div className="relative w-full mb-2">
        <input
          type="text"
          value={path}
          onChange={(e) => setPath(e.target.value)}
          placeholder="Chọn file định dạng *.csv hoặc *.xlsx"
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
        <button
          type="button"
          onClick={handleOpenExplorer}
          className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
        >
          ...
        </button>
      </div>
      <button
        onClick={handleConfirmFile}
        className="w-full py-2 bg-yellow-500 text-white font-bold rounded"
      >
        Xác nhận
      </button>
    </div>
  );
};

export default FileInputSection;
```
## 📄 File: `ColumnSelectorModal.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/ColumnSelectorModal.js`

```javascript
const ColumnSelectorModal = ({
  showModal,
  setShowModal,
  headers,
  selectedColumn,
  setSelectedColumn,
  history,
  setHistory,
  selectedPlatform,
  setSelectedPlatform,
  shopeeLabel,
  setShopeeLabel,
  lazadaLabel,
  setLazadaLabel,
  tiktokLabel,
  setTiktokLabel,
  customLabel1,
  setCustomLabel1,
  customLabel2,
  setCustomLabel2,
  path,
  fileContent,
  setSearchString,
  setSearchType,
}) => {
  const handleModalConfirm = async () => {
    const columnName = history[selectedPlatform] || "tracking_codes";
    const data = {
      file_path: path,
      file_content: fileContent || "",
      column_name: columnName,
      is_excel: path.toLowerCase().endsWith(".xlsx"), // Thêm logic xác định is_excel dựa trên path
    };
    try {
      console.log("Sending file data:", data);
      const response = await fetch("http://localhost:8080/parse-csv", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      console.log("Response from parse-csv:", result);
      if (response.ok) {
        const trackingCodes = result.tracking_codes || [];
        const formattedCodes = trackingCodes
          .map((code, index) => `${index + 1}. ${code}`)
          .join("\n");
        setSearchString(formattedCodes);
        setSearchType("Text");
        setShowModal(false);
      } else {
        throw new Error(result.error || "Failed to parse CSV");
      }
    } catch (error) {
      console.error("Error parsing CSV:", error);
      alert(error.message || "Failed to parse CSV");
    }
  };

  const handleUpdateColumn = () => {
    const newColumn = selectedColumn;
    const updatedHistory = { ...history };
    updatedHistory[selectedPlatform] = newColumn;
    setHistory(updatedHistory);
    localStorage.setItem("trackingColumnHistory", JSON.stringify(updatedHistory));

    const updatedLabels = {
      Shopee: shopeeLabel,
      Lazada: lazadaLabel,
      Tiktok: tiktokLabel,
      Custom1: customLabel1,
      Custom2: customLabel2,
    };
    localStorage.setItem("platformLabels", JSON.stringify(updatedLabels));
  };

  const handlePlatformChange = (platform) => {
    setSelectedPlatform(platform);
    setSelectedColumn(history[platform] || "tracking_codes");
  };

  if (!showModal) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-gray-800 p-6 rounded-lg w-1/2">
        <h2 className="text-xl font-bold mb-4">Chọn cột mã vận đơn</h2>
        <div className="mb-4">
          <label className="block mb-1">Chọn từ danh sách:</label>
          <select
            value={selectedColumn}
            onChange={(e) => setSelectedColumn(e.target.value)}
            className="w-full p-2 rounded bg-gray-700 text-white"
          >
            {headers.map((header, index) => (
              <option key={index} value={header}>{header}</option>
            ))}
          </select>
        </div>
        <div className="mb-4">
          <button
            onClick={handleUpdateColumn}
            className="w-full py-2 bg-blue-600 text-white font-bold rounded"
          >
            Cập nhật
          </button>
        </div>
        <div className="mb-4">
          <h3 className="text-lg font-bold mb-2">Lịch sử lựa chọn:</h3>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Shopee"
              checked={selectedPlatform === "Shopee"}
              onChange={() => handlePlatformChange("Shopee")}
              className="mr-2"
            />
            <input
              type="text"
              value={shopeeLabel}
              onChange={(e) => setShopeeLabel(e.target.value)}
              placeholder="Tên Shopee"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Shopee}
              onChange={(e) => setHistory({ ...history, Shopee: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Lazada"
              checked={selectedPlatform === "Lazada"}
              onChange={() => handlePlatformChange("Lazada")}
              className="mr-2"
            />
            <input
              type="text"
              value={lazadaLabel}
              onChange={(e) => setLazadaLabel(e.target.value)}
              placeholder="Tên Lazada"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Lazada}
              onChange={(e) => setHistory({ ...history, Lazada: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Tiktok"
              checked={selectedPlatform === "Tiktok"}
              onChange={() => handlePlatformChange("Tiktok")}
              className="mr-2"
            />
            <input
              type="text"
              value={tiktokLabel}
              onChange={(e) => setTiktokLabel(e.target.value)}
              placeholder="Tên Tiktok"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Tiktok}
              onChange={(e) => setHistory({ ...history, Tiktok: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Custom1"
              checked={selectedPlatform === "Custom1"}
              onChange={() => handlePlatformChange("Custom1")}
              className="mr-2"
            />
            <input
              type="text"
              value={customLabel1}
              onChange={(e) => setCustomLabel1(e.target.value)}
              placeholder="Tên tùy chỉnh 1"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Custom1}
              onChange={(e) => setHistory({ ...history, Custom1: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Custom2"
              checked={selectedPlatform === "Custom2"}
              onChange={() => handlePlatformChange("Custom2")}
              className="mr-2"
            />
            <input
              type="text"
              value={customLabel2}
              onChange={(e) => setCustomLabel2(e.target.value)}
              placeholder="Tên tùy chỉnh 2"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Custom2}
              onChange={(e) => setHistory({ ...history, Custom2: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
        </div>
        <div className="flex justify-end gap-4">
          <button
            onClick={() => setShowModal(false)}
            className="py-2 px-4 bg-gray-600 text-white rounded"
          >
            Hủy
          </button>
          <button
            onClick={handleModalConfirm}
            className="py-2 px-4 bg-green-600 text-white rounded"
          >
            Xác nhận
          </button>
        </div>
      </div>
    </div>
  );
};

export default ColumnSelectorModal;
```
## 📄 File: `useVtrackConfig.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/hooks/useVtrackConfig.js`

```javascript
import { useState, useEffect } from "react";

const useVtrackConfig = () => {
  const [fromTime, setFromTime] = useState(null);
  const [toTime, setToTime] = useState(null);
  const [country, setCountry] = useState("Việt Nam");
  const [timezone, setTimezone] = useState("UTC+7");
  const [brandName, setBrandName] = useState("");
  const [inputPath, setInputPath] = useState("");
  const [outputPath, setOutputPath] = useState("");
  const [workingDays, setWorkingDays] = useState([]);
  const [defaultDays, setDefaultDays] = useState(30);
  const [minPackingTime, setMinPackingTime] = useState(10);
  const [maxPackingTime, setMaxPackingTime] = useState(120);
  const [frameRate, setFrameRate] = useState(30);
  const [frameInterval, setFrameInterval] = useState(5);
  const [videoBuffer, setVideoBuffer] = useState(2);
  const [cameras, setCameras] = useState([]);
  const [selectedCameras, setSelectedCameras] = useState([]);
  const [showCameraDialog, setShowCameraDialog] = useState(false);
  const [error, setError] = useState(null);
  const [runDefaultOnStart, setRunDefaultOnStart] = useState(false);

  const countries = [
    "Việt Nam", "Nhật Bản", "Hàn Quốc", "Thái Lan", "Singapore",
    "Mỹ", "Anh", "Pháp", "Đức", "Úc"
  ];

  const countryTimezones = {
    "Việt Nam": "UTC+7", "Nhật Bản": "UTC+9", "Hàn Quốc": "UTC+9",
    "Thái Lan": "UTC+7", "Singapore": "UTC+8", "Mỹ": "UTC-5",
    "Anh": "UTC+0", "Pháp": "UTC+1", "Đức": "UTC+1", "Úc": "UTC+10"
  };

  const BASE_DIR = "/Users/annhu/vtrack_app/V_Track";

  useEffect(() => {
    const fetchCameraFolders = async () => {
      try {
        const response = await fetch("http://localhost:8080/get-camera-folders");
        const data = await response.json();
        if (Array.isArray(data.folders)) {
          setCameras(data.folders);
          setError(null);
        } else {
          setCameras([]);
          setError(data.error || "Failed to load camera folders");
        }
      } catch (error) {
        console.error("Error fetching camera folders:", error);
        setError("Error fetching camera folders: " + error.message);
      }
    };
    fetchCameraFolders();
  }, []);

  const handleCountryChange = (e) => {
    const selectedCountry = e.target.value;
    setCountry(selectedCountry);
    setTimezone(countryTimezones[selectedCountry] || "UTC+0");
  };

  const handleFromTimeChange = (time) => {
    setFromTime(time);
    if (toTime && time > toTime) setToTime(time);
  };

  const handleToTimeChange = (time) => {
    if (fromTime && time < fromTime) setFromTime(time);
    setToTime(time);
  };

  const handleWorkingDayChange = (day) => {
    setWorkingDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };

  useEffect(() => {
    console.log("workingDays updated:", workingDays);
  }, [workingDays]);

  const handleOpenExplorer = (type) => {
    const input = document.createElement("input");
    input.type = "file";
    input.webkitdirectory = true;
    input.onchange = (e) => {
      const files = e.target.files;
      if (files.length > 0) {
        const file = files[0];
        let selectedPath = file.path || file.webkitRelativePath || file.name || "";
        if (!selectedPath.startsWith('/')) {
          selectedPath = `${BASE_DIR}/${selectedPath}`;
        }
        selectedPath = selectedPath.split('/').slice(0, -1).join('/');
        if (selectedPath.includes('.DS_Store')) {
          selectedPath = selectedPath.replace('/.DS_Store', '');
        }
        console.log(`Selected ${type} path:`, selectedPath);
        if (type === "input") setInputPath(selectedPath);
        else setOutputPath(selectedPath);
      }
    };
    input.click();
  };

  const handleSaveGeneralInfo = async () => {
    const data = {
      country,
      timezone,
      brand_name: brandName,
      working_days: workingDays.length > 0 ? workingDays : ["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"],
      from_time: fromTime ? fromTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false }) : "07:00",
      to_time: toTime ? toTime.toLocaleTimeString('en-GB', { hour: "2-digit", minute: "2-digit", hour12: false }) : "23:00",
    };
    console.log("Data sent to /save-general-info:", data);
    try {
      const response = await fetch("http://localhost:8080/save-general-info", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (response.ok) alert("General info saved successfully");
      else throw new Error("Failed to save general info");
    } catch (error) {
      console.error("Error saving general info:", error);
      alert("Failed to save general info");
    }
  };

  const handleSaveConfig = async () => {
    let normalizedInputPath = inputPath.trim();
    if (!normalizedInputPath) {
      alert("Input path cannot be empty");
      return;
    }
    if (!normalizedInputPath.startsWith('/')) {
      normalizedInputPath = `${BASE_DIR}/${normalizedInputPath}`;
    }
    if (normalizedInputPath.includes('.DS_Store')) {
      normalizedInputPath = normalizedInputPath.replace('/.DS_Store', '');
    }

    let normalizedOutputPath = outputPath.trim();
    if (!normalizedOutputPath) {
      normalizedOutputPath = `${BASE_DIR}/output_clips`;
    }
    if (!normalizedOutputPath.startsWith('/')) {
      normalizedOutputPath = `${BASE_DIR}/${normalizedOutputPath}`;
    }
    if (normalizedOutputPath.includes('.DS_Store')) {
      normalizedOutputPath = normalizedOutputPath.replace('/.DS_Store', '');
    }

    const data = {
      video_root: normalizedInputPath,
      output_path: normalizedOutputPath,
      db_path: "/Users/annhu/Downloads/V_Track project/events.db",
      default_days: defaultDays,
      min_packing_time: minPackingTime,
      max_packing_time: maxPackingTime,
      frame_rate: frameRate,
      frame_interval: frameInterval,
      video_buffer: videoBuffer,
      selected_cameras: selectedCameras,
    };
    console.log("Data sent to /save-config:", data);
    try {
      const response = await fetch("http://localhost:8080/save-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      if (response.ok) {
        localStorage.setItem("configSet", "true");
        alert("Configuration saved successfully");
        setShowCameraDialog(false);
        const cameraResponse = await fetch("http://localhost:8080/get-cameras");
        const cameraData = await cameraResponse.json();
        if (cameraData && Array.isArray(cameraData.cameras)) {
          setCameras(cameraData.cameras.map(name => ({ name, path: "" })));
          setError(null);
        } else {
          setCameras([]);
          setError(cameraData?.error || "Failed to load cameras");
        }
      } else {
        throw new Error(result.error || "Failed to save config");
      }
    } catch (error) {
      console.error("Error saving config:", error);
      alert("Failed to save config: " + error.message);
    }
  };

  const handleShowCameraDialog = () => {
    setShowCameraDialog(true);
  };

  const handleCameraSelection = (cameraName) => {
    setSelectedCameras((prev) =>
      prev.includes(cameraName) ? prev.filter((c) => c !== cameraName) : [...prev, cameraName]
    );
  };

  return {
    fromTime,
    setFromTime,
    toTime,
    setToTime,
    country,
    setCountry,
    timezone,
    setTimezone,
    brandName,
    setBrandName,
    inputPath,
    setInputPath,
    outputPath,
    setOutputPath,
    workingDays,
    setWorkingDays,
    defaultDays,
    setDefaultDays,
    minPackingTime,
    setMinPackingTime,
    maxPackingTime,
    setMaxPackingTime,
    frameRate,
    setFrameRate,
    frameInterval,
    setFrameInterval,
    videoBuffer,
    setVideoBuffer,
    cameras,
    setCameras,
    selectedCameras,
    setSelectedCameras,
    showCameraDialog,
    setShowCameraDialog,
    error,
    setError,
    handleCountryChange,
    handleFromTimeChange,
    handleToTimeChange,
    handleWorkingDayChange,
    handleOpenExplorer,
    handleSaveGeneralInfo,
    handleSaveConfig,
    handleShowCameraDialog,
    handleCameraSelection,
    runDefaultOnStart,
    setRunDefaultOnStart,
  };
};

export default useVtrackConfig;
```
## 📄 File: `useProgramLogic.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/hooks/useProgramLogic.js`

```javascript
import { useState, useEffect } from "react";
import { runProgram, confirmRun } from "../api";

const useProgramLogic = () => {
  const [runningCard, setRunningCard] = useState("Mặc định");
  const [fileList, setFileList] = useState([]);
  const [customPath, setCustomPath] = useState("");
  const [showConfirmButton, setShowConfirmButton] = useState(false);
  const [firstRunCompleted, setFirstRunCompleted] = useState(false);
  const [isLocked, setIsLocked] = useState(false);

  const checkFirstRun = async () => {
    try {
      const response = await fetch("http://localhost:8080/check-first-run");
      const data = await response.json();
      setFirstRunCompleted(data.first_run_completed);
    } catch (error) {
      console.error("Error checking first run:", error);
    }
  };

  const checkDefaultRunning = async () => {
    try {
      const response = await fetch("http://localhost:8080/program", {
        method: "GET",
      });
      const data = await response.json();
      setRunningCard("Mặc định"); // Ép Mặc định khi refresh
      setIsLocked(false);
    } catch (error) {
      console.error("Error checking default running state:", error);
      setRunningCard("Mặc định"); // Ép Mặc định nếu lỗi
      setIsLocked(false);
    }
  };

  useEffect(() => {
    const initializeState = async () => {
      await checkFirstRun();
      await checkDefaultRunning();
    };
    initializeState();
  }, []);

  const handleRunStop = async (cardTitle, path = "") => {
    if (cardTitle === "Lần đầu" && firstRunCompleted) {
      return;
    }

    if (isLocked) {
      alert("Hệ thống đang xử lý, vui lòng đợi!");
      return;
    }

    try {
      let days = null;
      if (cardTitle === "Lần đầu" && !isRunning(cardTitle)) {
        days = prompt("Bạn muốn xử lý bao nhiêu ngày? (Tối đa 30 ngày)", "30");
        days = parseInt(days);
        if (isNaN(days) || days <= 0 || days > 30) {
          alert("Số ngày không hợp lệ. Vui lòng nhập từ 1 đến 30.");
          return;
        }
      } else if (cardTitle === "Chỉ định" && !isRunning(cardTitle)) {
        if (!path) {
          alert("Vui lòng chọn đường dẫn cho chương trình Chỉ định.");
          return;
        }
        setIsLocked(true);
      }

      const response = await runProgram({
        card: cardTitle,
        action: isRunning(cardTitle) ? "stop" : "run",
        days: days,
        custom_path: cardTitle === "Chỉ định" ? path : ""
      });

      if (response.status === 200) {
        if (isRunning(cardTitle)) {
          if (cardTitle === "Mặc định") {
            setRunningCard(null);
            setFileList([]);
            alert(`Đã dừng chương trình ${cardTitle}`);
          }
        } else {
          if (cardTitle !== "Lần đầu" || !firstRunCompleted) {
            setRunningCard(cardTitle);
            setShowConfirmButton(true);
            if (cardTitle !== "Chỉ định") {
              setIsLocked(false);
            }
          }
        }
      }
    } catch (error) {
      console.error("Error calling API:", error);
      setIsLocked(false);
      if (error.response?.status === 400) {
        alert(error.response.data.error);
      } else {
        alert("Có lỗi xảy ra khi gọi API. Vui lòng kiểm tra server.");
      }
    }
  };

  const handleConfirmRun = async () => {
    try {
      const response = await confirmRun({ card: runningCard });
      if (response.status === 200) {
        setShowConfirmButton(false);
        setFileList(response.data.files || []);
        if (runningCard === "Lần đầu") {
          setFirstRunCompleted(true);
          await checkFirstRun();
        }
        if (runningCard === "Chỉ định") {
          setIsLocked(false);
          await checkDefaultRunning();
        }
      }
    } catch (error) {
      console.error("Error confirming run:", error);
      setIsLocked(false);
      alert("Có lỗi xảy ra khi xác nhận chạy chương trình.");
    }
  };

  const isRunning = (cardTitle) => runningCard === cardTitle;

  return {
    runningCard,
    setRunningCard,
    fileList,
    setFileList,
    customPath,
    setCustomPath,
    showConfirmButton,
    setShowConfirmButton,
    firstRunCompleted,
    setFirstRunCompleted,
    handleRunStop,
    handleConfirmRun,
    isRunning,
    isLocked
  };
};

export default useProgramLogic;
```
## 📄 File: `database.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/database.py`

```python
import sqlite3
import os
import json
from modules.db_utils import find_project_root

# Xác định thư mục gốc của dự án
BASE_DIR = find_project_root(os.path.abspath(__file__))

# Đường dẫn cơ sở dữ liệu
DB_DIR = os.path.join(BASE_DIR, "backend/database")
DB_PATH = os.path.join(DB_DIR, "events.db")

# Đường dẫn mặc định
INPUT_VIDEO_DIR = os.path.join(BASE_DIR, "resources/Inputvideo")
OUTPUT_CLIPS_DIR = os.path.join(BASE_DIR, "resources/output_clips")

def get_db_connection():
    return sqlite3.connect(DB_PATH)

def update_database():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Tạo bảng file_list
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS file_list (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                program_type TEXT NOT NULL,
                days INTEGER,
                custom_path TEXT,
                file_path TEXT NOT NULL,
                ctime DATETIME,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_processed INTEGER DEFAULT 0,
                priority INTEGER DEFAULT 0,
                status TEXT DEFAULT 'chưa bắt đầu',
                log_file_path TEXT,
                camera_name TEXT
            )
        """)

        # Tạo bảng program_status
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS program_status (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL UNIQUE,
                value TEXT NOT NULL
            )
        """)
        cursor.execute("SELECT COUNT(*) FROM program_status WHERE key = 'first_run_completed'")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO program_status (key, value) VALUES ('first_run_completed', 'false')")

        # Tạo bảng processing_config
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS processing_config (
                id INTEGER PRIMARY KEY,
                input_path TEXT,
                output_path TEXT,
                storage_duration INTEGER,
                min_packing_time INTEGER,
                max_packing_time INTEGER,
                frame_rate INTEGER,
                frame_interval INTEGER,
                video_buffer INTEGER,
                default_frame_mode TEXT,
                selected_cameras TEXT,
                db_path TEXT NOT NULL,
                run_default_on_start INTEGER DEFAULT 0,
                motion_threshold FLOAT DEFAULT 0.1,
                stable_duration_sec FLOAT DEFAULT 1
            )
        """)
        cursor.execute("UPDATE processing_config SET db_path = ?, run_default_on_start = 0 WHERE db_path IS NULL OR run_default_on_start IS NULL", (DB_PATH,))

        # Chèn dữ liệu mặc định nếu bảng processing_config rỗng
        cursor.execute("SELECT COUNT(*) FROM processing_config")
        if cursor.fetchone()[0] == 0:
            cursor.execute("""
                INSERT INTO processing_config (
                    id, input_path, output_path, storage_duration, min_packing_time, 
                    max_packing_time, frame_rate, frame_interval, video_buffer, default_frame_mode, selected_cameras, db_path, run_default_on_start
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (1, INPUT_VIDEO_DIR, OUTPUT_CLIPS_DIR, 30, 10, 120, 30, 5, 2, "default", "[]", DB_PATH, 0))

        # Tạo bảng frame_settings
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS frame_settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mode TEXT NOT NULL,
                frame_rate INTEGER,
                frame_interval INTEGER,
                description TEXT
            )
        """)
        cursor.execute("SELECT COUNT(*) FROM frame_settings")
        if cursor.fetchone()[0] == 0:
            cursor.execute("""
                INSERT INTO frame_settings (mode, frame_rate, frame_interval, description)
                VALUES (?, ?, ?, ?)
            """, ("default", 30, 5, "Chế độ mặc định từ giao diện"))

        # Tạo bảng general_info với working_days dạng JSON tiếng Anh
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS general_info (
                id INTEGER PRIMARY KEY,
                country TEXT,
                timezone TEXT,
                brand_name TEXT,
                working_days TEXT,
                from_time TEXT,
                to_time TEXT
            )
        """)
        cursor.execute("SELECT COUNT(*) FROM general_info")
        if cursor.fetchone()[0] == 0:
            working_days = json.dumps(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])
            cursor.execute("""
                INSERT INTO general_info (
                    id, country, timezone, brand_name, working_days, from_time, to_time
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (1, "Việt Nam", "UTC+7", "MyBrand", working_days, "07:00", "23:00"))

        # Tạo bảng events
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS events (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER,
                te INTEGER,
                duration INTEGER,
                tracking_codes TEXT,
                video_file TEXT NOT NULL,
                buffer INTEGER NOT NULL,
                camera_name TEXT,
                packing_time_start INTEGER,
                packing_time_end INTEGER,
                is_processed INTEGER DEFAULT 0,
                processed_timestamp INTEGER,
                output_video_path TEXT,
                session_id TEXT,
                output_file TEXT
            )
        """)
        # Tạo chỉ mục trên te và event_id
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_te_event_id ON events(te, event_id)")

        # Tạo bảng processed_logs
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS processed_logs (
                log_file TEXT PRIMARY KEY,
                processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_processed INTEGER DEFAULT 0
            )
        """)

        # Tạo bảng packing_profiles
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS packing_profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                profile_name TEXT NOT NULL,
                qr_trigger_area TEXT,
                qr_motion_area TEXT,
                qr_mvd_area TEXT,
                packing_area TEXT,
                min_packing_time INTEGER,
                jump_time_ratio REAL,
                mvd_jump_ratio REAL,
                scan_mode TEXT,
                fixed_threshold INTEGER,
                margin INTEGER,
                additional_params TEXT
            )
        """)

        conn.commit()
        conn.close()
        print(f"CSDL tại {DB_PATH} đã được cập nhật thành công.")
    except Exception as e:
        print(f"Error updating database: {e}")
        raise

if __name__ == "__main__":
    os.makedirs(DB_DIR, exist_ok=True)
    update_database()
```
## 📄 File: `app.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/app.py`

```python
import os
import sys

# ==================== TẮT TẤT CẢ LOGS TRƯỚC KHI IMPORT ====================
# TensorFlow logs
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_LOGGING'] = 'ERROR'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

# Google/Abseil logs (MediaPipe)
os.environ['GLOG_minloglevel'] = '3'
os.environ['GLOG_logtostderr'] = '0'
os.environ['GLOG_stderrthreshold'] = '3'
os.environ['GLOG_v'] = '0'

# MediaPipe logs
os.environ['MEDIAPIPE_DISABLE_GPU'] = '1'
os.environ['MEDIAPIPE_LOG_LEVEL'] = '3'

# OpenCV logs
os.environ['OPENCV_LOG_LEVEL'] = 'ERROR'

# Tắt C++ warnings
os.environ['PYTHONWARNINGS'] = 'ignore'

# Redirect stderr để tắt hoàn toàn C++ logs
import warnings
warnings.filterwarnings('ignore')

# Tắt absl logging
try:
    import absl.logging
    absl.logging.set_verbosity(absl.logging.ERROR)
    absl.logging.set_stderrthreshold(absl.logging.ERROR)
except ImportError:
    pass

# ==================== IMPORT MODULES ====================
from modules.config.logging_config import setup_logging, get_logger
from datetime import datetime
import logging
import signal
import threading
import socket
import atexit
import sqlite3
from datetime import datetime, timedelta, timezone

# Thiết lập logging từ logging_config
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
setup_logging(BASE_DIR, app_name="app", log_level=logging.DEBUG)
logger = logging.getLogger("app")

# Import các modules khác
from modules.config.config import config_bp, init_app_and_config
from modules.scheduler.program import program_bp
from modules.query.query import query_bp
from blueprints.cutter_bp import cutter_bp
from blueprints.hand_detection_bp import hand_detection_bp
from blueprints.qr_detection_bp import qr_detection_bp
from blueprints.roi_bp import roi_bp
from modules.scheduler.program import scheduler  # Import BatchScheduler

# Khởi tạo Flask app và DB path từ config
app, DB_PATH, logger = init_app_and_config()

# Đăng ký các Blueprint
app.register_blueprint(program_bp)
app.register_blueprint(config_bp)
app.register_blueprint(query_bp)
app.register_blueprint(cutter_bp)
app.register_blueprint(hand_detection_bp)
app.register_blueprint(qr_detection_bp)
app.register_blueprint(roi_bp)

# Hàm ghi last_stop_time khi ứng dụng dừng
def exit_handler():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        last_stop_time = datetime.now(tz=timezone(timedelta(hours=7))).strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute("""
            INSERT OR REPLACE INTO program_status (key, value)
            VALUES ('last_stop_time', ?)
        """, (last_stop_time,))
        conn.commit()
        conn.close()
        logger.info("Application stopped gracefully")
    except Exception as e:
        logger.error(f"Error saving last_stop_time: {e}")

# Đăng ký exit_handler
atexit.register(exit_handler)

def is_port_in_use(port):
    """Kiểm tra xem cổng có đang được sử dụng hay không."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("localhost", port))
            return False
        except OSError:
            return True

# Global flag để tránh multiple shutdown
_shutdown_in_progress = False

def signal_handler(sig, frame):
    """Xử lý tín hiệu dừng ứng dụng một cách graceful"""
    global _shutdown_in_progress
    
    # Tránh multiple shutdown
    if _shutdown_in_progress:
        print("\nForced shutdown...")
        os._exit(1)  # Force exit nếu đã shutdown rồi
    
    _shutdown_in_progress = True
    print("\nShutting down gracefully... (Press Ctrl+C again to force)")
    
    try:
        logger.info("Received shutdown signal, stopping application...")
        
        # Dừng scheduler
        if 'scheduler' in globals():
            scheduler.stop()
            logger.info("Scheduler stopped")
        
        # Đợi các thread kết thúc với timeout ngắn hơn
        main_thread = threading.current_thread()
        for t in threading.enumerate():
            if t != main_thread and t.is_alive():
                try:
                    t.join(timeout=2)  # Giảm timeout xuống 2 giây
                    if t.is_alive():
                        logger.warning(f"Thread {t.name} did not stop gracefully")
                except:
                    pass  # Ignore errors during shutdown
        
        logger.info("Application shutdown complete")
        
    except Exception as e:
        logger.error(f"Error during shutdown: {e}")
    finally:
        os._exit(0)  # Force exit

# Đăng ký signal handler
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# Khởi chạy ứng dụng
if __name__ == "__main__":
    port = 8080
    
    # Kiểm tra port trước khi khởi chạy
    if is_port_in_use(port):
        logger.error(f"Port {port} is already in use!")
        sys.exit(1)
    
    logger.info(f"Starting application on port {port}")
    
    try:
        app.run(
            host='0.0.0.0',
            port=port,
            debug=False,
            use_reloader=False,
            threaded=True
        )
    except KeyboardInterrupt:
        logger.info("Application interrupted by user")
    except Exception as e:
        logger.error(f"Application error: {e}")
    finally:
        logger.info("Application terminated")
```
## 📄 File: `cutter_bp.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/blueprints/cutter_bp.py`

```python
import sqlite3
import os
from datetime import datetime
import subprocess
from flask import Blueprint, request, jsonify
from modules.db_utils import get_db_connection
import ast
from modules.technician.cutter.cutter_complete import cut_complete_event
from modules.technician.cutter.cutter_incomplete import cut_incomplete_event, merge_incomplete_events
from modules.technician.cutter.cutter_utils import generate_output_filename, update_event_in_db
from modules.scheduler.db_sync import db_rwlock

cutter_bp = Blueprint('cutter', __name__)

with db_rwlock.gen_rlock():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT output_path FROM processing_config LIMIT 1")
    result = cursor.fetchone()
    output_dir = result[0] if result else os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../resources/output_clips")
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    conn.close()

def get_video_duration(video_file):
    try:
        cmd = ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", video_file]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        return float(result.stdout.strip())
    except Exception:
        return None

def cut_and_update_events(selected_events, tracking_codes_filter, brand_name="Alan"):
    with db_rwlock.gen_wlock():
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT video_buffer, max_packing_time FROM processing_config LIMIT 1")
        result = cursor.fetchone()
        video_buffer = result[0] if result else 5
        max_packing_time = result[1] if result else 120
        cut_files = []

        for event in selected_events:
            event_id = event.get("event_id")
            ts = event.get("ts")
            te = event.get("te")
            video_file = event.get("video_file")
            cursor.execute("SELECT is_processed FROM events WHERE event_id = ?", (event_id,))
            is_processed = cursor.fetchone()[0]
            if is_processed:
                print(f"Bỏ qua: Sự kiện {event_id} đã được xử lý trước đó")
                continue

            has_ts = ts is not None
            has_te = te is not None
            is_incomplete = (has_ts and not has_te) or (not has_ts and has_te)

            if is_incomplete:
                next_event = None
                if has_ts and not has_te:
                    cursor.execute("SELECT event_id, ts, te, video_file, packing_time_start, packing_time_end, tracking_codes, is_processed FROM events WHERE event_id = ? AND is_processed = 0", (event_id + 1,))
                    next_event_row = cursor.fetchone()
                    if next_event_row:
                        next_event = {
                            "event_id": next_event_row[0],
                            "ts": next_event_row[1],
                            "te": next_event_row[2],
                            "video_file": next_event_row[3],
                            "packing_time_start": next_event_row[4],
                            "packing_time_end": next_event_row[5],
                            "tracking_codes": next_event_row[6],
                            "is_processed": next_event_row[7]
                        }
                elif not has_ts and has_te:
                    cursor.execute("SELECT event_id, ts, te, video_file, packing_time_start, packing_time_end, tracking_codes, is_processed FROM events WHERE event_id = ? AND is_processed = 0", (event_id - 1,))
                    prev_event_row = cursor.fetchone()
                    if prev_event_row:
                        next_event = {
                            "event_id": prev_event_row[0],
                            "ts": prev_event_row[1],
                            "te": prev_event_row[2],
                            "video_file": prev_event_row[3],
                            "packing_time_start": prev_event_row[4],
                            "packing_time_end": prev_event_row[5],
                            "tracking_codes": prev_event_row[6],
                            "is_processed": prev_event_row[7]
                        }

                if next_event:
                    next_event_id = next_event.get("event_id")
                    next_ts = next_event.get("ts")
                    next_te = next_event.get("te")
                    next_video_file = next_event.get("video_file")
                    next_has_ts = next_ts is not None
                    next_has_te = next_te is not None
                    can_merge = (has_ts and not has_te and not next_has_ts and next_has_te) or (not has_ts and has_te and next_has_ts and not next_has_te)

                    if can_merge:
                        video_length_a = get_video_duration(video_file)
                        video_length_b = get_video_duration(next_video_file)
                        if video_length_a is None or video_length_b is None:
                            print(f"Lỗi: Không thể lấy độ dài video {video_file} hoặc {next_video_file}")
                            continue

                        output_file_a = generate_output_filename(event, tracking_codes_filter, output_dir, brand_name)
                        print(f"Đang xử lý sự kiện {event_id}: output_file={output_file_a}, packing_time_start={event.get('packing_time_start')}, packing_time_end={event.get('packing_time_end')}")
                        if cut_incomplete_event(event, video_buffer, video_length_a, output_file_a):
                            update_event_in_db(cursor, event_id, output_file_a)

                        output_file_b = generate_output_filename(next_event, tracking_codes_filter, output_dir, brand_name)
                        print(f"Đang xử lý sự kiện {next_event_id}: output_file={output_file_b}, packing_time_start={next_event.get('packing_time_start')}, packing_time_end={next_event.get('packing_time_end')}")
                        if cut_incomplete_event(next_event, video_buffer, video_length_b, output_file_b):
                            update_event_in_db(cursor, next_event_id, output_file_b)

                        if has_ts and not has_te:
                            event_a = event
                            event_b = next_event
                            video_length_event_a = video_length_a
                            video_length_event_b = video_length_b
                        else:
                            event_a = next_event
                            event_b = event
                            video_length_event_a = video_length_b
                            video_length_event_b = video_length_a

                        print(f"Gọi merge_incomplete_events: event_a (ID: {event_a.get('event_id')}, ts: {event_a.get('ts')}, te: {event_a.get('te')}), event_b (ID: {event_b.get('event_id')}, ts: {event_b.get('ts')}, te: {event_b.get('te')})")

                        merged_file = merge_incomplete_events(event_a, event_b, video_buffer, video_length_event_a, video_length_event_b, output_dir, max_packing_time, brand_name)
                        if merged_file:
                            update_event_in_db(cursor, event_id, merged_file)
                            update_event_in_db(cursor, next_event_id, merged_file)
                            cut_files.append(merged_file)
                        continue

            video_length = get_video_duration(video_file)
            if video_length is None:
                print(f"Lỗi: Không thể lấy độ dài video {video_file}")
                continue

            output_file = generate_output_filename(event, tracking_codes_filter, output_dir, brand_name)
            print(f"Đang xử lý sự kiện {event_id}: output_file={output_file}, packing_time_start={event.get('packing_time_start')}, packing_time_end={event.get('packing_time_end')}")

            if has_ts and has_te:
                if cut_complete_event(event, video_buffer, video_length, output_file):
                    update_event_in_db(cursor, event_id, output_file)
                    cut_files.append(output_file)
            elif is_incomplete:
                if cut_incomplete_event(event, video_buffer, video_length, output_file):
                    update_event_in_db(cursor, event_id, output_file)
                    cut_files.append(output_file)
            else:
                print(f"Bỏ qua: Sự kiện {event_id} không có ts hoặc te")
                continue

        conn.commit()
        conn.close()
    return cut_files

@cutter_bp.route('/cut-videos', methods=['POST'])
def cut_videos():
    data = request.get_json()
    selected_events = data.get('selected_events', [])
    tracking_codes_filter = data.get('tracking_codes_filter', [])

    if not selected_events:
        return jsonify({"error": "No selected events provided"}), 400

    try:
        cut_files = cut_and_update_events(selected_events, tracking_codes_filter)
        return jsonify({"message": "Videos cut successfully", "cut_files": cut_files}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/blueprints/__init__.py`

```python

```
## 📄 File: `hand_detection_bp.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/blueprints/hand_detection_bp.py`

```python
from flask import Blueprint, request, jsonify
from modules.technician.hand_detection import select_roi
import subprocess
import os
import json
import logging

hand_detection_bp = Blueprint('hand_detection', __name__)

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

@hand_detection_bp.route('/select-roi', methods=['POST'])
def select_roi_endpoint():
    try:
        data = request.get_json()
        video_path = data.get('videoPath')
        camera_id = data.get('cameraId')
        step = data.get('step', 'packing')
        
        logging.debug(f"Received request for select-roi with step: {step}, video_path: {video_path}, camera_id: {camera_id}")
        
        if not video_path or not camera_id:
            logging.error("Missing videoPath or cameraId")
            return jsonify({"success": False, "error": "Thiếu videoPath hoặc cameraId."}), 400
        
        if not os.path.exists(video_path):
            logging.error(f"Video path does not exist: {video_path}")
            return jsonify({"success": False, "error": "Đường dẫn video không tồn tại."}), 404
        
        if os.path.exists("/tmp/roi.json"):
            os.remove("/tmp/roi.json")
            logging.info("Đã xóa file /tmp/roi.json để bắt đầu quy trình mới")
        
        result = select_roi(video_path, camera_id, step)
        logging.debug(f"Result from select_roi: {result}")
        return jsonify(result), 200 if result["success"] else 400
    
    except Exception as e:
        logging.error(f"Exception in select_roi_endpoint: {str(e)}")
        return jsonify({"success": False, "error": f"Lỗi hệ thống: {str(e)}"}), 500

@hand_detection_bp.route('/run-select-roi', methods=['POST'])
def run_select_roi_endpoint():
    try:
        data = request.get_json()
        video_path = data.get('videoPath')
        camera_id = data.get('cameraId', 'default_camera')
        
        if not video_path:
            return jsonify({"success": False, "error": "Thiếu videoPath."}), 400
        
        logging.info(f"Running hand_detection.py with video_path: {video_path}, camera_id: {camera_id}")
        
        if not os.path.exists(video_path):
            return jsonify({"success": False, "error": "Đường dẫn video không tồn tại."}), 404
        
        if os.path.exists("/tmp/roi.json"):
            os.remove("/tmp/roi.json")
        
        result = subprocess.run(
            ["python3", "modules/technician/hand_detection.py", video_path, camera_id],
            capture_output=True,
            text=True,
            timeout=300
        )
        
        if result.returncode != 0:
            error_message = f"Lỗi khi chạy script: {result.stderr}"
            logging.error(error_message)
            return jsonify({"success": False, "error": error_message}), 500
        
        if not os.path.exists("/tmp/roi.json"):
            return jsonify({"success": False, "error": "Không tìm thấy file kết quả ROI."}), 500
        
        with open("/tmp/roi.json", "r") as f:
            roi_result = json.load(f)
        
        logging.info(f"ROI result from /tmp/roi.json: {roi_result}")
        return jsonify(roi_result), 200 if roi_result["success"] else 400
    
    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "Hết thời gian chờ khi chạy script."}), 500
    except Exception as e:
        logging.error(f"Unexpected error in run-select-roi: {str(e)}")
        return jsonify({"success": False, "error": f"Lỗi hệ thống: {str(e)}"}), 500

```
## 📄 File: `roi_bp.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/blueprints/roi_bp.py`

```python
from flask import Blueprint, request, jsonify, send_file
from modules.technician.hand_detection import finalize_roi
import os
import glob
import json
import sqlite3
from datetime import datetime
import logging

roi_bp = Blueprint('roi', __name__)

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "..", "database", "events.db")
CAMERA_ROI_DIR = os.path.join(BASE_DIR, "..", "..", "resources/output_clips/CameraROI")

@roi_bp.route('/finalize-roi', methods=['POST'])
def finalize_roi_endpoint():
    try:
        data = request.get_json()
        video_path = data.get('videoPath')
        camera_id = data.get('cameraId')
        rois = data.get('rois')

        if not video_path or not camera_id or not rois:
            return jsonify({"success": False, "error": "Thiếu videoPath, cameraId hoặc rois."}), 400

        if not os.path.exists(video_path):
            return jsonify({"success": False, "error": "Đường dẫn video không tồn tại."}), 404

        packing_roi = [0, 0, 0, 0]
        if os.path.exists("/tmp/roi.json"):
            with open("/tmp/roi.json", "r") as f:
                roi_data = json.load(f)
                if roi_data.get("success") and "roi" in roi_data:
                    packing_roi = [roi_data["roi"]["x"], roi_data["roi"]["y"], roi_data["roi"]["w"], roi_data["roi"]["h"]]
        
        qr_mvd_area = [0, 0, 0, 0]
        qr_trigger_area = [0, 0, 0, 0]
        table_type = None
        if os.path.exists("/tmp/qr_roi.json"):
            with open("/tmp/qr_roi.json", "r") as f:
                qr_roi_data = json.load(f)
                table_type = qr_roi_data.get("table_type")
                for roi in rois:
                    if roi["type"] == "mvd":
                        qr_mvd_area = [roi["x"], roi["y"], roi["w"], roi["h"]]
                    elif roi["type"] == "trigger" and table_type == "standard":
                        qr_trigger_area = [roi["x"], roi["y"], roi["w"], roi["h"]]

        profile_name = camera_id
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM packing_profiles WHERE profile_name = ?", (profile_name,))
        exists = cursor.fetchone()
        
        if exists:
            cursor.execute('''
                UPDATE packing_profiles
                SET qr_trigger_area = ?, qr_mvd_area = ?, packing_area = ?,
                    min_packing_time = ?, jump_time_ratio = ?, scan_mode = ?, fixed_threshold = ?, margin = ?, additional_params = ?
                WHERE profile_name = ?
            ''', (
                json.dumps(qr_trigger_area),
                json.dumps(qr_mvd_area),
                json.dumps(packing_roi),
                10, 0.5, "full", 20, 60, json.dumps({}),
                profile_name
            ))
        else:
            cursor.execute('''
                INSERT INTO packing_profiles (
                    profile_name, qr_trigger_area, qr_mvd_area, packing_area,
                    min_packing_time, jump_time_ratio, scan_mode, fixed_threshold, margin, additional_params
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                profile_name,
                json.dumps(qr_trigger_area),
                json.dumps(qr_mvd_area),
                json.dumps(packing_roi),
                10, 0.5, "full", 20, 60, json.dumps({})
            ))
        conn.commit()
        conn.close()
        logging.info(f"Lưu ROI vào packing_profiles với profile_name: {profile_name}")

        result = finalize_roi(video_path, camera_id, rois)
        return jsonify(result), 200 if result["success"] else 400
    
    except Exception as e:
        logging.error(f"Exception in finalize_roi_endpoint: {str(e)}")
        return jsonify({"success": False, "error": f"Lỗi hệ thống: {str(e)}"}), 500

@roi_bp.route('/get-roi-frame', methods=['GET'])
def get_roi_frame():
    camera_id = request.args.get('camera_id')
    file = request.args.get('file')
    if not camera_id or not file:
        return jsonify({"success": False, "error": "Thiếu camera_id hoặc file."}), 400

    file_path = os.path.join(CAMERA_ROI_DIR, f"camera_{camera_id}_{file}")
    logging.info(f"Attempting to fetch file: {file_path}")

    if not os.path.exists(file_path):
        logging.error(f"File không tồn tại: {file_path}")
        return jsonify({"success": False, "error": "Không tìm thấy ảnh."}), 404

    return send_file(file_path, mimetype='image/jpeg')

@roi_bp.route('/get-final-roi-frame', methods=['GET'])
def get_final_roi_frame():
    camera_id = request.args.get('camera_id')
    if not camera_id:
        return jsonify({"success": False, "error": "Thiếu camera_id."}), 400
    
    final_pattern = os.path.join(CAMERA_ROI_DIR, f"camera_{camera_id}_roi_final_*.jpg")
    final_files = glob.glob(final_pattern)
    logging.info(f"Files found for camera_id={camera_id}: {final_files}")

    if not final_files:
        logging.error(f"Không tìm thấy file tổng hợp nào trong {CAMERA_ROI_DIR} với pattern {final_pattern}")
        return jsonify({"success": False, "error": "Không tìm thấy ảnh tổng hợp."}), 404

    latest_file = max(final_files, key=os.path.getmtime)
    logging.info(f"Latest file selected: {latest_file}")

    if not os.path.exists(latest_file):
        logging.error(f"File mới nhất {latest_file} không tồn tại")
        return jsonify({"success": False, "error": "Không tìm thấy ảnh tổng hợp."}), 404

    return send_file(latest_file, mimetype='image/jpeg')
```
## 📄 File: `qr_detection_bp.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/blueprints/qr_detection_bp.py`

```python
from flask import Blueprint, request, jsonify
from modules.technician.qr_detector import select_qr_roi
import subprocess
import os
import json
import logging

qr_detection_bp = Blueprint('qr_detection', __name__)

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

CAMERA_ROI_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "resources/output_clips/CameraROI")

@qr_detection_bp.route('/select-qr-roi', methods=['POST'])
def select_qr_roi_endpoint():
    try:
        data = request.get_json()
        video_path = data.get('videoPath')
        camera_id = data.get('cameraId')
        roi_frame_path = data.get('roiFramePath')
        step = data.get('step', 'mvd')
        
        logging.debug(f"[MVD] Received data: {data}")
        logging.debug(f"[MVD] Parameters - video_path: {video_path}, camera_id: {camera_id}, roi_frame_path: {roi_frame_path}, step: {step}")
        
        if not video_path or not camera_id or not roi_frame_path:
            logging.error("[MVD] Missing required parameters")
            return jsonify({"success": False, "error": "Thiếu videoPath, cameraId hoặc roiFramePath."}), 400
        
        logging.debug(f"[MVD] Checking video path exists: {video_path}")
        if not os.path.exists(video_path):
            logging.error(f"[MVD] Video path does not exist: {video_path}")
            return jsonify({"success": False, "error": "Đường dẫn video không tồn tại."}), 404
        
        logging.debug(f"[MVD] Checking ROI frame path exists: {roi_frame_path}")
        if not os.path.exists(roi_frame_path):
            logging.error(f"[MVD] ROI frame path does not exist: {roi_frame_path}")
            return jsonify({"success": False, "error": "Đường dẫn ảnh tạm không tồn tại."}), 404
        
        if os.path.exists("/tmp/qr_roi.json"):
            logging.debug("[MVD] Removing existing /tmp/qr_roi.json")
            os.remove("/tmp/qr_roi.json")
            logging.info("[MVD] Đã xóa file /tmp/qr_roi.json để bắt đầu quy trình mới")
        
        logging.debug(f"[MVD] Calling select_qr_roi with video_path: {video_path}, camera_id: {camera_id}, roi_frame_path: {roi_frame_path}, step: {step}")
        result = select_qr_roi(video_path, camera_id, roi_frame_path, step)
        logging.debug(f"[MVD] select_qr_roi result: {result}")
        logging.info(f"[MVD] Completed MVD step for camera_id: {camera_id}")
        
        return jsonify(result), 200 if result["success"] else 400
    
    except Exception as e:
        logging.error(f"[MVD] Exception in select_qr_roi_endpoint: {str(e)}")
        return jsonify({"success": False, "error": f"Lỗi hệ thống: {str(e)}"}), 500

@qr_detection_bp.route('/run-qr-detector', methods=['POST'])
def run_qr_detector_endpoint():
    try:
        data = request.get_json()
        video_path = data.get('videoPath')
        camera_id = data.get('cameraId', 'default_camera')
        
        if not video_path:
            return jsonify({"success": False, "error": "Thiếu videoPath."}), 400
        
        absolute_roi_frame_path = os.path.join(CAMERA_ROI_DIR, f"camera_{camera_id}_roi_packing.jpg")
        
        logging.info(f"Running qr_detector.py with video_path: {video_path}, camera_id: {camera_id}, roi_frame_path: {absolute_roi_frame_path}")
        
        if not os.path.exists(video_path):
            return jsonify({"success": False, "error": "Đường dẫn video không tồn tại."}), 404
        if not os.path.exists(absolute_roi_frame_path):
            return jsonify({"success": False, "error": "Đường dẫn ảnh packing không tồn tại."}), 404
        
        if os.path.exists("/tmp/qr_roi.json"):
            os.remove("/tmp/qr_roi.json")
        
        result = subprocess.run(
            ["python3", "modules/technician/qr_detector.py", video_path, camera_id, absolute_roi_frame_path],
            capture_output=True,
            text=True,
            timeout=300
        )
        
        if result.returncode != 0:
            error_message = f"Lỗi khi chạy script: {result.stderr}"
            logging.error(error_message)
            return jsonify({"success": False, "error": error_message}), 500
        
        if not os.path.exists("/tmp/qr_roi.json"):
            return jsonify({"success": False, "error": "Không tìm thấy file kết quả ROI."}), 500
        
        with open("/tmp/qr_roi.json", "r") as f:
            qr_roi_result = json.load(f)
        
        logging.info(f"QR ROI result from /tmp/qr_roi.json: {qr_roi_result}")
        return jsonify(qr_roi_result), 200 if qr_roi_result["success"] else 400
    
    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "error": "Hết thời gian chờ khi chạy script."}), 500
    except Exception as e:
        logging.error(f"Unexpected error in run-qr-detector: {str(e)}")
        return jsonify({"success": False, "error": f"Lỗi hệ thống: {str(e)}"}), 500
```
## 📄 File: `config_loader.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/config_loader.py`

```python
import sqlite3
import os
from modules.path_utils import get_paths


def get_processing_config():
    """
    Trả về INPUT_VIDEO_DIR và LOG_DIR từ bảng processing_config.
    Nếu thiếu, fallback về path mặc định.
    """
    paths = get_paths()
    db_path = paths["DB_PATH"]

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT input_path, output_path FROM processing_config LIMIT 1")
        row = cursor.fetchone()
        conn.close()

        if row:
            return {
                "INPUT_VIDEO_DIR": row[0],
                "LOG_DIR": row[1],
            }
    except Exception as e:
        print(f"[!] Lỗi đọc cấu hình DB: {e}")

    # fallback nếu lỗi hoặc DB trống
    return {
        "INPUT_VIDEO_DIR": os.path.join(paths["BASE_DIR"], "resources/Inputvideo"),
        "LOG_DIR": os.path.join(paths["BASE_DIR"], "resources/output_clips/LOG"),
    }


def get_log_path(file_name: str) -> str:
    """Trả về đường dẫn đầy đủ đến file trong LOG_DIR."""
    log_dir = get_processing_config()["LOG_DIR"]
    return os.path.join(log_dir, file_name)


def get_input_path(file_name: str) -> str:
    """Trả về đường dẫn đầy đủ đến file trong INPUT_VIDEO_DIR."""
    input_dir = get_processing_config()["INPUT_VIDEO_DIR"]
    return os.path.join(input_dir, file_name)
```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/__init__.py`

```python

```
## 📄 File: `path_utils.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/path_utils.py`

```python
import os


def find_project_root(file_path):
    """Tìm thư mục gốc của dự án bắt đầu từ file_path."""
    current_path = os.path.dirname(os.path.abspath(file_path))
    while current_path != os.path.dirname(current_path):
        if "backend" in os.listdir(current_path):
            return current_path
        current_path = os.path.dirname(current_path)
    raise RuntimeError("Không tìm thấy thư mục gốc dự án.")


def get_paths():
    base_dir = find_project_root(__file__)
    return {
        "BASE_DIR": base_dir,
        "DB_PATH": os.path.join(base_dir, "backend/database/events.db"),
        "BACKEND_DIR": os.path.join(base_dir, "backend"),
        "FRONTEND_DIR": os.path.join(base_dir, "frontend"),
        "CAMERA_ROI_DIR": os.path.join(base_dir, "resources", "output_clips", "CameraROI")
    }

```
## 📄 File: `config.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/config/config.py`

```python
from flask import Blueprint, request, jsonify, Flask
from flask_cors import CORS
import os
import json
import sqlite3
import logging
from modules.db_utils import find_project_root, get_db_connection
from modules.scheduler.db_sync import db_rwlock
from database import update_database, DB_PATH

config_bp = Blueprint('config', __name__)

# Xác định thư mục gốc của dự án
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")

def init_app_and_config():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        handlers=[
            logging.StreamHandler()
        ]
    )
    logger = logging.getLogger(__name__)

    app = Flask(__name__)
    CORS(app, resources={r"/*": {"origins": "http://localhost:3000"}})

    DB_PATH = os.path.join(BASE_DIR, "database", "events.db")
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    # Gọi update_database để tạo bảng trước khi truy vấn
    update_database()

    def get_db_path():
        default_db_path = DB_PATH
        try:
            with db_rwlock.gen_rlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT db_path FROM processing_config WHERE id = 1")
                result = cursor.fetchone()
                conn.close()
            return result[0] if result else default_db_path
        except Exception as e:
            logger.error(f"Error getting DB_PATH from database: {e}")
            return default_db_path

    final_db_path = get_db_path()
    logger.info(f"Using DB_PATH: {final_db_path}")

    # Truy vấn cấu hình từ processing_config
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT input_path, output_path, frame_rate, frame_interval FROM processing_config WHERE id = 1")
        result = cursor.fetchone()
        conn.close()
        if result:
            INPUT_PATH, OUTPUT_PATH, FRAME_RATE, FRAME_INTERVAL = result
        else:
            INPUT_PATH = os.path.join(BASE_DIR, "Inputvideo")
            OUTPUT_PATH = os.path.join(BASE_DIR, "output_clips")
            FRAME_RATE = 30
            FRAME_INTERVAL = 6
    except Exception as e:
        logger.error(f"Error querying processing_config: {e}")
        INPUT_PATH = os.path.join(BASE_DIR, "Inputvideo")
        OUTPUT_PATH = os.path.join(BASE_DIR, "output_clips")
        FRAME_RATE = 30
        FRAME_INTERVAL = 6

    return app, final_db_path, logger

# Hàm đọc cấu hình từ file hoặc biến môi trường
def load_config():
    default_config = {
        "db_path": os.path.join(BASE_DIR, "database", "events.db"),
        "input_path": os.path.join(BASE_DIR, "Inputvideo"),
        "output_path": os.path.join(BASE_DIR, "output_clips")
    }
    
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading config file: {e}")
            return default_config
    
    return {
        "db_path": os.getenv("DB_PATH", default_config["db_path"]),
        "input_path": os.getenv("INPUT_PATH", default_config["input_path"]),
        "output_path": os.getenv("OUTPUT_PATH", default_config["output_path"])
    }

# Load cấu hình từ processing_config thay vì config.json
config = load_config()

@config_bp.route('/get-cameras', methods=['GET'])
def get_cameras():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT input_path FROM processing_config WHERE id = 1")
        result = cursor.fetchone()
        conn.close()

        if not result:
            return jsonify({"error": "video_root not found in configuration. Please update via /save-config endpoint."}), 400

        video_root = result[0]
        if not os.path.exists(video_root):
            return jsonify({"error": f"Directory {video_root} does not exist. Ensure the path is correct or create the directory."}), 400

        cameras = []
        for item in os.listdir(video_root):
            item_path = os.path.join(video_root, item)
            if os.path.isdir(item_path):
                cameras.append({"name": item, "path": item_path})

        return jsonify(cameras), 200
    except Exception as e:
        return jsonify({"error": f"Failed to retrieve cameras: {str(e)}"}), 500

@config_bp.route('/save-config', methods=['POST'])
def save_config():
    data = request.json
    video_root = data.get('video_root')
    output_path = data.get('output_path', config["output_path"])
    default_days = data.get('default_days')
    min_packing_time = data.get('min_packing_time', 10)
    max_packing_time = data.get('max_packing_time', 120)
    frame_rate = data.get('frame_rate')
    frame_interval = data.get('frame_interval')
    video_buffer = data.get('video_buffer', 2)
    selected_cameras = data.get('selected_cameras', [])
    run_default_on_start = data.get('run_default_on_start', 1)

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("ALTER TABLE processing_config ADD COLUMN run_default_on_start INTEGER DEFAULT 1")
        except sqlite3.OperationalError:
            pass
        cursor.execute("""
            INSERT OR REPLACE INTO processing_config (
                id, input_path, output_path, storage_duration, min_packing_time, 
                max_packing_time, frame_rate, frame_interval, video_buffer, default_frame_mode, selected_cameras, db_path, run_default_on_start
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (1, video_root, output_path, default_days, min_packing_time, max_packing_time, frame_rate, frame_interval, video_buffer, "default", json.dumps(selected_cameras), DB_PATH, run_default_on_start))

        cursor.execute("""
            INSERT OR REPLACE INTO frame_settings (id, mode, frame_rate, frame_interval, description)
            VALUES (?, ?, ?, ?, ?)
        """, (1, "default", frame_rate, frame_interval, "Chế độ mặc định từ giao diện"))

        conn.commit()
    except PermissionError as e:
        return jsonify({"error": f"Permission denied: {str(e)}. Check database file permissions."}), 403
    except Exception as e:
        return jsonify({"error": f"Database error: {str(e)}. Ensure the database is accessible."}), 500
    finally:
        conn.close()

    print("Config saved:", data)
    return jsonify({"message": "Configuration saved"}), 200

@config_bp.route('/save-general-info', methods=['POST'])
def save_general_info():
    data = request.json
    country = data.get('country')
    timezone = data.get('timezone')
    brand_name = data.get('brand_name')
    working_days = data.get('working_days', ["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"])
    
    # Bản đồ ngày tiếng Việt sang tiếng Anh
    day_map = {
        'Thứ Hai': 'Monday', 'Thứ Ba': 'Tuesday', 'Thứ Tư': 'Wednesday',
        'Thứ Năm': 'Thursday', 'Thứ Sáu': 'Friday', 'Thứ Bảy': 'Saturday',
        'Chủ Nhật': 'Sunday'
    }
    
    # Chuyển đổi working_days sang tiếng Anh
    working_days_en = [day_map.get(day, day) for day in working_days]
    
    from_time = data.get('from_time', "07:00")
    to_time = data.get('to_time', "23:00")

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO general_info (
                id, country, timezone, brand_name, working_days, from_time, to_time
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (1, country, timezone, brand_name, json.dumps(working_days_en), from_time, to_time))

        conn.commit()
    except PermissionError as e:
        return jsonify({"error": f"Permission denied: {str(e)}. Check database file permissions."}), 403
    except Exception as e:
        return jsonify({"error": f"Database error: {str(e)}. Ensure the database is accessible."}), 500
    finally:
        conn.close()

    print("General info saved:", data)
    return jsonify({"message": "General info saved"}), 200
```
## 📄 File: `logging_config.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/config/logging_config.py`

```python
import logging
import os
import sys
from datetime import datetime
from logging.handlers import RotatingFileHandler

class LogSizeFilter(logging.Filter):
    def __init__(self, log_file, max_size=10*1024*1024):
        super().__init__()
        self.log_file = log_file
        self.max_size = max_size
    
    def filter(self, record):
        if os.path.exists(self.log_file) and os.path.getsize(self.log_file) > self.max_size:
            if record.levelno < logging.INFO:
                return False
            print("Log file size exceeds 10MB, switching to INFO level", file=sys.stderr)
            return True
        return True

class ContextAdapter(logging.LoggerAdapter):
    def process(self, msg, kwargs):
        context = " ".join(f"{k}={v}" for k, v in self.extra.items())
        return f"[{context}] {msg}", kwargs

def setup_logging(base_dir, app_name="app", log_level=logging.INFO):
    log_dir = os.path.join(base_dir, "resources", "output_clips", "LOG")
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"{app_name}_{datetime.now().strftime('%Y-%m-%d')}.log")
    
    handler = RotatingFileHandler(log_file, maxBytes=10*1024*1024, backupCount=5)
    handler.setFormatter(logging.Formatter(
        '%(asctime)sZ [%(levelname)s] %(name)s: %(message)s',
        datefmt='%Y-%m-%dT%H:%M:%S'
    ))
    handler.addFilter(LogSizeFilter(log_file))
    
    logging.basicConfig(level=log_level, handlers=[handler])

def get_logger(module_name, context=None, separate_log=None):
    logger = logging.getLogger("app")
    if separate_log:
        log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "resources", "output_clips", "LOG")
        os.makedirs(log_dir, exist_ok=True)
        log_file = os.path.join(log_dir, f"{separate_log}_{datetime.now().strftime('%Y-%m-%d')}.log")
        file_handler = RotatingFileHandler(log_file, maxBytes=10*1024*1024, backupCount=5)
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s,%(msecs)03d - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        file_handler.setLevel(logging.INFO)
        logger.addHandler(file_handler)
    return ContextAdapter(logger, context or {})
```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/config/__init__.py`

```python

```
## 📄 File: `file_lister.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/scheduler/file_lister.py`

```python
import os
import sqlite3
import json
import logging
from datetime import datetime, timedelta
from statistics import median
from modules.db_utils import find_project_root, get_db_connection
from .db_sync import db_rwlock
import subprocess
import pytz

# Cấu hình múi giờ Việt Nam
VIETNAM_TZ = pytz.timezone('Asia/Ho_Chi_Minh')

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

logger = logging.getLogger("app")
logger.info("Logging initialized")

# Hằng số cho quét động
BUFFER_SECONDS = 6 * 60
N_FILES_FOR_ESTIMATE = 3
DEFAULT_DAYS = 7

DB_PATH = os.path.join(BASE_DIR, "database", "events.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

def get_db_path():
    try:
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT db_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            conn.close()
            return result[0] if result else DB_PATH
    except Exception as e:
        logger.error(f"Lỗi khi lấy DB_PATH: {e}")
        return DB_PATH

DB_PATH = get_db_path()
logger.info(f"Sử dụng DB_PATH: {DB_PATH}")

def get_file_creation_time(file_path):
    """Lấy thời gian tạo tệp bằng FFmpeg, chuẩn hóa theo múi giờ Việt Nam."""
    if not os.path.isfile(file_path) or not file_path.lower().endswith(('.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv')):
        return datetime.fromtimestamp(os.path.getctime(file_path), tz=VIETNAM_TZ)
    try:
        cmd = [
            "ffprobe",
            "-v", "quiet",
            "-print_format", "json",
            "-show_entries", "format_tags=creation_time:format=creation_time",
            file_path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        metadata = json.loads(result.stdout)
        creation_time = (
            metadata.get("format", {})
                    .get("tags", {})
                    .get("creation_time")
            or metadata.get("format", {}).get("creation_time")  
        )  
        if creation_time:
            utc_time = datetime.strptime(creation_time, "%Y-%m-%dT%H:%M:%S.%fZ")
            utc_time = pytz.utc.localize(utc_time)
            return utc_time.astimezone(VIETNAM_TZ)
        else:
            logger.warning(f"Không tìm thấy creation_time cho {file_path}, dùng giờ hệ thống")
            return datetime.fromtimestamp(os.path.getctime(file_path), tz=VIETNAM_TZ)
    except (subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as e:
        logger.error(f"Lỗi khi lấy creation_time cho {file_path}: {e}")
        return datetime.fromtimestamp(os.path.getctime(file_path), tz=VIETNAM_TZ)

def compute_chunk_interval(ctimes):
    ctimes = sorted(ctimes)[-N_FILES_FOR_ESTIMATE:]
    if len(ctimes) < 2:
        return 30
    intervals = [(ctimes[i+1] - ctimes[i]) / 60 for i in range(len(ctimes)-1)]
    return round(median(intervals))

def scan_files(root_path, video_root, time_threshold, max_ctime, restrict_to_current_date=False, camera_ctime_map=None, working_days=None, from_time=None, to_time=None, selected_cameras=None, strict_date_match=False):
    video_files = []
    file_ctimes = []
    video_extensions = ('.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv')
    current_date = datetime.now(VIETNAM_TZ).date()
    skipped_by_ctime = 0
    skipped_by_camera = 0
    ffprobe_errors = 0

    for root, dirs, files in os.walk(root_path):
        relative_path = os.path.relpath(root, video_root)
        camera_name = relative_path.split(os.sep)[0] if relative_path != "." else os.path.basename(video_root)
        if selected_cameras and camera_name not in selected_cameras:
            skipped_by_camera += len([f for f in files if f.lower().endswith(video_extensions)])
            continue

        for file in files:
            if file.lower().endswith(video_extensions):
                file_path = os.path.join(root, file)
                try:
                    file_ctime = get_file_creation_time(file_path)
                except Exception:
                    ffprobe_errors += 1
                    file_ctime = datetime.fromtimestamp(os.path.getctime(file_path), tz=VIETNAM_TZ)

                logger.debug(f"Checking file {file_path}, ctime={file_ctime}, max_ctime={max_ctime}")
                if time_threshold and file_ctime < time_threshold:
                    skipped_by_ctime += 1
                    continue

                if max_ctime and file_ctime <= max_ctime:
                    skipped_by_ctime += 1
                    continue

                weekday = file_ctime.strftime('%A')
                if working_days and weekday not in working_days:
                    skipped_by_ctime += 1
                    logger.debug(f"Skipped file {file_path} due to non-working day: {weekday}")
                    continue

                file_time = file_ctime.time()
                if from_time and to_time and not (from_time <= file_time <= to_time):
                    skipped_by_ctime += 1
                    logger.debug(f"Skipped file {file_path} due to time outside working hours: {file_time}")
                    continue

                relative_path = os.path.relpath(file_path, video_root)
                video_files.append(relative_path)
                file_ctimes.append(file_ctime.timestamp())
                logger.info(f"Tìm thấy tệp: {file_path}")

        if camera_ctime_map is not None:
            dir_ctime = datetime.fromtimestamp(os.path.getctime(root), tz=VIETNAM_TZ)
            camera_ctime_map[camera_name] = max(camera_ctime_map.get(camera_name, 0), dir_ctime.timestamp())

    logger.info(f"Thống kê quét: {skipped_by_ctime} tệp bỏ qua do ctime, {skipped_by_camera} tệp bỏ qua do camera, {ffprobe_errors} lỗi ffprobe")
    return video_files, file_ctimes

def save_files_to_db(conn, video_files, file_ctimes, scan_action, days, custom_path, video_root):
    if not video_files:
        return

    insert_data = []
    days_val = len(days) if isinstance(days, list) else days if days is not None else None
    for file_path, file_ctime in zip(video_files, file_ctimes):
        absolute_path = os.path.join(video_root, file_path) if scan_action != "custom" or not os.path.isfile(custom_path) else custom_path
        file_ctime_dt = datetime.fromtimestamp(file_ctime, tz=VIETNAM_TZ)
        priority = 1 if scan_action == "custom" else 0
        relative_path = os.path.relpath(absolute_path, video_root) if scan_action != "custom" else os.path.dirname(absolute_path)
        camera_name = relative_path.split(os.sep)[0] if relative_path != "." else os.path.basename(video_root)
        insert_data.append((
            scan_action, days_val, custom_path, absolute_path, datetime.now(VIETNAM_TZ), file_ctime_dt, priority, camera_name, 'pending', 0
        ))

    with conn:
        cursor = conn.cursor()
        cursor.executemany('''
            INSERT INTO file_list (program_type, days, custom_path, file_path, created_at, ctime, priority, camera_name, status, is_processed)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', insert_data)
        logger.info(f"Đã chèn {len(insert_data)} tệp vào file_list")

def list_files(video_root, scan_action, custom_path, days, db_path, default_scan_days=7, camera_ctime_map=None, is_initial_scan=False):
    try:
        with db_rwlock.gen_wlock():
            conn = get_db_connection()
            cursor = conn.cursor()

            if not os.path.exists(video_root):
                try:
                    os.makedirs(video_root, exist_ok=True)
                    logger.info(f"Đã tạo thư mục video root: {video_root}")
                except Exception as e:
                    logger.error(f"Không thể tạo thư mục video root: {video_root}, lỗi: {str(e)}")
                    raise Exception(f"Không thể tạo thư mục video root: {str(e)}")

            cursor.execute('SELECT MAX(ctime) FROM file_list')
            last_ctime = cursor.fetchone()[0]
            max_ctime = datetime.fromisoformat(last_ctime.replace('Z', '+00:00')) if last_ctime else datetime.min.replace(tzinfo=VIETNAM_TZ)

            cursor.execute("SELECT input_path, selected_cameras FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            if result:
                video_root = result[0]
                selected_cameras = json.loads(result[1]) if result[1] else []
            else:
                selected_cameras = []
            logger.info(f"Sử dụng video_root: {video_root}, Camera được chọn: {selected_cameras}")

            cursor.execute("SELECT working_days, from_time, to_time FROM general_info WHERE id = 1")
            general_info = cursor.fetchone()
            if general_info:
                try:
                    working_days_raw = general_info[0].encode('utf-8').decode('utf-8') if general_info[0] else ''
                    working_days = json.loads(working_days_raw) if working_days_raw else []
                except json.JSONDecodeError as e:
                    logger.error(f"JSON không hợp lệ trong working_days: {general_info[0]}, lỗi: {e}")
                    working_days = []
                from_time = datetime.strptime(general_info[1], '%H:%M').time() if general_info[1] else None
                to_time = datetime.strptime(general_info[2], '%H:%M').time() if general_info[2] else None
            else:
                working_days, from_time, to_time = [], None, None
            logger.info(f"Ngày làm việc: {working_days}, from_time: {from_time}, to_time: {to_time}")

            video_files = []
            file_ctimes = []

            if scan_action == "custom" and custom_path:
                if not os.path.exists(custom_path):
                    raise Exception(f"Đường dẫn không tồn tại: {custom_path}")
                if os.path.isfile(custom_path) and custom_path.lower().endswith(('.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv')):
                    file_name = os.path.basename(custom_path)
                    file_ctime = get_file_creation_time(custom_path)
                    video_files.append(file_name)
                    file_ctimes.append(file_ctime.timestamp())
                    logger.info(f"Tìm thấy tệp: {custom_path}")
                else:
                    video_files, file_ctimes = scan_files(
                        custom_path, video_root, None, None, False, None,
                        working_days, from_time, to_time, selected_cameras, strict_date_match=False
                    )
            elif scan_action == "first" and days:
                time_threshold = datetime.now(VIETNAM_TZ) - timedelta(days=days)
                video_files, file_ctimes = scan_files(
                    video_root, video_root, time_threshold, None, False, None,
                    working_days, from_time, to_time, selected_cameras, strict_date_match=False
                )
                cursor.execute('''
                    INSERT OR REPLACE INTO program_status (id, key, value)
                    VALUES ((SELECT id FROM program_status WHERE key = 'first_run_completed'), 'first_run_completed', 'true')
                ''')
                conn.commit()
            else:  # default
                time_threshold = datetime.now(VIETNAM_TZ) - timedelta(days=default_scan_days) if is_initial_scan else datetime.now(VIETNAM_TZ) - timedelta(days=1)
                restrict_to_current_date = not is_initial_scan
                video_files, file_ctimes = scan_files(
                    video_root, video_root, time_threshold, max_ctime, restrict_to_current_date, camera_ctime_map,
                    working_days, from_time, to_time, selected_cameras, strict_date_match=True
                )

            save_files_to_db(conn, video_files, file_ctimes, scan_action, days, custom_path, video_root)
            conn.close()
        logger.info(f"Tìm thấy {len(video_files)} tệp video")
        return video_files, file_ctimes
    except Exception as e:
        logger.error(f"Lỗi trong list_files: {e}")
        raise Exception(f"Lỗi trong list_files: {str(e)}")

def cleanup_stale_jobs():
    try:
        with db_rwlock.gen_wlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE file_list 
                SET status = 'pending'
                WHERE status = 'đang frame sampler ...'
                AND created_at < datetime('now', '-59 minutes')
            """)
            affected = cursor.rowcount
            conn.commit()
            conn.close()
            if affected > 0:
                logger.info(f"Reset {affected} stale jobs to pending")
    except Exception as e:
        logger.error(f"Error cleaning up stale jobs: {e}")

def run_file_scan(scan_action="default", days=None, custom_path=None):
    db_path = get_db_path()
    cleanup_stale_jobs()
    try:
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT input_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            conn.close()
            video_root = result[0] if result else ""
        if not video_root:
            raise Exception("Không tìm thấy video_root trong processing_config")
        camera_ctime_map = {}
        is_initial_scan = scan_action == "default" and days is not None  # Đặt is_initial_scan=True cho lần quét đầu tiên
        files, _ = list_files(video_root, scan_action, custom_path, days, db_path, camera_ctime_map=camera_ctime_map, is_initial_scan=is_initial_scan)
        return files
    except Exception as e:
        logger.error(f"Lỗi trong run_file_scan: {e}")
        raise

```
## 📄 File: `db_sync.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/scheduler/db_sync.py`

```python
from readerwriterlock import rwlock
import threading

db_rwlock = rwlock.RWLockFairD()  # Sử dụng RWLockFairD để tránh deadlock
frame_sampler_event = threading.Event()
event_detector_event = threading.Event()
event_detector_done = threading.Event()
event_detector_done.set()  # Ban đầu cho phép Frame Sampler chạy

```
## 📄 File: `system_monitor.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/scheduler/system_monitor.py`

```python
import psutil
import logging
import os
from datetime import datetime
from modules.config.logging_config import get_logger


# Đường dẫn tương đối từ project root
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class SystemMonitor:
    def __init__(self):
        self.min_batch_size = 2
        self.max_batch_size = 6
        self.cpu_threshold_low = 70  # Tăng batch_size nếu CPU < 70%
        self.cpu_threshold_high = 90  # Giảm batch_size nếu CPU > 90%
        self.setup_logging()

    def setup_logging(self):
        self.logger = get_logger(__name__, {"module": "system_monitor"})
        self.logger.info("SystemMonitor logging initialized")

    def get_system_metrics(self):
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            logging.info(f"System metrics retrieved: CPU={cpu_percent}%, Memory={memory_percent}%")
            return cpu_percent, memory_percent
        except Exception as e:
            logging.error(f"Error getting system metrics: {str(e)}")
            return 50.0, 50.0  # Giá trị mặc định nếu lỗi

    def get_batch_size(self, current_batch_size=2):
        logging.info(f"Calculating batch size, current={current_batch_size}")
        cpu_percent, memory_percent = self.get_system_metrics()
        if cpu_percent < self.cpu_threshold_low and memory_percent < self.cpu_threshold_low:
            new_batch_size = min(current_batch_size + 1, self.max_batch_size)
        elif cpu_percent > self.cpu_threshold_high or memory_percent > self.cpu_threshold_high:
            new_batch_size = max(current_batch_size - 1, self.min_batch_size)
        else:
            new_batch_size = current_batch_size
        logging.info(f"Calculated batch_size: {new_batch_size}")
        return new_batch_size

    def log_timeout_warning(self, timeout_files, total_files):
        logging.info(f"Checking timeout: {timeout_files}/{total_files} files")
        if timeout_files > total_files * 0.1:
            logging.warning(f"Warning: {timeout_files}/{total_files} files timed out, consider increasing resources")
        else:
            logging.info("No timeout warning triggered")

```
## 📄 File: `program_runner.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/scheduler/program_runner.py`

```python
import threading
import time
import os
import logging
from datetime import datetime
from modules.db_utils.db_utils import get_db_connection
from modules.technician.frame_sampler_trigger import FrameSamplerTrigger
from modules.technician.frame_sampler_no_trigger import FrameSamplerNoTrigger
from modules.technician.IdleMonitor import IdleMonitor
from modules.technician.event_detector import process_single_log
from .db_sync import db_rwlock, frame_sampler_event, event_detector_event, event_detector_done
import json
from modules.config.logging_config import  get_logger
import logging

logging.info("Logging initialized for program_runner")

# Biến tạm để lưu trạng thái chạy và số ngày
running_state = {"current_running": None, "days": None, "custom_path": None, "files": []}
# Dictionary lưu khóa cho từng nhóm video
video_locks = {}

def start_frame_sampler_thread(batch_size=1):
    logging.info(f"Starting {batch_size} frame sampler threads")
    threads = []
    for _ in range(batch_size):
        frame_sampler_thread = threading.Thread(target=run_frame_sampler)
        frame_sampler_thread.start()
        threads.append(frame_sampler_thread)
    return threads

def run_frame_sampler():
    logging.info("Frame sampler thread started")
    while True:  # Vòng lặp vô hạn để thread luôn chạy
        frame_sampler_event.wait()  # Chờ thông báo từ event
        logging.debug("Frame sampler event received")
        try:
            with db_rwlock.gen_rlock():  # Đồng bộ hóa truy cập database
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT file_path, camera_name FROM file_list WHERE is_processed = 0 ORDER BY priority DESC, created_at ASC")
                video_files = [(row[0], row[1]) for row in cursor.fetchall()]
                conn.close()
                logging.info(f"Found {len(video_files)} unprocessed video files")

            if not video_files:
                logging.info("No video files to process, clearing event")
                frame_sampler_event.clear()  # Xóa event và tiếp tục chờ
                continue

            for video_file, camera_name in video_files:
                # Kiểm tra trạng thái video trước khi xử lý
                with db_rwlock.gen_rlock():
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("SELECT status, is_processed FROM file_list WHERE file_path = ?", (video_file,))
                    result = cursor.fetchone()
                    conn.close()
                    if result and (result[0] == "đang frame sampler ..." or result[1] == 1):
                        logging.info(f"Skipping video {video_file}: already being processed or completed")
                        continue

                # Khóa theo video
                with db_rwlock.gen_wlock():
                    if video_file not in video_locks:
                        video_locks[video_file] = threading.Lock()
                video_lock = video_locks[video_file]
                if not video_lock.acquire(blocking=False):
                    logging.info(f"Skipping video {video_file}: locked by another thread")
                    continue

                try:
                    logging.info(f"Processing video: {video_file}")
                    # Kiểm tra qr_trigger_area và packing_area từ packing_profiles
                    with db_rwlock.gen_rlock():
                        conn = get_db_connection()
                        cursor = conn.cursor()
                        search_name = camera_name if camera_name else "CamTest"
                        if not camera_name:
                            logging.warning(f"No camera_name for {video_file}, falling back to CamTest")
                        cursor.execute("SELECT id, profile_name, qr_trigger_area, packing_area FROM packing_profiles WHERE profile_name LIKE ?", (f'%{search_name}%',))
                        profiles = cursor.fetchall()
                        conn.close()
                    
                    # Chọn profile có id lớn nhất
                    trigger = [0, 0, 0, 0]
                    packing_area = None
                    selected_profile = None
                    if profiles:
                        selected_profile = max(profiles, key=lambda x: x[0])  # Chọn id lớn nhất
                        profile_id, profile_name, qr_trigger_area, packing_area_raw = selected_profile
                        # Parse qr_trigger_area
                        try:
                            trigger = json.loads(qr_trigger_area) if qr_trigger_area else [0, 0, 0, 0]
                            if not isinstance(trigger, list) or len(trigger) != 4:
                                logging.error(f"Invalid qr_trigger_area for {profile_name}: {qr_trigger_area}, using default [0, 0, 0, 0]")
                                trigger = [0, 0, 0, 0]
                        except json.JSONDecodeError as e:
                            logging.error(f"Failed to parse qr_trigger_area for {profile_name}: {e}, using default [0, 0, 0, 0]")
                            trigger = [0, 0, 0, 0]
                        # Parse packing_area
                        try:
                            if packing_area_raw:
                                parsed = json.loads(packing_area_raw)
                                if isinstance(parsed, list) and len(parsed) == 4:
                                    packing_area = tuple(parsed)
                                else:
                                    logging.error(f"Invalid packing_area format for {profile_name}: {packing_area_raw}, using default None")
                                    packing_area = None
                            logging.info(f"Selected profile id={profile_id}, profile_name={profile_name}, qr_trigger_area={trigger}, packing_area={packing_area}")
                        except (ValueError, json.JSONDecodeError, KeyError, TypeError) as e:
                            logging.error(f"Failed to parse packing_area for {profile_name}: {e}, using default None")
                            packing_area = None
                    else:
                        logging.warning(f"No profile found for camera {search_name}, using default qr_trigger_area=[0, 0, 0, 0], packing_area=None")
                    
                    # Chạy IdleMonitor trước FrameSampler, truyền packing_area
                    idle_monitor = IdleMonitor()
                    logging.info(f"Running IdleMonitor for {video_file}")
                    idle_monitor.process_video(video_file, camera_name, packing_area)
                    work_block_queue = idle_monitor.get_work_block_queue()

                    # bỏ qua file không có work block
                    if work_block_queue.empty():
                        logging.info(f"No work blocks found for {video_file}, skipping FrameSampler and log file creation")
                        with db_rwlock.gen_wlock():
                            conn = get_db_connection()
                            cursor = conn.cursor()
                            cursor.execute("UPDATE file_list SET status = ?, is_processed = 1 WHERE file_path = ?", ("xong", video_file))
                            conn.commit()
                            conn.close()
                        continue  # Bỏ qua FrameSampler và chuyển sang video tiếp theo
                    # Chọn FrameSampler dựa trên trigger
                    if trigger != [0, 0, 0, 0]:
                        frame_sampler = FrameSamplerTrigger()
                        logging.info(f"Using FrameSamplerTrigger for {video_file}")
                    else:
                        frame_sampler = FrameSamplerNoTrigger()
                        logging.info(f"Using FrameSamplerNoTrigger for {video_file}")

                    with db_rwlock.gen_wlock():  # Khóa khi cập nhật trạng thái
                        conn = get_db_connection()
                        cursor = conn.cursor()
                        cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("đang frame sampler ...", video_file))
                        conn.commit()
                        conn.close()
                        logging.debug(f"Updated status for {video_file} to 'đang frame sampler ...'")
                    
                    # Gọi process_video với work block từ queue
                    log_file = None
                    while not work_block_queue.empty():
                        work_block = work_block_queue.get()
                        start_time = work_block['start_time']
                        end_time = work_block['end_time']
                        logging.info(f"Processing video block: start_time={start_time}, end_time={end_time}")
                        log_file = frame_sampler.process_video(
                            video_file,
                            video_lock=frame_sampler.video_lock,
                            get_packing_area_func=frame_sampler.get_packing_area,
                            process_frame_func=frame_sampler.process_frame,
                            frame_interval=frame_sampler.frame_interval,
                            start_time=start_time,
                            end_time=end_time
                        )
                    
                    with db_rwlock.gen_wlock():  # Khóa khi cập nhật trạng thái cuối
                        conn = get_db_connection()
                        cursor = conn.cursor()
                        if log_file:
                            cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("xong", video_file))
                            event_detector_event.set()  # Kích hoạt Event Detector sau mỗi video
                            logging.info(f"Video {video_file} processed successfully, log file: {log_file}")
                        else:
                            cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("lỗi", video_file))
                            logging.error(f"Failed to process video {video_file}")
                        conn.commit()
                        conn.close()
                    
                    # Tạm dừng sau khi xử lý xong một video
                    logging.info(f"Frame Sampler pausing after processing {video_file}, waiting for Event Detector...")
                    while not event_detector_done.is_set():
                        time.sleep(1)  # Chờ Event Detector hoàn tất

                finally:
                    video_lock.release()
                    with db_rwlock.gen_wlock():
                        video_locks.pop(video_file, None)  # Xóa khóa sau khi xử lý xong
                    logging.debug(f"Released lock for {video_file}")

            frame_sampler_event.clear()  # Xóa event sau khi xử lý hết file
            logging.info("All video files processed, clearing frame sampler event")
        except Exception as e:
            logging.error(f"Error in Frame Sampler thread: {str(e)}")
            frame_sampler_event.clear()  # Đảm bảo thread "ngủ" lại nếu có lỗi

def start_event_detector_thread():
    logging.info("Starting event detector thread")
    event_detector_thread = threading.Thread(target=run_event_detector)
    event_detector_thread.start()
    return event_detector_thread

def run_event_detector():
    logging.info("Event detector thread started")
    while True:
        event_detector_event.wait()
        logging.debug("Event detector event received")
        try:
            with db_rwlock.gen_rlock():  # Đồng bộ hóa truy cập database
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT log_file FROM processed_logs WHERE is_processed = 0")
                log_files = [row[0] for row in cursor.fetchall()]
                conn.close()
                logging.info(f"Found {len(log_files)} unprocessed log files")

            if not log_files:
                event_detector_event.clear()
                event_detector_done.set()  # Báo hiệu Frame Sampler tiếp tục
                logging.info("No log files to process, clearing event and signaling done")
                continue

            for log_file in log_files:
                logging.info(f"Event Detector processing: {log_file}")
                process_single_log(log_file)
            event_detector_event.clear()
            event_detector_done.set()  # Báo hiệu Frame Sampler tiếp tục sau khi xử lý hết log
            logging.info("All log files processed, clearing event and signaling done")
        except Exception as e:
            logging.error(f"Error in Event Detector thread: {str(e)}")
            event_detector_event.clear()
            event_detector_done.set()  # Vẫn báo hiệu Frame Sampler tiếp tục nếu có lỗi

```
## 📄 File: `program.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/scheduler/program.py`

```python
from flask import Blueprint, request, jsonify
import os
import json
import threading
import pytz
from datetime import datetime, timedelta
import logging
from modules.db_utils import find_project_root, get_db_connection
from .file_lister import run_file_scan, get_db_path
from .batch_scheduler import BatchScheduler
from .db_sync import frame_sampler_event, event_detector_event
import logging

VIETNAM_TZ = pytz.timezone('Asia/Ho_Chi_Minh')

program_bp = Blueprint('program', __name__)

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database", "events.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

DB_PATH = get_db_path()
LOG_DIR = os.path.join(BASE_DIR, "../../resources/output_clips/LOG")
os.makedirs(LOG_DIR, exist_ok=True)

logger = logging.getLogger("app")
logger.info("Program logging initialized")

db_rwlock = threading.RLock()
running_state = {
    "days": None,
    "custom_path": None,
    "current_running": None,
    "files": []
}

scheduler = BatchScheduler()

def init_default_program():
    logger.info("Initializing default program")
    try:
        with db_rwlock:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT value FROM program_status WHERE key = "first_run_completed"')
            result = cursor.fetchone()
            conn.close()
        first_run_completed = result[0] == 'true' if result else False
        logger.info(f"First run completed: {first_run_completed}, Scheduler running: {scheduler.running}")
        if first_run_completed and not scheduler.running:
            logger.info("Chuyển sang chế độ chạy mặc định (quét lặp)")
            running_state["current_running"] = "Mặc định"
            scheduler.start()
    except Exception as e:
        logger.error(f"Error initializing default program: {e}")

init_default_program()

@program_bp.route('/program', methods=['POST'])
def program():
    logger.info(f"POST /program called, Current state before action: scheduler_running={scheduler.running}, running_state={running_state}")
    data = request.json
    card = data.get('card')
    action = data.get('action')
    custom_path = data.get('custom_path', '')
    days = data.get('days')

    if card == "Lần đầu" and action == "run":
        try:
            with db_rwlock:
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute('SELECT value FROM program_status WHERE key = "first_run_completed"')
                result = cursor.fetchone()
                first_run_completed = result[0] == 'true' if result else False
                conn.close()
            if first_run_completed:
                logger.warning("First run already completed")
                return jsonify({"error": "Lần đầu đã chạy trước đó, không thể chạy lại"}), 400
        except Exception as e:
            logger.error(f"Failed to check first run status: {str(e)}")
            return jsonify({"error": f"Failed to check first run status: {str(e)}"}), 500

    if action == "run":
        logger.info(f"Action run for card: {card}, scheduler_running={scheduler.running}")
        if scheduler.running and card == "Chỉ định":
            scheduler.pause()
            running_state["current_running"] = None
            running_state["files"] = []
        if card == "Lần đầu":
            if not days:
                logger.error("Days required for Lần đầu")
                return jsonify({"error": "Days required for Lần đầu"}), 400
            running_state["days"] = days
            running_state["custom_path"] = None
            try:
                run_file_scan(scan_action="first", days=days)
            except Exception as e:
                logger.error(f"Failed to run first scan: {str(e)}")
                return jsonify({"error": f"Failed to run first scan: {str(e)}"}), 500
        elif card == "Chỉ định":
            if not custom_path:
                logger.error("Custom path required for Chỉ định")
                return jsonify({"error": "Custom path required cho Chỉ định"}), 400
            abs_path = os.path.abspath(custom_path)
            if not os.path.exists(abs_path):
                logger.error(f"Custom path {abs_path} does not exist")
                return jsonify({"error": f"Custom path {abs_path} does not exist"}), 400
            try:
                with db_rwlock:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("SELECT status, is_processed FROM file_list WHERE file_path = ? AND (status = 'xong' OR is_processed = 1)", (abs_path,))
                    result = cursor.fetchone()
                    conn.close()
                    if result:
                        logger.warning(f"File {abs_path} already processed with status {result[0]}")
                        return jsonify({"error": "File đã được xử lý"}), 400
            except Exception as e:
                logger.error(f"Error checking file status: {str(e)}")
                return jsonify({"error": f"Error checking file status: {str(e)}"}), 500
            running_state["custom_path"] = abs_path
            running_state["days"] = None
            try:
                scheduler.pause()
                run_file_scan(scan_action="custom", custom_path=abs_path)
                with db_rwlock:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("SELECT file_path FROM file_list WHERE custom_path = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1", (abs_path,))
                    result = cursor.fetchone()
                    conn.close()
                if result:
                    from .program_runner import start_frame_sampler_thread, start_event_detector_thread
                    frame_sampler_event.set()
                    start_frame_sampler_thread()
                    start_event_detector_thread()
                    logger.info(f"[Chỉ định] Processing started: {result[0]}")
                    import time
                    while True:
                        with db_rwlock:
                            conn = get_db_connection()
                            cursor = conn.cursor()
                            cursor.execute("SELECT status FROM file_list WHERE file_path = ?", (result[0],))
                            status_result = cursor.fetchone()
                            conn.close()
                        if status_result and status_result[0] == 'xong':
                            break
                        time.sleep(2)
                    logger.info(f"[Chỉ định] Processing completed: {result[0]}")
                    scheduler.resume()
                    try:
                        if not scheduler.running:
                            scheduler.start()
                            logger.info("Restarted scheduler for default mode")
                        run_file_scan(scan_action="default")
                        frame_sampler_event.set()
                        event_detector_event.set()
                        logger.info(f"Completed Chỉ định, transitioning to default: scheduler_running={scheduler.running}, running_state={running_state}")
                    except Exception as e:
                        logger.error(f"Error triggering default scan: {str(e)}")
                else:
                    logger.error(f"[Chỉ định] No pending file found at: {abs_path}")
                    return jsonify({"error": "Không tìm thấy file pending để xử lý"}), 404
            except Exception as e:
                logger.error(f"[Chỉ định] Error: {str(e)}")
                scheduler.resume()
                return jsonify({"error": f"Xử lý chỉ định thất bại: {str(e)}"}), 500
        else:
            running_state["days"] = None
            running_state["custom_path"] = None

        running_state["current_running"] = card
        if not scheduler.running:
            running_state["current_running"] = "Mặc định"
            scheduler.start()

        if card == "Lần đầu":
            try:
                with db_rwlock:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("UPDATE program_status SET value = ? WHERE key = ?", ("true", "first_run_completed"))
                    conn.commit()
                    conn.close()
                logger.info("Chuyển sang chế độ chạy mặc định (quét lặp) sau khi hoàn thành Lần đầu")
            except Exception as e:
                logger.error(f"Error updating first_run_completed: {e}")

    elif action == "stop":
        logger.info(f"Action stop called, current_state={running_state}, scheduler_running={scheduler.running}")
        running_state["current_running"] = None
        running_state["days"] = None
        running_state["custom_path"] = None
        running_state["files"] = []
        if not scheduler.running:
            scheduler.start()
            logger.info("Scheduler restarted for default mode")
        logger.info(f"State after stop: running_state={running_state}, scheduler_running={scheduler.running}")

    logger.info(f"Program action completed: {card} {action}, final_state={running_state}, scheduler_running={scheduler.running}")
    return jsonify({
        "current_running": running_state["current_running"],
        "days": running_state.get("days"),
        "custom_path": running_state.get("custom_path")
    }), 200

@program_bp.route('/program', methods=['GET'])
def get_program_status():
    logger.info("GET /program called")
    return jsonify({
        "current_running": running_state["current_running"],
        "days": running_state.get("days"),
        "custom_path": running_state.get("custom_path")
    }), 200

@program_bp.route('/confirm-run', methods=['POST'])
def confirm_run():
    logger.info("POST /confirm-run called")
    data = request.json
    card = data.get('card')

    scan_action = "first" if card == "Lần đầu" else "default" if card == "Mặc định" else "custom"
    days = running_state.get("days") if card == "Lần đầu" else None
    custom_path = running_state.get("custom_path", '')
    try:
        run_file_scan(scan_action=scan_action, days=days, custom_path=custom_path)
        logger.info(f"Files queued for {scan_action}")
    except Exception as e:
        logger.error(f"Failed to list files: {str(e)}")
        return jsonify({"error": f"Failed to list files: {str(e)}"}), 500

    return jsonify({
        "program_type": scan_action
    }), 200

@program_bp.route('/program-progress', methods=['GET'])
def get_program_progress():
    logger.info("GET /program-progress called")
    try:
        with db_rwlock:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT file_path, status FROM file_list WHERE is_processed = 0 ORDER BY created_at DESC")
            files_status = [{"file": row[0], "status": row[1]} for row in cursor.fetchall()]
            conn.close()
        logger.info(f"Retrieved {len(files_status)} files for status")
        return jsonify({"files": files_status}), 200
    except Exception as e:
        logger.error(f"Failed to retrieve program progress: {str(e)}")
        return jsonify({"error": f"Failed to retrieve program progress: {str(e)}"}), 500

@program_bp.route('/check-first-run', methods=['GET'])
def check_first_run():
    logger.info("GET /check-first-run called")
    try:
        with db_rwlock:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT value FROM program_status WHERE key = "first_run_completed"')
            result = cursor.fetchone()
            conn.close()
            first_run_completed = result[0] == 'true' if result else False
        logger.info(f"First run completed: {first_run_completed}")
        return jsonify({"first_run_completed": first_run_completed}), 200
    except Exception as e:
        logger.error(f"Failed to check first run status: {str(e)}")
        return jsonify({"error": f"Failed to check first run status: {str(e)}"}), 500

@program_bp.route('/get-cameras', methods=['GET'])
def get_cameras():
    logger.info("GET /get-cameras called")
    try:
        with db_rwlock:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT selected_cameras FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            conn.close()
            cameras = result[0] if result else "[]"
            cameras_list = json.loads(cameras) if cameras else []
        logger.info(f"Retrieved {len(cameras_list)} cameras")
        return jsonify({"cameras": cameras_list}), 200
    except Exception as e:
        logger.error(f"Failed to retrieve cameras: {str(e)}")
        return jsonify({"error": f"Failed to retrieve cameras: {str(e)}"}), 500

@program_bp.route('/get-camera-folders', methods=['GET'])
def get_camera_folders():
    logger.info("GET /get-camera-folders called")
    try:
        with db_rwlock:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT input_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            video_root = result[0] if result else os.path.join(BASE_DIR, "Inputvideo")
            conn.close()

        if not os.path.exists(video_root):
            logger.error(f"Directory {video_root} does not exist")
            return jsonify({"error": f"Directory {video_root} does not exist. Ensure the path is correct or create the directory."}), 400

        folders = []
        for folder_name in os.listdir(video_root):
            folder_path = os.path.join(video_root, folder_name)
            if os.path.isdir(folder_path):
                folders.append({"name": folder_name, "path": folder_path})
        logger.info(f"Retrieved {len(folders)} camera folders")
        return jsonify({"folders": folders}), 200
    except Exception as e:
        logger.error(f"Failed to retrieve camera folders: {str(e)}")
        return jsonify({"error": f"Failed to retrieve camera folders: {str(e)}"}), 500

if __name__ == "__main__":
    logger.info("Main program started")
    if not scheduler.running:
        running_state["current_running"] = "Mặc định"
        scheduler.start()

```
## 📄 File: `batch_scheduler.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/scheduler/batch_scheduler.py`

```python
import os
import threading
import time
import logging
import sqlite3
import pytz
import psutil  # THÊM IMPORT MỚI
from datetime import datetime, timedelta
from modules.db_utils import get_db_connection
from .db_sync import db_rwlock, frame_sampler_event, event_detector_event
from .file_lister import run_file_scan
from .program_runner import start_frame_sampler_thread, start_event_detector_thread
import logging

logger = logging.getLogger("app")
logger.info("BatchScheduler logging initialized")

# Cấu hình múi giờ Việt Nam
VIETNAM_TZ = pytz.timezone('Asia/Ho_Chi_Minh')

class SystemMonitor:
    """Theo dõi tài nguyên hệ thống và tính batch_size động."""
    def __init__(self):
        self.cpu_threshold_low = 70
        self.cpu_threshold_high = 90
        self.base_batch_size = 2
        self.max_batch_size = 6

    def get_cpu_usage(self):
        """Lấy CPU usage thực tế từ hệ thống"""
        try:
            # Lấy CPU usage trung bình trong 1 giây
            cpu_percent = psutil.cpu_percent(interval=1)
            logger.debug(f"Current CPU usage: {cpu_percent}%")
            return cpu_percent
        except Exception as e:
            logger.error(f"Error getting CPU usage: {e}")
            return 50  # Fallback value nếu có lỗi

    def get_memory_usage(self):
        """Lấy memory usage thực tế"""
        try:
            memory_percent = psutil.virtual_memory().percent
            logger.debug(f"Current memory usage: {memory_percent}%")
            return memory_percent
        except Exception as e:
            logger.error(f"Error getting memory usage: {e}")
            return 50  # Fallback value

    def get_batch_size(self, current_batch_size):
        cpu_usage = self.get_cpu_usage()
        memory_usage = self.get_memory_usage()
        
        logger.debug(f"Resource usage - CPU: {cpu_usage}%, Memory: {memory_usage}%")
        
        # Kiểm tra nếu tài nguyên quá tải
        if cpu_usage > self.cpu_threshold_high or memory_usage > 85:
            if current_batch_size > self.base_batch_size:
                new_batch_size = current_batch_size - 1
                logger.warning(f"High resource usage (CPU: {cpu_usage}%, RAM: {memory_usage}%), reducing batch size: {current_batch_size} -> {new_batch_size}")
                return new_batch_size
        
        # Kiểm tra nếu tài nguyên nhàn rỗi
        elif cpu_usage < self.cpu_threshold_low and memory_usage < 70:
            if current_batch_size < self.max_batch_size:
                new_batch_size = current_batch_size + 1
                logger.info(f"Low resource usage (CPU: {cpu_usage}%, RAM: {memory_usage}%), increasing batch size: {current_batch_size} -> {new_batch_size}")
                return new_batch_size
        
        # Giữ nguyên nếu tài nguyên ổn định
        return current_batch_size

    def log_system_info(self):
        """Log thông tin hệ thống khi khởi động"""
        try:
            cpu_count = psutil.cpu_count()
            memory_total = psutil.virtual_memory().total / (1024**3)  # GB
            logger.info(f"System info - CPU cores: {cpu_count}, Total RAM: {memory_total:.1f}GB")
            logger.info(f"Batch size config - Base: {self.base_batch_size}, Max: {self.max_batch_size}")
            logger.info(f"CPU thresholds - Low: {self.cpu_threshold_low}%, High: {self.cpu_threshold_high}%")
        except Exception as e:
            logger.error(f"Error logging system info: {e}")

class BatchScheduler:
    def __init__(self):
        self.batch_size = 2
        self.sys_monitor = SystemMonitor()
        self.scan_interval = 60
        self.timeout_seconds = 3600
        self.running = False
        self.queue_limit = 5
        self.sampler_threads = []
        self.detector_thread = None
        self.pause_event = threading.Event()
        self.pause_event.set()

    def pause(self):
        logger.info(f"BatchScheduler paused, current_batch_size={self.batch_size}")
        self.pause_event.clear()

    def resume(self):
        logger.info(f"BatchScheduler resumed, current_batch_size={self.batch_size}")
        self.pause_event.set()

    def get_pending_files(self):
        """Lấy danh sách file chưa xử lý, giới hạn queue_limit."""
        try:
            with db_rwlock.gen_rlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT file_path, camera_name FROM file_list WHERE status = 'pending' AND is_processed = 0 ORDER BY priority DESC, created_at ASC LIMIT ?", 
                             (self.queue_limit,))
                files = [(row[0], row[1]) for row in cursor.fetchall()]
                conn.close()
            return files
        except Exception as e:
            logger.error(f"Error retrieving pending files: {e}")
            return []

    def update_file_status(self, file_path, status):
        """Cập nhật trạng thái file trong file_list."""
        try:
            with db_rwlock.gen_wlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("UPDATE file_list SET status = ?, is_processed = ? WHERE file_path = ?",
                             (status, 1 if status in ['xong', 'lỗi', 'timeout'] else 0, file_path))
                conn.commit()
                conn.close()
        except Exception as e:
            logger.error(f"Error updating file status for {file_path}: {e}")

    def check_timeout(self):
        """Kiểm tra và cập nhật trạng thái timeout cho file quá 900s."""
        try:
            with db_rwlock.gen_wlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT file_path, created_at FROM file_list WHERE status = 'đang frame sampler ...'")
                for row in cursor.fetchall():
                    created_at = datetime.fromisoformat(row[1].replace('Z', '+00:00')) if row[1] else datetime.min.replace(tzinfo=VIETNAM_TZ)
                    if (datetime.now(VIETNAM_TZ) - created_at).total_seconds() > self.timeout_seconds:
                        cursor.execute("UPDATE file_list SET status = ?, is_processed = 1 WHERE file_path = ?", 
                                     ('timeout', row[0]))
                        logger.warning(f"Timeout processing {row[0]} after {self.timeout_seconds}s")
                conn.commit()
                conn.close()
        except Exception as e:
            logger.error(f"Error checking timeout: {e}")

    def scan_files(self):
        """Quét file mới định kỳ (15 phút)."""
        logger.info("Bắt đầu quét lặp")
        while self.running:
            try:
                logger.debug("Kiểm tra quét lặp, running=%s, paused=%s", self.running, not self.pause_event.is_set())
                self.pause_event.wait()
                with db_rwlock.gen_rlock():
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("SELECT COUNT(*) FROM file_list WHERE status = 'pending' AND is_processed = 0")
                    pending_count = cursor.fetchone()[0]
                    conn.close()

                if pending_count >= self.queue_limit:
                    logger.warning(f"Queue full ({pending_count}/{self.queue_limit}), skipping file scan")
                else:
                    run_file_scan("default")
                    frame_sampler_event.set()
                time.sleep(self.scan_interval)
            except Exception as e:
                logger.error(f"Error in file scan: {e}")

    def run_batch(self):
        """Chạy batch xử lý file, sử dụng run_frame_sampler."""
        while self.running:
            try:
                self.pause_event.wait()
                self.batch_size = self.sys_monitor.get_batch_size(self.batch_size)

                if not self.sampler_threads or len(self.sampler_threads) != self.batch_size:
                    for thread in self.sampler_threads:
                        if thread.is_alive():
                            thread.join(timeout=1)
                    self.sampler_threads = start_frame_sampler_thread(self.batch_size)
                    logger.info(f"Started {self.batch_size} frame sampler threads")

                if not self.detector_thread or not self.detector_thread.is_alive():
                    self.detector_thread = start_event_detector_thread()
                    logger.info("Started event detector thread")

                self.check_timeout()

                files = self.get_pending_files()
                if not files:
                    frame_sampler_event.clear()
                    frame_sampler_event.wait()
                    continue

                frame_sampler_event.set()
                event_detector_event.set()
                time.sleep(60)
            except Exception as e:
                logger.error(f"Error in batch processing: {e}")

    def start(self):
        """Khởi động BatchScheduler."""
        if not self.running:
            # Log system info khi khởi động
            self.sys_monitor.log_system_info()
            
            self.running = True
            days = [(datetime.now(VIETNAM_TZ) - timedelta(days=i)).date().isoformat() for i in range(6, -1, -1)]
            logger.info(f"Initial scan for days: {days}")
            try:
                run_file_scan("default", days=days)
                frame_sampler_event.set()
            except Exception as e:
                logger.error(f"Initial scan failed: {e}")

            scan_thread = threading.Thread(target=self.scan_files)
            batch_thread = threading.Thread(target=self.run_batch)
            scan_thread.start()
            batch_thread.start()
            logger.info(f"BatchScheduler started, batch_size={self.batch_size}, scan_interval={self.scan_interval}")

    def stop(self):
        """Dừng BatchScheduler."""
        self.running = False
        frame_sampler_event.clear()
        event_detector_event.clear()
        for thread in self.sampler_threads:
            if thread.is_alive():
                thread.join(timeout=1)
        if self.detector_thread and self.detector_thread.is_alive():
            self.detector_thread.join(timeout=1)
        logger.info("BatchScheduler stopped")
```
## 📄 File: `file_parser.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/utils/file_parser.py`

```python
import pandas as pd
import base64
import os
from io import BytesIO
import logging
import csv

# Thiết lập logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def force_split_excel_text(df: pd.DataFrame) -> pd.DataFrame:
    if df.shape[1] == 1 and isinstance(df.columns[0], str) and "\t" in df.columns[0]:
        raw = df.to_csv(index=False, header=False)
        reader = csv.reader(raw.splitlines(), delimiter='\t')
        rows = list(reader)
        df_fixed = pd.DataFrame(rows[1:], columns=rows[0])
        logger.debug(f"[DEBUG] After force_split_excel_text - df.columns: {df_fixed.columns.tolist()}")
        logger.debug(f"[DEBUG] After force_split_excel_text - df.shape: {df_fixed.shape}")
        return df_fixed
    return df

def parse_uploaded_file(file_content: str = None, file_path: str = None, is_excel: bool = False) -> pd.DataFrame:
    """
    Decode base64-encoded file content or read from file path and return a pandas DataFrame.
    Supports both CSV and Excel formats.
    Raises detailed exceptions instead of falling back silently.
    """
    logger.debug(f"parse_uploaded_file called with is_excel={is_excel}, file_content={'provided' if file_content else 'not provided'}, file_path={file_path}")

    if not file_content and not file_path:
        raise ValueError("Either file_content or file_path must be provided.")

    if file_content:
        try:
            file_bytes = base64.b64decode(file_content)
        except Exception as e:
            raise ValueError(f"Failed to decode base64 content: {e}")
        buffer = BytesIO(file_bytes)
    elif file_path:
        if not os.path.exists(file_path):
            raise ValueError(f"File not found at path: {file_path}")
        buffer = file_path  # pandas can read directly from file path

    try:
        if is_excel:
            logger.debug("Reading file as Excel (pd.read_excel)")
            try:
                df = pd.read_excel(buffer, header=None, engine='openpyxl')  # Xóa encoding
            except Exception as e:
                logger.debug(f"Failed to read Excel with pd.read_excel: {str(e)}")
                logger.debug("Falling back to pd.read_csv")
                buffer.seek(0)  # Reset con trỏ file để đọc lại
                df = pd.read_csv(buffer, sep=",", encoding='utf-8-sig', engine='python')
            logger.debug(f"[DEBUG] Raw DataFrame before processing: {df.to_dict()}")
            logger.debug(f"[DEBUG] Raw first row (potential header): {df.iloc[0].tolist()}")
            if df.shape[0] > 1:
                df.columns = df.iloc[0].values.tolist()
                df = df[1:]
                df = force_split_excel_text(df)  # Fix nếu dính lỗi tab
            else:
                raise ValueError("Excel file missing header/data")
            logger.debug(f"[DEBUG] df.columns: {df.columns.tolist()}")
            logger.debug(f"[DEBUG] df.shape: {df.shape}")
            logger.debug(f"[DEBUG] df.head(2): {df.head(2).to_dict()}")
            return df
        else:
            logger.debug("Reading file as CSV (pd.read_csv)")
            try:
                df = pd.read_csv(buffer, sep=",", encoding='latin1', engine='python')  # Thử dấu phẩy trước
                # Kiểm tra nếu chỉ có 1 cột và cột đó chứa dấu ;
                if len(df.columns) == 1 and df.columns[0] and isinstance(df.columns[0], str) and ";" in df.columns[0]:
                    logger.debug("Detected single column with semicolon, retrying with sep=';'")
                    if file_content:
                        buffer.seek(0)  # Reset con trỏ file để đọc lại nếu dùng file_content
                    df = pd.read_csv(buffer, sep=";", encoding='latin1', engine='python')
                return df
            except pd.errors.ParserError:
                if file_content:
                    buffer.seek(0)  # Reset con trỏ file để đọc lại nếu dùng file_content
                return pd.read_csv(buffer, sep=";", encoding='latin1', engine='python')  # Nếu lỗi, thử dấu chấm phẩy
    except Exception as e:
        file_type = 'Excel' if is_excel else 'CSV'
        raise ValueError(f"Failed to read {file_type} file: {e}")
```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/utils/__init__.py`

```python

```
## 📄 File: `LicenseGuard.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/system/LicenseGuard.py`

```python
# LicenseGuard.py - Module kiểm tra bản quyền (QR watermark, MAC address)

```
## 📄 File: `SystemMonitor.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/system/SystemMonitor.py`

```python
# SystemMonitor.py - Module theo dõi hiệu suất và tài nguyên hệ thống

```
## 📄 File: `SystemCalendar.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/system/SystemCalendar.py`

```python
# SystemCalendar.py - Module quản lý lịch làm việc (ngày nghỉ, ca làm việc)

```
## 📄 File: `AuditLogger.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/system/AuditLogger.py`

```python
# AuditLogger.py - Module ghi log hệ thống (lịch sử xử lý, lỗi, người dùng)

```
## 📄 File: `TG.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/db_utils/TG.py`

```python

```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/db_utils/__init__.py`

```python
from .db_utils import find_project_root, get_db_connection

```
## 📄 File: `db_utils.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/db_utils/db_utils.py`

```python
import sqlite3
import os

# Hàm tìm thư mục gốc dự án dựa trên tên thư mục
def find_project_root(start_path):
    current_path = os.path.abspath(start_path)
    while os.path.basename(current_path) != "V_Track":
        parent_path = os.path.dirname(current_path)
        if parent_path == current_path:  # Đã đến thư mục gốc của hệ thống (/)
            raise ValueError("Could not find project root (V_Track directory)")
        current_path = parent_path
    return current_path

# Xác định thư mục gốc của dự án
BASE_DIR = find_project_root(os.path.abspath(__file__))

# Định nghĩa DB_PATH mặc định dựa trên BASE_DIR
DEFAULT_DB_PATH = os.path.join(BASE_DIR, "backend/database", "events.db")
os.makedirs(os.path.dirname(DEFAULT_DB_PATH), exist_ok=True)  # Tạo thư mục database nếu chưa có

# Hàm lấy DB_PATH từ processing_config
def get_db_path():
    try:
        conn = sqlite3.connect(DEFAULT_DB_PATH)  # Kết nối tạm thời để truy vấn
        cursor = conn.cursor()
        cursor.execute("SELECT db_path FROM processing_config WHERE id = 1")
        result = cursor.fetchone()
        conn.close()
        return result[0] if result else DEFAULT_DB_PATH
    except Exception as e:
        print(f"Error getting DB_PATH from database: {e}")
        return DEFAULT_DB_PATH

DB_PATH = get_db_path()

def get_db_connection():
    if not os.path.exists(DB_PATH):
        raise FileNotFoundError(f"Database file not found: {DB_PATH}")
    if not os.access(DB_PATH, os.R_OK):
        raise PermissionError(f"No read permission for database: {DB_PATH}")
    if not os.access(DB_PATH, os.W_OK):
        raise PermissionError(f"No write permission for database: {DB_PATH}")
    return sqlite3.connect(DB_PATH, check_same_thread=False)

```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/account/__init__.py`

```python

```
## 📄 File: `account.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/account/account.py`

```python

```
## 📄 File: `query.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/query/query.py`

```python
from flask import Blueprint, request, jsonify
from datetime import datetime
import csv
import io
import os
import base64
import pandas as pd
import json
from io import BytesIO
from modules.db_utils import find_project_root, get_db_connection
from ..utils.file_parser import parse_uploaded_file
from modules.scheduler.db_sync import db_rwlock  # Thêm import db_rwlock

query_bp = Blueprint('query', __name__)

# Xác định thư mục gốc của dự án
BASE_DIR = find_project_root(os.path.abspath(__file__))

# Định nghĩa DB_PATH dựa trên BASE_DIR
DB_PATH = os.path.join(BASE_DIR, "database", "events.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

@query_bp.route('/get-csv-headers', methods=['POST'])
def get_csv_headers():
    data = request.get_json()
    file_content = data.get('file_content', '')
    file_path = data.get('file_path', '')
    is_excel = data.get('is_excel', False)

    if file_content:
        if not file_content.strip():
            return jsonify({"error": "File CSV is empty. Please provide a valid CSV file with content."}), 400

        try:
            df = parse_uploaded_file(file_content=file_content, is_excel=is_excel)
            rows = [df.columns.tolist()]
        except Exception as e:
            return jsonify({"error": f"Failed to read file content: {str(e)}. Ensure the content is properly formatted."}), 400
    elif file_path:
        if not os.path.exists(file_path):
            return jsonify({"error": f"File not found at path: {file_path}. Please check the file path and try again."}), 404

        try:
            with open(file_path, "rb") as f:
                file_content = base64.b64encode(f.read()).decode("utf-8")
            df = parse_uploaded_file(file_content=file_content, is_excel=is_excel)
            rows = [df.columns.tolist()]
        except Exception as e:
            return jsonify({"error": f"Failed to read file from path {file_path}: {str(e)}. Ensure the file is accessible and properly formatted."}), 400
    else:
        return jsonify({"error": "No file content or path provided. Please provide either file content or a valid file path."}), 400

    if not rows or len(rows) < 1:
        return jsonify({"error": "CSV file has no header. Please ensure the CSV file contains at least one row with headers."}), 400

    header = rows[0]
    if not header:
        return jsonify({"error": "CSV file header is empty. Please ensure the first row contains valid headers."}), 400

    return jsonify({"headers": header}), 200

@query_bp.route('/parse-csv', methods=['POST'])
def parse_csv():
    data = request.get_json()
    file_content = data.get('file_content', '')
    file_path = data.get('file_path', '')
    column_name = data.get('column_name', 'tracking_codes')
    is_excel = data.get('is_excel', False)

    try:
        if file_content:
            df = parse_uploaded_file(file_content=file_content, is_excel=is_excel)
        elif file_path:
            with open(file_path, "rb") as f:
                file_content = base64.b64encode(f.read()).decode("utf-8")
            df = parse_uploaded_file(file_content=file_content, is_excel=is_excel)
        else:
            return jsonify({"error": "No file provided"}), 400

        if column_name not in df.columns:
            return jsonify({"error": f"Cột '{column_name}' không tồn tại trong file."}), 400

        values = df[column_name].dropna().astype(str).tolist()
        codes = []
        for val in values:
            # Thử cắt chuỗi theo dấu phẩy trước
            split_vals = val.split(',')
            if len(split_vals) == 1:  # Nếu không cắt được, thử dấu chấm phẩy
                split_vals = val.split(';')
            codes.extend(v.strip() for v in split_vals if v.strip())
        codes = list(set(codes))  # Loại bỏ trùng lặp

        return jsonify({"tracking_codes": codes}), 200

    except Exception as e:
        return jsonify({"error": f"Failed to parse CSV: {str(e)}. Ensure the file and column name are valid."}), 500

@query_bp.route('/query', methods=['POST'])
def query_events():
    data = request.get_json()
    print(f"Received data: {data}")  # Log dữ liệu nhận được
    search_string = data.get('search_string', '')
    default_days = data.get('default_days', 7)  # Thêm giá trị mặc định 7 nếu không có trong request
    from_time = data.get('from_time')
    to_time = data.get('to_time')
    selected_cameras = data.get('selected_cameras', [])  # Lấy selected_cameras

    # Tách search_string theo dòng và loại bỏ số thứ tự
    tracking_codes = []
    if search_string:
        lines = search_string.splitlines()
        for line in lines:
            line = line.strip()
            if line:
                # Loại bỏ số thứ tự (e.g., "1. " hoặc "2. ")
                code = line.split('. ', 1)[-1].strip()
                if code:
                    tracking_codes.append(code)
    print(f"Parsed tracking_codes from search_string: {tracking_codes}")  # Log tracking_codes đã tách

    try:
        if from_time and to_time:
            try:
                from_timestamp = int(datetime.fromisoformat(from_time.replace('Z', '+00:00')).timestamp() * 1000)
                to_timestamp = int(datetime.fromisoformat(to_time.replace('Z', '+00:00')).timestamp() * 1000)
            except ValueError as e:
                return jsonify({"error": f"Invalid time format for from_time or to_time: {str(e)}. Use ISO format (e.g., 2023-10-01T00:00:00Z)."}), 400
        else:
            to_timestamp = int(datetime.now().timestamp() * 1000)
            from_timestamp = to_timestamp - (default_days * 24 * 60 * 60 * 1000)
        print(f"Time range: from_timestamp={from_timestamp}, to_timestamp={to_timestamp}")  # Log khoảng thời gian

        with db_rwlock.gen_rlock():  # Thêm khóa đọc
            conn = get_db_connection()
            cursor = conn.cursor()

            query = """
                SELECT event_id, ts, te, duration, tracking_codes, video_file, packing_time_start, packing_time_end
                FROM events
                WHERE is_processed = 0
            """
            params = []
            # Chỉ thêm điều kiện thời gian nếu packing_time_start không null
            if from_timestamp and to_timestamp:
                query += " AND (packing_time_start IS NULL OR (packing_time_start >= ? AND packing_time_start <= ?))"
                params.extend([from_timestamp, to_timestamp])
            if selected_cameras:
                query += " AND camera_name IN ({})".format(','.join('?' * len(selected_cameras)))
                params.extend(selected_cameras)

            print(f"Executing query: {query} with params: {params}")  # Log truy vấn
            cursor.execute(query, params)
            events = cursor.fetchall()
            print(f"Fetched events: {events}")  # Log kết quả truy vấn

            filtered_events = []
            for event in events:
                event_dict = {
                    'event_id': event[0],
                    'ts': event[1],
                    'te': event[2],
                    'duration': event[3],
                    'tracking_codes': event[4],
                    'video_file': event[5],
                    'packing_time_start': event[6],
                    'packing_time_end': event[7]
                }
                print(f"Raw tracking_codes for event {event[0]}: {event[4]}")  # Log giá trị thô của tracking_codes
                try:
                    tracking_codes_list = json.loads(event[4]) if event[4] else []
                    if not isinstance(tracking_codes_list, list):
                        raise ValueError("tracking_codes is not a list")
                except Exception:
                    print(f"[WARN] tracking_codes fallback for event {event[0]}")
                    tracking_codes_list = []
                    if event[4]:
                        raw = event[4].strip("[]").replace("'", "").replace('"', "")
                        tracking_codes_list = [code.strip() for code in raw.split(',')]
                print(f"Parsed tracking_codes for event {event[0]}: {tracking_codes_list}")  # Log tracking_codes đã parse
                if not tracking_codes:
                    filtered_events.append(event_dict)
                else:
                    for code in tracking_codes:
                        if code in tracking_codes_list:
                            filtered_events.append(event_dict)
                            break
            print(f"Filtered events: {filtered_events}")  # Log kết quả sau khi lọc

            conn.close()
        return jsonify({'events': filtered_events}), 200
    except Exception as e:
        print(f"Error in query_events: {str(e)}")  # Log lỗi chi tiết
        return jsonify({"error": f"Failed to query events: {str(e)}. Ensure the database is accessible and the events table exists."}), 500
```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/query/__init__.py`

```python

```
## 📄 File: `trigger_processor.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/trigger_processor.py`

```python
import cv2
import logging
import time
import os
from datetime import timedelta
from modules.db_utils import get_db_connection
from modules.scheduler.db_sync import db_rwlock

def run_trigger_logic(
    core_sampler,
    video_capture,
    video_metadata,
    trigger_roi_coords_for_state_check,
    get_log_handle_callback
):
    core_sampler.logger.info(f"TRIGGER_PROCESSOR: Starting for {video_metadata['base_video_name']}")
    frame_idx_counter_tr = 0
    frame_states_buffer_list_tr = []
    mvd_buffer_list_tr = []
    last_recorded_state_tr = None
    last_recorded_mvd_tr = ""
    second = 0
    current_start_second = 0
    current_end_second = core_sampler.log_segment_duration
    log_file = os.path.join(core_sampler.log_dir_output_segments, f"log_{video_metadata['base_video_name']}_{current_start_second:04d}_{current_end_second:04d}.txt")
    log_file_handle = open(log_file, 'w')
    log_file_handle.write(f"# Start: {current_start_second}, End: {current_end_second}, Start_Time: {(video_metadata['start_time_obj'] + timedelta(seconds=current_start_second)).strftime('%Y-%m-%d %H:%M:%S')}, Camera_Name: {video_metadata['camera_name']}, Video_File: {video_metadata['absolute_video_path']}\n")
    log_file_handle.flush()
    with db_rwlock.gen_wlock():
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM processed_logs WHERE log_file = ?", (log_file,))
        log_exists = cursor.fetchone()
        if not log_exists:
            cursor.execute("INSERT INTO processed_logs (log_file, is_processed) VALUES (?, 0)", (log_file,))
        conn.commit()
        conn.close()
    while video_capture.isOpened():
        ret, bgr_frame = video_capture.read()
        if not ret: break
        frame_idx_counter_tr += 1
        if frame_idx_counter_tr % core_sampler.frame_interval != 0: continue
        state_val, mvd_val = core_sampler._internal_process_frame_qr(
            bgr_frame,
            frame_idx_counter_tr,
            trigger_roi_coords_for_state_check=trigger_roi_coords_for_state_check
        )
        frame_states_buffer_list_tr.append(state_val)
        mvd_buffer_list_tr.append(mvd_val)
        second_in_video = (frame_idx_counter_tr - 1) / core_sampler.fps
        second = round(second_in_video)
        if second >= current_end_second:
            log_file_handle.close()
            current_start_second = current_end_second
            current_end_second += core_sampler.log_segment_duration
            log_file = os.path.join(core_sampler.log_dir_output_segments, f"log_{video_metadata['base_video_name']}_{current_start_second:04d}_{current_end_second:04d}.txt")
            log_file_handle = open(log_file, 'w')
            log_file_handle.write(f"# Start: {current_start_second}, End: {current_end_second}, Start_Time: {(video_metadata['start_time_obj'] + timedelta(seconds=current_start_second)).strftime('%Y-%m-%d %H:%M:%S')}, Camera_Name: {video_metadata['camera_name']}, Video_File: {video_metadata['absolute_video_path']}\n")
            log_file_handle.flush()
            with db_rwlock.gen_wlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT 1 FROM processed_logs WHERE log_file = ?", (log_file,))
                log_exists = cursor.fetchone()
                if not log_exists:
                    cursor.execute("INSERT INTO processed_logs (log_file, is_processed) VALUES (?, 0)", (log_file,))
                conn.commit()
                conn.close()
        if len(frame_states_buffer_list_tr) == 5:
            on_count_tr = frame_states_buffer_list_tr.count("On")
            determined_final_state_tr = "On" if on_count_tr >= 3 else "Off"
            determined_final_mvd_tr = mvd_buffer_list_tr[-1] if mvd_buffer_list_tr else ""
            if determined_final_state_tr != last_recorded_state_tr or determined_final_mvd_tr != last_recorded_mvd_tr:
                log_handle_tr = get_log_handle_callback(second_in_video)
                log_handle_tr.write(f"{second},{determined_final_state_tr},{determined_final_mvd_tr}\n")
                log_handle_tr.flush()
                last_recorded_state_tr = determined_final_state_tr
                last_recorded_mvd_tr = determined_final_mvd_tr
            frame_states_buffer_list_tr.clear()
            mvd_buffer_list_tr.clear()
    log_file_handle.close()
    core_sampler.logger.info(f"TRIGGER_PROCESSOR: Finished for {video_metadata['base_video_name']}")
```
## 📄 File: `IdleMonitor.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/IdleMonitor.py`

```python
import cv2
import mediapipe as mp
import queue
import os
import logging
from datetime import datetime
import uuid
from modules.config.logging_config import get_logger

class IdleMonitor:
    def __init__(self, processing_config=None):
        """Khởi tạo IdleMonitor với queue và processing_config."""
        self.video_file = None
        self.logger = get_logger("app", {"video_id": None})
        self.logger.setLevel(logging.INFO)
        self.work_block_queue = queue.Queue()  # Queue lưu work block
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(static_image_mode=False, max_num_hands=1, min_detection_confidence=0.6)
        self.IDLE_GAP = 120  # seconds
        self.HAND_SAMPLE_INTERVAL = 1  # seconds
        self.MIN_WORK_BLOCK = 10  # seconds
        self.MIN_PACKING_TIME = processing_config.get('min_packing_time', 5) if processing_config else 5  # seconds
        self.CHUNK_SIZE = int(self.MIN_PACKING_TIME * 0.8) # seconds
        self.video_id = str(uuid.uuid4())  # Định danh duy nhất cho video

    def process_video(self, video_file, camera_name, packing_area):
        """Xử lý video, xác định work block, lưu vào queue, dùng packing_area từ program_runner."""
        self.video_file = video_file
        self.logger = get_logger("app", {"video_id": os.path.basename(self.video_file)})
        # Đọc video
        cap = cv2.VideoCapture(video_file)
        if not cap.isOpened():
            self.logger.error(f"Failed to open video: {video_file}")
            return

        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        video_duration = int(total_frames / fps)
        self.logger.info(f"Processing video: {video_file}, Duration: {video_duration}s, Video ID: {self.video_id}")

        # Kiểm tra packing_area
        roi = packing_area
        if not roi:
            self.logger.warning(f"No packing_area for {camera_name}, using full frame")
            roi = None

        hand_timeline = []
        event_id = 0

        # Quét video theo chunk
        sec = 0
        while sec < video_duration:
            chunk_end = min(sec + self.CHUNK_SIZE, video_duration)
            chunk_has_hand = False
            check_time = sec
            # Quét đều toàn chunk
            while check_time < chunk_end:
                frame_id = int(check_time * fps)
                cap.set(cv2.CAP_PROP_POS_FRAMES, frame_id)
                ret, frame = cap.read()
                if not ret:
                    break

                # Áp dụng ROI nếu có
                if roi:
                    x, y, w, h = roi
                    frame_height, frame_width = frame.shape[:2]
                    if w > 0 and h > 0 and y + h <= frame_height and x + w <= frame_width:
                        frame = frame[y:y+h, x:x+w]
                    else:
                        self.logger.warning(f"Invalid ROI for frame {frame_id}: {roi}")
                        frame = frame

                # Hand detection
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = self.hands.process(rgb_frame)
                if results.multi_hand_landmarks is not None:
                    chunk_has_hand = True
                    break
                check_time += self.HAND_SAMPLE_INTERVAL

            hand_timeline.append(chunk_has_hand)
            #self.logger.info(f"[Chunk {sec:04d}-{chunk_end:04d}s] Hand: {chunk_has_hand}, Video ID: {self.video_id}")
            sec += self.CHUNK_SIZE

        # Phát hiện idle block
        idle_gap_list = []
        idle_candidate_start = None
        for tick_time, hand_detected in enumerate(hand_timeline):
            if hand_detected:
                if idle_candidate_start is not None:
                    idle_duration = tick_time - idle_candidate_start
                    if idle_duration * self.CHUNK_SIZE >= self.IDLE_GAP:
                        idle_gap_list.append({'start': idle_candidate_start * self.CHUNK_SIZE, 'end': tick_time * self.CHUNK_SIZE})
                    idle_candidate_start = None
            else:
                if idle_candidate_start is None:
                    idle_candidate_start = tick_time

        if idle_candidate_start is not None:
            idle_duration = len(hand_timeline) - idle_candidate_start
            if idle_duration * self.CHUNK_SIZE >= self.IDLE_GAP:
                idle_gap_list.append({'start': idle_candidate_start * self.CHUNK_SIZE, 'end': len(hand_timeline) * self.CHUNK_SIZE})

        # Phát hiện work block
        work_blocks = []
        prev_end = 0
        for idle in idle_gap_list:
            if idle['start'] > prev_end:
                work_blocks.append({'start': prev_end, 'end': idle['start']})
            prev_end = idle['end']
        if prev_end < len(hand_timeline) * self.CHUNK_SIZE:
            work_blocks.append({'start': prev_end, 'end': len(hand_timeline) * self.CHUNK_SIZE})

        # Lưu work block vào queue
        for idx, block in enumerate(work_blocks):
            duration = block['end'] - block['start']
            event_id += 1
            if duration < self.MIN_WORK_BLOCK:
                self.logger.info(f"Skipping work block {idx+1}: duration {duration}s < {self.MIN_WORK_BLOCK}s")
                continue
            self.work_block_queue.put({
                'video_id': self.video_id,
                'event_id': f"evt_{event_id:03d}",
                'file_path': video_file,
                'start_time': block['start'],
                'end_time': block['end']
            })
            self.logger.info(f"Work block {idx+1}: {block['start']}s --> {block['end']}s (duration: {duration}s), Video ID: {self.video_id}")
            if duration < self.MIN_WORK_BLOCK:
                self.logger.warning(f"Block shorter than {self.MIN_WORK_BLOCK}s")

        cap.release()
        self.hands.close()

    def get_work_block_queue(self):
        """Trả về queue chứa work block."""
        return self.work_block_queue
```
## 📄 File: `qr_detector.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/qr_detector.py`

```python
import cv2
import os
import json
import logging
import queue
import threading
import time
import glob
import traceback
from datetime import datetime
from modules.config.logging_config import get_logger


# Đảm bảo thư mục LOG tồn tại
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
LOG_DIR = os.path.join(BASE_DIR, "resources", "output_clips", "LOG")
os.makedirs(LOG_DIR, exist_ok=True)

# Khởi tạo logger mà không sử dụng video_path
logger = get_logger(__name__, {"module": "qr_detector"})
logger.info("Logging initialized")

# Đường dẫn tới mô hình WeChat QRCode (tương đối)
MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "models", "wechat_qr")
DETECT_PROTO = os.path.join(MODEL_DIR, "detect.prototxt")
DETECT_MODEL = os.path.join(MODEL_DIR, "detect.caffemodel")
SR_PROTO = os.path.join(MODEL_DIR, "sr.prototxt")
SR_MODEL = os.path.join(MODEL_DIR, "sr.caffemodel")

# Đường dẫn lưu ảnh
CAMERA_ROI_DIR = os.path.join(BASE_DIR, "resources", "output_clips", "CameraROI")

def select_qr_roi(video_path, camera_id, roi_frame_path, step="mvd"):
    """
    Cho phép người dùng vẽ ROI cho mã QR (1 hoặc 2 vùng cho mvd), sau đó xử lý video.
    Args:
        video_path (str): Đường dẫn đến file video.
        camera_id (str): ID của camera.
        roi_frame_path (str): Đường dẫn đến ảnh tạm cuối cùng từ bước trước (đã có ROI vẽ sẵn).
        step (str): Giai đoạn hiện tại (mvd).
    Returns:
        dict: {'success': bool, 'rois': [{'x': int, 'y': int, 'w': int, 'h': int, 'type': str}, ...], 
               'roi_frame': str, 'qr_detected': bool, 'qr_detected_roi1': bool, 'qr_detected_roi2': bool, 
               'qr_content': str, 'trigger_detected': bool, 'table_type': str}
              hoặc {'success': false, 'error': str}
    """
    try:
        logger.debug(f"[MVD] Bắt đầu select_qr_roi với video_path: {video_path}, camera_id: {camera_id}, roi_frame_path: {roi_frame_path}, step: {step}")

        # Kiểm tra sự tồn tại của các mô hình
        for model_file in [DETECT_PROTO, DETECT_MODEL, SR_PROTO, SR_MODEL]:
            logger.debug(f"[MVD] Kiểm tra file mô hình: {model_file}")
            if not os.path.exists(model_file):
                logger.error(f"[MVD] File mô hình không tìm thấy: {model_file}")
                cv2.destroyAllWindows()
                return {"success": False, "error": f"File mô hình không tìm thấy: {model_file}"}

        # Kiểm tra file ảnh và video
        logger.debug(f"[MVD] Kiểm tra ảnh tạm: {roi_frame_path}")
        if not os.path.exists(roi_frame_path):
            logger.error(f"[MVD] Ảnh tạm không tồn tại: {roi_frame_path}")
            cv2.destroyAllWindows()
            return {"success": False, "error": f"Ảnh tạm không tồn tại: {roi_frame_path}"}
        
        logger.debug(f"[MVD] Kiểm tra video: {video_path}")
        if not os.path.exists(video_path):
            logger.error(f"[MVD] Video không tồn tại: {video_path}")
            cv2.destroyAllWindows()
            return {"success": False, "error": f"Video không tồn tại: {video_path}"}

        # Đọc frame từ ảnh tạm
        try:
            logger.debug(f"[MVD] Đọc ảnh tạm: {roi_frame_path}")
            frame = cv2.imread(roi_frame_path)
            if frame is None:
                logger.error(f"[MVD] Không thể đọc ảnh tạm: {roi_frame_path}")
                cv2.destroyAllWindows()
                return {"success": False, "error": f"Không thể đọc ảnh tạm: {roi_frame_path}"}
            logger.debug(f"[MVD] Kích thước ảnh tạm: {frame.shape[:2]}")
        except Exception as e:
            logger.error(f"[MVD] OpenCV imread error: {str(e)}\n{traceback.format_exc()}")
            cv2.destroyAllWindows()
            return {"success": False, "error": f"OpenCV imread error: {str(e)}"}

        # Chọn loại bàn đóng gói
        table_type = None
        while table_type is None:
            current_frame = frame.copy()
            window_title = "**** Nhan 1 cho ban tieu chuan, 2 cho ban khong tieu chuan, q thoat ****"
            cv2.namedWindow(window_title, cv2.WINDOW_NORMAL)
            cv2.imshow(window_title, current_frame)
            key = cv2.waitKey(0) & 0xFF
            cv2.destroyAllWindows()
            if key == ord('1'):
                table_type = "standard"
                logger.debug("[MVD] Chọn bàn tiêu chuẩn")
            elif key == ord('2'):
                table_type = "non_standard"
                logger.debug("[MVD] Chọn bàn không tiêu chuẩn")
            elif key == ord('q'):
                logger.debug("[MVD] Người dùng thoát")
                cv2.destroyAllWindows()
                return {"success": False, "error": "Người dùng thoát"}
            else:
                logger.debug("[MVD] Phím không hợp lệ, hiển thị lại hướng dẫn")
                continue

        while True:
            # Tạo bản sao mới của frame mỗi lần vẽ lại
            current_frame = frame.copy()
            rois = []

            # Vẽ ROI 1 (mã QR)
            window_title = "**** Keo chuot ve vung ma QR. Enter xac nhan, Esc huy ****"
            try:
                logger.debug("[MVD] Gọi cv2.selectROI cho MVD ROI 1")
                cv2.destroyAllWindows()
                cv2.startWindowThread()
                cv2.namedWindow(window_title, cv2.WINDOW_NORMAL)
                roi1 = cv2.selectROI(window_title, current_frame, showCrosshair=True, fromCenter=False)
                cv2.destroyAllWindows()
                x1, y1, w1, h1 = map(int, roi1)
                if w1 > 0 and h1 > 0:
                    rois.append({"x": x1, "y": y1, "w": w1, "h": h1, "type": "mvd"})
                    cv2.rectangle(current_frame, (x1, y1), (x1 + w1, y1 + h1), (0, 0, 255), 2)  # Màu đỏ cho MVD
                    cv2.putText(current_frame, "ShippingLabel", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                    logger.debug(f"[MVD] Đã chọn MVD ROI 1: x={x1}, y={y1}, w={w1}, h={h1}")
                    cv2.namedWindow("**** Da ve vung ma QR ****", cv2.WINDOW_NORMAL)
                    cv2.imshow("**** Da ve vung ma QR ****", current_frame)
                    cv2.waitKey(500)
                    cv2.destroyAllWindows()
                else:
                    logger.debug("[MVD] ROI 1 không hợp lệ")
                    cv2.namedWindow("**** Loi: ROI khong hop le. Ve lai vung ma QR ****", cv2.WINDOW_NORMAL)
                    cv2.imshow("**** Loi: ROI khong hop le. Ve lai vung ma QR ****", current_frame)
                    cv2.waitKey(2000)
                    cv2.destroyAllWindows()
                    continue

                # Chỉ vẽ ROI 2 (trigger) cho bàn tiêu chuẩn
                if table_type == "standard":
                    window_title = "**** Ve vung ma trigger (QR: TimeGo). Enter xac nhan, Esc huy ****"
                    roi2_label = "Trigger"
                    logger.debug("[MVD] Gọi cv2.selectROI cho ROI 2")
                    cv2.destroyAllWindows()
                    cv2.startWindowThread()
                    cv2.namedWindow(window_title, cv2.WINDOW_NORMAL)
                    roi2 = cv2.selectROI(window_title, current_frame, showCrosshair=True, fromCenter=False)
                    cv2.destroyAllWindows()
                    x2, y2, w2, h2 = map(int, roi2)
                    if w2 > 0 and h2 > 0:
                        roi_type = "trigger"
                        rois.append({"x": x2, "y": y2, "w": w2, "h": h2, "type": roi_type})
                        cv2.rectangle(current_frame, (x2, y2), (x2 + w2, y2 + h2), (0, 0, 255), 2)  # Màu đỏ
                        cv2.putText(current_frame, roi2_label, (x2, y2 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                        logger.debug(f"[MVD] Đã chọn ROI 2: x={x2}, y={y2}, w={w2}, h={h2}, type={roi_type}")
            except Exception as e:
                logger.error(f"[MVD] OpenCV selectROI error: {str(e)}\n{traceback.format_exc()}")
                cv2.destroyAllWindows()
                return {"success": False, "error": f"OpenCV selectROI error: {str(e)}"}

            # Lưu ảnh vào CameraROI nếu có ROI hợp lệ
            if rois:
                roi_frame_path_new = os.path.join(CAMERA_ROI_DIR, f"camera_{camera_id}_roi_MVD.jpg")
                try:
                    logger.debug(f"[MVD] Lưu ảnh với ROI vào: {roi_frame_path_new}")
                    ret = cv2.imwrite(roi_frame_path_new, current_frame)
                    if not ret:
                        logger.error(f"[MVD] Không thể lưu ảnh tại: {roi_frame_path_new}")
                        cv2.destroyAllWindows()
                        return {"success": False, "error": f"Không thể lưu ảnh tại {roi_frame_path_new}"}
                    logger.info(f"[MVD] Đã lưu frame với ROI vào: {roi_frame_path_new}")
                except Exception as e:
                    logger.error(f"[MVD] OpenCV imwrite error: {str(e)}\n{traceback.format_exc()}")
                    cv2.destroyAllWindows()
                    return {"success": False, "error": f"OpenCV imwrite error: {str(e)}"}
                break
            else:
                logger.debug("[MVD] Không chọn được ROI hợp lệ, hiển thị lại ảnh trước đó để vẽ lại.")
                cv2.namedWindow("**** Loi: ROI khong hop le. Ve lai vung ma QR ****", cv2.WINDOW_NORMAL)
                cv2.imshow("**** Loi: ROI khong hop le. Ve lai vung ma QR ****", current_frame)
                cv2.waitKey(2000)
                cv2.destroyAllWindows()
                continue

        # Kiểm tra tính tương thích của ảnh packing với MVD
        logger.debug(f"[MVD] Kiểm tra tính tương thích của ảnh packing với MVD: {roi_frame_path}")

        # Khởi tạo danh sách hàng đợi và cờ thoát
        frame_queues = [queue.Queue(maxsize=50) for _ in range(len(rois))]
        exit_flag = threading.Event()
        qr_detected = False
        qr_detected_roi1 = False
        qr_detected_roi2 = False
        qr_content = ""
        trigger_detected = False

        def process_roi(video_file, roi_index, x, y, w, h, interval=5):
            nonlocal qr_detected, qr_detected_roi1, qr_detected_roi2, qr_content, trigger_detected
            try:
                logger.debug(f"[MVD] Khởi tạo WeChatQRCode cho ROI {roi_index + 1}")
                local_detector = cv2.wechat_qrcode_WeChatQRCode(DETECT_PROTO, DETECT_MODEL, SR_PROTO, SR_MODEL)
                logger.debug(f"[MVD] WeChatQRCode khởi tạo thành công cho ROI {roi_index + 1}")
            except Exception as e:
                logger.error(f"[MVD] OpenCV WeChatQRCode error in ROI {roi_index + 1}: {str(e)}\n{traceback.format_exc()}")
                return

            try:
                logger.debug(f"[MVD] Mở video cho ROI {roi_index + 1}: {video_file}")
                cap = cv2.VideoCapture(video_file)
                if not cap.isOpened():
                    logger.error(f"[MVD] Không thể mở video '{video_file}' cho ROI {roi_index + 1}")
                    return
                logger.debug(f"[MVD] Video mở thành công cho ROI {roi_index + 1}")
            except Exception as e:
                logger.error(f"[MVD] OpenCV VideoCapture error in ROI {roi_index + 1}: {str(e)}\n{traceback.format_exc()}")
                return

            frame_count = 0
            start_time = time.time()

            while not exit_flag.is_set():
                try:
                    ret, frame = cap.read()
                    if not ret:
                        logger.debug(f"[MVD] Kết thúc video '{video_file}' (ROI {roi_index + 1})")
                        break

                    frame_count += 1
                    if frame_count % interval != 0:
                        continue

                    logger.debug(f"[MVD] Xử lý frame {frame_count} cho ROI {roi_index + 1}")
                    roi_frame = frame[y:y+h, x:x+w]
                    if roi_frame.size == 0 or roi_frame.shape[0] == 0 or roi_frame.shape[1] == 0:
                        logger.warning(f"[MVD] ROI {roi_index + 1} không hợp lệ, bỏ qua frame")
                        continue

                    if len(roi_frame.shape) == 2:
                        roi_frame = cv2.cvtColor(roi_frame, cv2.COLOR_GRAY2BGR)

                    logger.debug(f"[MVD] Phát hiện QR trong ROI {roi_index + 1}")
                    texts, points = local_detector.detectAndDecode(roi_frame)
                    if texts:
                        qr_detected = True
                        if roi_index == 0:
                            qr_detected_roi1 = True
                        elif roi_index == 1 and table_type == "standard":
                            qr_detected_roi2 = True
                        qr_content = texts[0]  # Lưu nội dung QR đầu tiên
                        # Kiểm tra trigger cho ROI 2 (bàn tiêu chuẩn)
                        if table_type == "standard" and roi_index == 1 and texts[0].lower() == "timego":
                            trigger_detected = True
                            logger.info(f"[MVD] [ROI {roi_index + 1}] Phát hiện trigger: {texts[0]}")
                        for text, box in zip(texts, points):
                            logger.info(f"[MVD] [ROI {roi_index + 1}] Nội dung mã QR: {text}")
                            # Vẽ khung viền QR
                            for i in range(4):
                                pt1 = tuple(map(int, box[i]))
                                pt2 = tuple(map(int, box[(i + 1) % 4]))
                                cv2.line(roi_frame, pt1, pt2, (0, 255, 0), 2)
                            # Hiển thị nội dung QR dưới khung viền
                            bottom_left = tuple(map(int, box[2]))  # Góc dưới trái
                            cv2.putText(roi_frame, text[:20], (bottom_left[0], bottom_left[1] + 30), 
                                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

                    elapsed_time = time.time() - start_time
                    elapsed_time_text = f"Time: {elapsed_time:.1f}"
                    cv2.putText(roi_frame, elapsed_time_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
                    cv2.putText(roi_frame, "Dang phat hien ma QR. Noi dung hien thi neu tim thay", 
                                (10, roi_frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                    frame_queues[roi_index].put(roi_frame)
                    logger.debug(f"[MVD] Đã đẩy frame cho ROI {roi_index + 1} vào hàng đợi")
                except Exception as e:
                    logger.error(f"[MVD] OpenCV processing error in process_roi (ROI {roi_index + 1}): {str(e)}\n{traceback.format_exc()}")
                    break

            logger.debug(f"[MVD] Giải phóng video capture cho ROI {roi_index + 1}")
            cap.release()

        # Khởi chạy luồng xử lý video cho từng ROI
        threads = []
        for i, roi in enumerate(rois):
            if roi["w"] > 0 and roi["h"] > 0:
                logger.debug(f"[MVD] Khởi chạy thread cho ROI {i + 1}")
                thread = threading.Thread(target=process_roi, args=(video_path, i, roi["x"], roi["y"], roi["w"], roi["h"], 5))
                thread.start()
                threads.append(thread)
                logger.info(f"[MVD] Thread cho ROI {i + 1} đã khởi chạy")
            else:
                logger.warning(f"[MVD] ROI {i + 1} không hợp lệ, bỏ qua")

        # Khởi tạo cửa sổ cho từng ROI
        for i in range(len(frame_queues)):
            try:
                logger.debug(f"[MVD] Khởi tạo cửa sổ cho ROI {i + 1}")
                window_title = f"**** Dang phat hien ma QR. Noi dung hien thi neu tim thay (ROI {i + 1}) ****"
                cv2.namedWindow(window_title, cv2.WINDOW_AUTOSIZE)
                logger.debug(f"[MVD] Cửa sổ cho ROI {i + 1} đã được khởi tạo")
            except Exception as e:
                logger.error(f"[MVD] OpenCV namedWindow error: {str(e)}\n{traceback.format_exc()}")
                cv2.destroyAllWindows()
                return {"success": False, "error": f"OpenCV namedWindow error: {str(e)}"}

        # Hiển thị mỗi ROI trong cửa sổ riêng
        while any(thread.is_alive() for thread in threads) or any(not q.empty() for q in frame_queues):
            for i in range(len(frame_queues)):
                try:
                    frame = frame_queues[i].get(timeout=0.1)
                    window_name = f"**** Dang phat hien ma QR. Noi dung hien thi neu tim thay (ROI {i + 1}) ****"
                    cv2.imshow(window_name, frame)
                    logger.debug(f"[MVD] Hiển thị frame cho {window_name}")
                except queue.Empty:
                    pass
                except Exception as e:
                    logger.error(f"[MVD] OpenCV imshow error in loop: {str(e)}\n{traceback.format_exc()}")
                    cv2.destroyAllWindows()
                    return {"success": False, "error": f"OpenCV imshow error: {str(e)}"}

            try:
                if cv2.waitKey(10) & 0xFF == ord('q'):
                    logger.debug("[MVD] Nhận lệnh thoát từ người dùng")
                    exit_flag.set()
                    break
            except Exception as e:
                logger.error(f"[MVD] OpenCV waitKey error: {str(e)}\n{traceback.format_exc()}")
                cv2.destroyAllWindows()
                return {"success": False, "error": f"OpenCV waitKey error: {str(e)}"}

        logger.debug("[MVD] Đóng tất cả cửa sổ OpenCV")
        cv2.destroyAllWindows()
        for thread in threads:
            logger.debug(f"[MVD] Chờ thread ROI {threads.index(thread) + 1} kết thúc")
            thread.join()

        # Lưu kết quả vào /tmp/qr_roi.json
        result = {
            "success": True,
            "rois": rois,
            "roi_frame": os.path.relpath(roi_frame_path_new, BASE_DIR),
            "qr_detected": qr_detected,
            "qr_detected_roi1": qr_detected_roi1,
            "qr_detected_roi2": qr_detected_roi2 if table_type == "standard" else False,
            "qr_content": qr_content,
            "trigger_detected": trigger_detected,
            "table_type": table_type
        }
        logger.debug(f"[MVD] Lưu kết quả vào /tmp/qr_roi.json: {result}")
        try:
            with open("/tmp/qr_roi.json", "w") as f:
                json.dump(result, f)
            logger.info("[MVD] Đã lưu kết quả vào /tmp/qr_roi.json")
        except Exception as e:
            logger.error(f"[MVD] Lỗi khi lưu /tmp/qr_roi.json: {str(e)}\n{traceback.format_exc()}")
            cv2.destroyAllWindows()
            return {"success": False, "error": f"Lỗi khi lưu /tmp/qr_roi.json: {str(e)}"}

        logger.info(f"[MVD] Hoàn tất select_qr_roi cho camera_id: {camera_id}, step: {step}")
        cv2.destroyAllWindows()
        return result

    except Exception as e:
        logger.error(f"[MVD] Lỗi trong select_qr_roi: {str(e)}\n{traceback.format_exc()}")
        cv2.destroyAllWindows()
        return {"success": False, "error": f"Lỗi hệ thống: {str(e)}"}

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 4:
        logger.error("Usage: python3 qr_detector.py <video_path> <camera_id> <roi_frame_path>")
        sys.exit(1)

    video_path = sys.argv[1]
    camera_id = sys.argv[2]
    roi_frame_path = sys.argv[3]
    try:
        result = select_qr_roi(video_path, camera_id, roi_frame_path, step="mvd")
        if not result["success"]:
            logger.error(result["error"])
    except Exception as e:
        logger.error(f"[MVD] Lỗi khi chạy script: {str(e)}\n{traceback.format_exc()}")
        cv2.destroyAllWindows()

```
## 📄 File: `roi_preview.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/roi_preview.py`

```python
import cv2
import argparse
import os
import logging

def setup_logging():
    log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "resources", "output_clips", "LOG")
    os.makedirs(log_dir, exist_ok=True)
    log_file_path = os.path.join(log_dir, f"roi_preview_{os.getpid()}.log")
    logging.basicConfig(
        filename=log_file_path,
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logging.info(f"ROI Preview started with PID {os.getpid()}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--video', required=True, help='File video .mp4')
    parser.add_argument('--roi', nargs=4, type=int, required=True, help='Tọa độ ROI: x y w h')
    args = parser.parse_args()

    setup_logging()
    x, y, w, h = args.roi
    cap = cv2.VideoCapture(args.video)
    if not cap.isOpened():
        logging.error(f"Cannot open {args.video}")
        return

    win = "ROI Preview"
    cv2.namedWindow(win, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(win, w, h)

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        crop = frame[y:y+h, x:x+w]
        cv2.imshow(win, crop)
        if cv2.waitKey(30) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    logging.info("ROI Preview closed")

if __name__ == "__main__":
    main()
```
## 📄 File: `event_detector.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/event_detector.py`

```python
from flask import Blueprint, jsonify
import os
import sqlite3
import logging
from datetime import datetime
from modules.db_utils import get_db_connection
from modules.scheduler.db_sync import db_rwlock
from modules.config.logging_config import get_logger


# Định nghĩa BASE_DIR
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

event_detector_bp = Blueprint('event_detector', __name__)

def calculate_duration(ts, te):
    if ts is None or te is None:
        return None
    if te < ts:
        return None
    return te - ts

def process_single_log(log_file_path):
    if not os.path.isfile(log_file_path):
        logging.warning(f"Log file not found: {log_file_path}, skipping.")
        return
    # Khởi tạo logger với context log_file
    logger = get_logger(__name__, {"log_file": log_file_path})
    logger.info("Logging initialized for process_single_log")

    try:
        with db_rwlock.gen_wlock():
            conn = get_db_connection()
            cursor = conn.cursor()

            # Kiểm tra trạng thái is_processed của file log
            cursor.execute("SELECT is_processed FROM processed_logs WHERE log_file = ?", (log_file_path,))
            result = cursor.fetchone()
            if result and result[0] == 1:
                logging.info(f"Log file {log_file_path} already processed, skipping")
                conn.close()
                return

            with open(log_file_path, "r") as f:
                header = f.readline().strip()
                logging.info(f"Header: {header}")
                start_time = int(header.split("Start: ")[1].split(",")[0])
                end_time = int(header.split("End: ")[1].split(",")[0])
                start_time_str = header.split("Start_Time: ")[1].split(",")[0].strip()
                camera_name = header.split("Camera_Name: ")[1].split(",")[0].strip()
                video_path = header.split("Video_File: ")[1].split(",")[0].strip()
                start_time_dt = datetime.strptime(start_time_str, "%Y-%m-%d %H:%M:%S")
                logging.info(f"Parsed header - Start: {start_time}, End: {end_time}, Start_Time: {start_time_str}, Camera_Name: {camera_name}, Video_File: {video_path}")

                # Kiểm tra nếu file log rỗng
                first_data_line = f.readline().strip()
                if not first_data_line:
                    logging.info(f"Log file {log_file_path} is empty, skipping")
                    cursor.execute("UPDATE processed_logs SET is_processed = 1, processed_at = ? WHERE log_file = ?", (datetime.now(), log_file_path))
                    conn.commit()
                    conn.close()
                    return

                # Nếu có dữ liệu, quay lại và xử lý
                f.seek(0)
                next(f)
                frame_sampler_data = []
                for line in f:
                    parts = line.strip().split(",")
                    try:
                        second, state = parts[0], parts[1]
                        codes = [parts[2]] if len(parts) > 2 and parts[2] else []
                        frame_sampler_data.append({"second": float(second), "state": state, "tracking_codes": codes})
                    except Exception as e:
                        logging.info(f"Error parsing line '{line.strip()}': {str(e)}")

            # Lấy min_packing_time từ Processing_config
            cursor.execute("SELECT min_packing_time FROM Processing_config LIMIT 1")
            min_packing_time_row = cursor.fetchone()
            min_packing_time = min_packing_time_row[0] if min_packing_time_row else 5
            logging.info(f"Min packing time: {min_packing_time}")

            # Lấy pending_event mới nhất theo ts
            cursor.execute("SELECT event_id, ts, tracking_codes, video_file FROM events WHERE te IS NULL AND camera_name = ? ORDER BY event_id DESC LIMIT 1", (camera_name,))
            pending_event = cursor.fetchone()
            logging.info(f"Pending event: {pending_event}")
            ts = pending_event[1] if pending_event else None
            pending_tracking_codes = eval(pending_event[2]) if pending_event and pending_event[2] else []
            pending_video_file = pending_event[3] if pending_event else None
            event_id = pending_event[0] if pending_event else None
            segments = []
            prev_state = None
            has_pending = ts is not None and ts <= start_time

            for data in frame_sampler_data:
                current_state = data["state"]
                current_second = data["second"]
                current_tracking_codes = data["tracking_codes"]

                if has_pending and ts is not None:
                    if current_state == "On":
                        te = current_second
                        total_duration = calculate_duration(ts, te)
                        
                        # Tách tracking_codes thành các sự kiện liên tiếp
                        all_tracking_codes = list(set(pending_tracking_codes + current_tracking_codes))
                        num_codes = len(all_tracking_codes) if all_tracking_codes else 1
                        duration_per_event = max(round(total_duration / num_codes), min_packing_time)  # Làm tròn và đảm bảo >= min_packing_time
                        total_duration = duration_per_event * num_codes  # Cập nhật total_duration
                        te = ts + total_duration if ts is not None else te
                        logging.info(f"Điều chỉnh pending event: Ts={ts}, Te={te}, Duration mỗi sự kiện thành {duration_per_event}")
                        
                        if pending_video_file == video_path:
                            current_ts = ts
                            for i, code in enumerate(all_tracking_codes):
                                current_te = current_ts + duration_per_event if current_ts is not None else te
                                if i == 0:
                                    # Cập nhật pending event cho mã đầu tiên
                                    segments.append((current_ts, current_te, duration_per_event, [code], video_path, event_id))
                                    logging.info(f"Cập nhật pending event liên tiếp {i+1}/{num_codes}: Ts={current_ts}, Te={current_te}, Duration={duration_per_event}, Tracking_code={code}")
                                else:
                                    # Thêm sự kiện mới cho các mã tiếp theo
                                    segments.append((current_ts, current_te, duration_per_event, [code], video_path, None))
                                    logging.info(f"Thêm sự kiện liên tiếp mới {i+1}/{num_codes}: Ts={current_ts}, Te={current_te}, Duration={duration_per_event}, Tracking_code={code}")
                                current_ts = current_te
                        else:
                            current_ts = None
                            for i, code in enumerate(all_tracking_codes):
                                current_te = te - (num_codes - i - 1) * duration_per_event
                                segments.append((current_ts, current_te, duration_per_event, [code], video_path, None))
                                logging.info(f"Thêm pending event liên tiếp {i+1}/{num_codes}: Ts={current_ts}, Te={current_te}, Duration={duration_per_event}, Tracking_code={code}")
                                current_ts = current_te
                        
                        ts = None
                        has_pending = False
                    elif current_state == "Off":
                        pending_tracking_codes.extend([code for code in current_tracking_codes if code and code not in pending_tracking_codes])
                        # Kiểm tra và xóa sự kiện dở dang nếu không có tracking_codes
                        if not pending_tracking_codes and not current_tracking_codes:
                            cursor.execute("DELETE FROM events WHERE te IS NULL AND event_id = (SELECT MAX(event_id) FROM events WHERE te IS NULL AND camera_name = ?)", (camera_name,))
                            logging.info(f"Xóa sự kiện dở dang cuối cùng của camera {camera_name} do không có tracking_codes")              
                elif not has_pending:
                    if prev_state == "On" and current_state == "Off":
                        ts = current_second
                        pending_tracking_codes = current_tracking_codes[:]
                        logging.info(f"Phát hiện sự kiện Ts tại giây {current_second}")

                    elif prev_state == "Off" and current_state == "On" and ts is not None:
                        te = current_second
                        total_duration = calculate_duration(ts, te)
                        
                        # Tách tracking_codes thành các sự kiện liên tiếp
                        all_tracking_codes = list(set(pending_tracking_codes + current_tracking_codes))  # Loại bỏ trùng lặp
                        num_codes = len(all_tracking_codes) if all_tracking_codes else 1
                        duration_per_event = max(round(total_duration / num_codes), min_packing_time)  # Làm tròn và đảm bảo >= min_packing_time
                        total_duration = duration_per_event * num_codes  # Cập nhật total_duration
                        te = ts + total_duration if ts is not None else te
                        logging.info(f"Điều chỉnh sự kiện: Ts={ts}, Te={te}, Duration mỗi sự kiện thành {duration_per_event}")
                        
                        if all_tracking_codes:
                            current_ts = ts
                            for i, code in enumerate(all_tracking_codes):
                                current_te = current_ts + duration_per_event if current_ts is not None else te
                                segments.append((current_ts, current_te, duration_per_event, [code], video_path, None))
                                logging.info(f"Thêm sự kiện liên tiếp {i+1}/{num_codes}: Ts={current_ts}, Te={current_te}, Duration={duration_per_event}, Tracking_code={code}")
                                current_ts = current_te
                        else:
                            segments.append((ts, te, duration_per_event, [], video_path, None))
                            logging.info(f"Thêm sự kiện không có tracking_code: Ts={ts}, Te={te}, Duration={duration_per_event}")
                        
                        ts = None
                        pending_tracking_codes = []

                    elif ts is not None and current_state == "Off":
                        pending_tracking_codes.extend([code for code in current_tracking_codes if code and code not in pending_tracking_codes])

                prev_state = current_state

            if ts is not None:
                segments.append((ts, None, None, pending_tracking_codes, video_path, None))
                logging.info(f"Giây {frame_sampler_data[-1]['second']}: Ts={ts}, Te=Not finished")

            logging.info(f"All segments detected: {segments}")

            for segment in segments:
                ts, te, duration, tracking_codes, segment_video_path, segment_event_id = segment
                if te is not None and not tracking_codes:
                    logging.info(f"Bỏ qua sự kiện hoàn chỉnh do tracking_codes rỗng: ts={ts}, te={te}")
                    continue
                packing_time_start = int((start_time_dt.timestamp() + ts) * 1000) if ts is not None else None
                packing_time_end = int((start_time_dt.timestamp() + te) * 1000) if te is not None else None
                if segment_event_id is not None:
                    cursor.execute("UPDATE events SET te=?, duration=?, tracking_codes=?, packing_time_end=? WHERE event_id=?",
                                   (te, duration, str(tracking_codes), packing_time_end, segment_event_id))
                    logging.info(f"Updated event_id {segment_event_id}: ts={ts}, te={te}, duration={duration}")
                else:
                    cursor.execute('''INSERT INTO events (ts, te, duration, tracking_codes, video_file, buffer, camera_name, packing_time_start, packing_time_end)
                                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                                   (ts, te, duration, str(tracking_codes), segment_video_path, 0, camera_name, packing_time_start, packing_time_end))
                    logging.info(f"Inserted new event: ts={ts}, te={te}, duration={duration}")

            cursor.execute("UPDATE processed_logs SET is_processed = 1, processed_at = ? WHERE log_file = ?", (datetime.now(), log_file_path))
            conn.commit()
            logging.info("Database changes committed")

    except Exception as e:
        logging.error(f"Error in process_single_log: {str(e)}")
        raise
    finally:
        conn.close()

@event_detector_bp.route('/process-events', methods=['GET'])
def process_events():
    try:
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT DISTINCT log_file_path, (
                    SELECT CAST(SUBSTR(header, INSTR(header, 'Start: ') + 7, INSTR(SUBSTR(header, INSTR(header, 'Start: ') + 7), ',') - 1) AS INTEGER)
                    FROM (
                        SELECT SUBSTR(CAST(READFILE(log_file_path) AS TEXT), 1, INSTR(CAST(READFILE(log_file_path) AS TEXT), '\n') - 1) AS header
                    )
                ) AS start_time
                FROM file_list 
                WHERE is_processed = 1 AND log_file_path IS NOT NULL 
                AND log_file_path IN (SELECT log_file FROM processed_logs WHERE is_processed = 0)
                ORDER BY start_time
            """)
            log_files = [row[0] for row in cursor.fetchall()]
            logging.info(f"Log files to process: {log_files}")
            conn.close()

        for log_file in log_files:
            if not os.path.isfile(log_file):
                logging.warning(f"Log file not found, skipping: {log_file}")
                continue
            if os.path.exists(log_file):
                logging.info(f"Starting to process file: {log_file}")
                process_single_log(log_file)
                logging.info(f"Finished processing file: {log_file}")
            else:
                logging.info(f"File not found: {log_file}")

        return jsonify({"message": "Event detection completed successfully"}), 200
    except Exception as e:
        logging.error(f"Error in process_events: {str(e)}")
        return jsonify({"error": str(e)}), 500

```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/__init__.py`

```python

```
## 📄 File: `hand_detection.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/hand_detection.py`

```python
import cv2
import mediapipe as mp
import time
import logging
import json
import os
import glob
from datetime import datetime
from modules.config.logging_config import get_logger


# Định nghĩa BASE_DIR
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Khởi tạo logger mà không sử dụng video_path
logger = get_logger(__name__, {"module": "hand_detection"})
logger.info("Logging initialized")

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

# Đặt bước nhảy frame
FRAME_STEP = 5

# Đường dẫn lưu ảnh
CAMERA_ROI_DIR = os.path.join(BASE_DIR, "resources", "output_clips", "CameraROI")

def ensure_directory_exists(directory):
    """Đảm bảo thư mục tồn tại, nếu không thì tạo mới."""
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
            logging.debug(f"Đã tạo thư mục: {directory}")
        # Kiểm tra quyền truy cập
        if not os.access(directory, os.W_OK):
            logging.error(f"Không có quyền ghi vào thư mục {directory}")
            raise PermissionError(f"Không có quyền ghi vào thư mục {directory}")
    except Exception as e:
        logging.error(f"Lỗi khi tạo thư mục {directory}: {str(e)}")
        raise

def select_roi(video_path, camera_id, step="packing"):
    """
    Mở video và cho phép người dùng vẽ ROI bằng OpenCV, lưu kết quả vào CameraROI, sau đó phát hiện tay.
    Args:
        video_path (str): Đường dẫn đến file video.
        camera_id (str): ID của camera.
        step (str): Giai đoạn hiện tại (packing, trigger).
    Returns:
        dict: {'success': bool, 'roi': {'x': int, 'y': int, 'w': int, 'h': int}, 'roi_frame': str, 'hand_detected': bool} hoặc {'success': false, 'error': str}
    """
    try:
        logging.debug(f"Bắt đầu select_roi với video_path: {video_path}, camera_id: {camera_id}, step: {step}")
        
        # Đảm bảo thư mục CameraROI tồn tại
        ensure_directory_exists(CAMERA_ROI_DIR)

        # Mở video
        logging.debug("Đang mở video...")
        cap = cv2.VideoCapture(video_path)
        try:
            if not cap.isOpened():
                logging.error("Không thể mở video.")
                return {"success": False, "error": "Không thể mở video."}
            
            # Đọc frame đầu tiên
            logging.debug("Đang đọc frame đầu tiên...")
            ret, frame = cap.read()
            if not ret:
                logging.error("Không thể đọc frame từ video.")
                return {"success": False, "error": "Không thể đọc frame từ video."}
            
            # Lưu frame gốc nếu ở bước packing
            if step == "packing":
                original_frame_path = os.path.join(CAMERA_ROI_DIR, f"camera_{camera_id}_original.jpg")
                ret = cv2.imwrite(original_frame_path, frame)
                if not ret:
                    logging.error(f"Không thể lưu ảnh gốc tại: {original_frame_path}")
                    return {"success": False, "error": f"Không thể lưu ảnh gốc tại {original_frame_path}"}
                logging.debug(f"Đã lưu frame gốc vào: {original_frame_path}")
            
            while True:
                # Hiển thị giao diện chọn ROI
                logging.debug("Gọi cv2.selectROI...")
                current_frame = frame.copy()
                roi = cv2.selectROI(f"Click va keo chuot de chon -Vung {step.capitalize()}-", current_frame, showCrosshair=True, fromCenter=False)
                logging.debug(f"ROI trả về: {roi}")
                cv2.destroyAllWindows()
                
                # Kiểm tra nếu ROI hợp lệ
                x, y, w, h = map(int, roi)
                if w == 0 or h == 0:
                    logging.debug("ROI không hợp lệ, hiển thị lại frame gốc để vẽ lại.")
                    continue  # Hiển thị lại frame gốc, không lưu file
                
                # Vẽ ROI lên frame
                color = (0, 255, 0) if step == "packing" else (0, 255, 255)
                cv2.rectangle(current_frame, (x, y), (x + w, y + h), color, 2)
                # Thêm tiêu đề "Packing" nếu ở bước packing
                if step == "packing":
                    cv2.putText(current_frame, "Packing", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                
                # Hiển thị frame với ROI và tiêu đề
                cv2.namedWindow("**** Da ve vung Packing ****", cv2.WINDOW_NORMAL)
                cv2.imshow("**** Da ve vung Packing ****", current_frame)
                cv2.waitKey(500)
                cv2.destroyAllWindows()
                
                # Lưu frame với ROI vào CameraROI
                if step == "packing":
                    roi_frame_path = os.path.join(CAMERA_ROI_DIR, f"camera_{camera_id}_roi_packing.jpg")
                else:  # step == "trigger"
                    roi_frame_path = os.path.join(CAMERA_ROI_DIR, f"camera_{camera_id}_roi_trigger.jpg")
                
                ret = cv2.imwrite(roi_frame_path, current_frame)
                if not ret:
                    logging.error(f"Không thể lưu ảnh tại: {roi_frame_path}")
                    return {"success": False, "error": f"Không thể lưu ảnh tại {roi_frame_path}"}
                logging.debug(f"Đã lưu frame với ROI vào: {roi_frame_path}")
                
                # Kiểm tra file đã được lưu thành công
                if not os.path.exists(roi_frame_path):
                    logging.error(f"File không tồn tại sau khi lưu: {roi_frame_path}")
                    return {"success": False, "error": f"File không tồn tại sau khi lưu: {roi_frame_path}"}
                
                # Nếu là bước packing, gọi detect_hands để kiểm tra tay
                hand_detected = False
                if step == "packing":
                    detect_result = detect_hands(video_path, {"x": x, "y": y, "w": w, "h": h})
                    if not detect_result["success"]:
                        logging.error(f"Lỗi khi phát hiện tay: {detect_result['error']}")
                        return {"success": False, "error": detect_result["error"]}
                    hand_detected = detect_result["hand_detected"]
                
                # Lưu tọa độ ROI và trạng thái hand_detected vào /tmp/roi.json
                result = {
                    "success": True,
                    "roi": {"x": x, "y": y, "w": w, "h": h},
                    "roi_frame": os.path.relpath(roi_frame_path, BASE_DIR),
                    "hand_detected": hand_detected
                }
                logging.debug(f"Lưu ROI vào /tmp/roi.json: {result}")
                with open("/tmp/roi.json", "w") as f:
                    json.dump(result, f)
                
                logging.debug(f"ROI hợp lệ: x={x}, y={y}, w={w}, h={h}, hand_detected: {hand_detected}")
                return result
            
        finally:
            cap.release()
            logging.debug("Đã giải phóng tài nguyên video (cap.release).")
        
    except Exception as e:
        logging.error(f"Lỗi trong select_roi: {str(e)}")
        cv2.destroyAllWindows()
        return {"success": False, "error": f"Lỗi hệ thống: {str(e)}"}

def detect_hands(video_path, roi):
    """
    Hiển thị video với phát hiện tay trong vùng ROI, trả về trạng thái phát hiện tay.
    Args:
        video_path (str): Đường dẫn đến file video.
        roi (dict): Tọa độ ROI {'x': int, 'y': int, 'w': int, 'h': int}.
    Returns:
        dict: {'success': bool, 'hand_detected': bool, 'error': str nếu có lỗi}
    """
    try:
        x, y, w, h = roi["x"], roi["y"], roi["w"], roi["h"]
        if w <= 0 or h <= 0:
            logging.error("ROI không hợp lệ (chiều rộng hoặc chiều cao bằng 0).")
            return {"success": False, "hand_detected": False, "error": "ROI không hợp lệ."}

        # Mở video
        logging.debug("Đang mở video để phát hiện tay...")
        cap = cv2.VideoCapture(video_path)
        try:
            if not cap.isOpened():
                logging.error("Không thể mở video.")
                return {"success": False, "hand_detected": False, "error": "Không thể mở video."}

            hands = mp_hands.Hands(static_image_mode=False, max_num_hands=2, min_detection_confidence=0.5)
            frame_count = 0
            start_time = time.time()
            hand_detected = False

            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    break

                # Cắt video theo ROI
                roi_frame = frame[y:y+h, x:x+w]

                # Chỉ xử lý mỗi FRAME_STEP frame
                if frame_count % FRAME_STEP == 0:
                    # Chuyển đổi BGR sang RGB
                    rgb_frame = cv2.cvtColor(roi_frame, cv2.COLOR_BGR2RGB)

                    # Phát hiện bàn tay
                    results = hands.process(rgb_frame)

                    # Kiểm tra và xác nhận phát hiện tay
                    if results.multi_hand_landmarks:
                        hand_detected = True
                        for hand_landmarks in results.multi_hand_landmarks:
                            # Vẽ keypoints ngay khi phát hiện tay
                            mp_drawing.draw_landmarks(roi_frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                # Hiển thị video
                elapsed_time = time.time() - start_time
                cv2.putText(roi_frame, f"Time: {elapsed_time:.2f}s", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                cv2.imshow("ROI Hand Detection", roi_frame)

                if cv2.waitKey(1) == ord("q"):
                    break

                frame_count += 1

            logging.debug(f"Phát hiện tay: {hand_detected}")
            return {"success": True, "hand_detected": hand_detected}
        
        finally:
            cap.release()
            cv2.destroyWindow("ROI Hand Detection")  # Chỉ đóng cửa sổ của detect_hands
            logging.debug("Đã giải phóng tài nguyên video (cap.release) trong detect_hands.")
    
    except Exception as e:
        logging.error(f"Lỗi trong detect_hands: {str(e)}")
        return {"success": False, "hand_detected": False, "error": f"Lỗi hệ thống: {str(e)}"}

def finalize_roi(video_path, camera_id, rois):
    """
    Vẽ tất cả các vùng ROI (packing, MVD, trigger) lên frame và lưu vào thư mục CameraROI.
    Args:
        video_path (str): Đường dẫn đến file video.
        camera_id (str): ID của camera.
        rois (list): Danh sách các vùng ROI [{'type': str, 'x': int, 'y': int, 'w': int, 'h': int}, ...].
    Returns:
        dict: {'success': bool, 'final_roi_frame': str, 'error': str nếu có lỗi}
    """
    try:
        # Đảm bảo thư mục CameraROI tồn tại
        ensure_directory_exists(CAMERA_ROI_DIR)

        # Mở video và lấy frame đầu tiên
        logging.debug("Đang mở video để tạo ảnh tổng hợp...")
        cap = cv2.VideoCapture(video_path)
        try:
            if not cap.isOpened():
                logging.error("Không thể mở video.")
                return {"success": False, "error": "Không thể mở video."}

            ret, frame = cap.read()
            if not ret:
                logging.error("Không thể đọc frame từ video.")
                return {"success": False, "error": "Không thể đọc frame từ video."}

            # Vẽ các vùng ROI với màu sắc khác nhau
            for roi in rois:
                x, y, w, h = roi["x"], roi["y"], roi["w"], roi["h"]
                roi_type = roi["type"]

                # Định nghĩa màu sắc cho từng loại ROI
                if roi_type == "packing":
                    color = (0, 255, 0)  # Xanh lá
                elif roi_type == "mvd":
                    color = (0, 0, 255)  # Đỏ
                elif roi_type == "trigger":
                    color = (0, 255, 255)  # Vàng
                else:
                    color = (255, 255, 255)  # Trắng (mặc định)

                # Vẽ ROI lên frame
                cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
                # Thêm nhãn cho vùng ROI
                cv2.putText(frame, roi_type.upper(), (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)

            # Tạo tên file với timestamp và camera_id
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            final_roi_frame_path = os.path.join(CAMERA_ROI_DIR, f"camera_{camera_id}_roi_final_{timestamp}.jpg")

            # Lưu ảnh tổng hợp
            ret = cv2.imwrite(final_roi_frame_path, frame)
            if not ret:
                logging.error(f"Không thể lưu ảnh tổng hợp tại: {final_roi_frame_path}")
                return {"success": False, "error": f"Không thể lưu ảnh tổng hợp tại {final_roi_frame_path}"}
            logging.debug(f"Đã lưu ảnh tổng hợp với tất cả ROI vào: {final_roi_frame_path}")

            return {"success": True, "final_roi_frame": os.path.relpath(final_roi_frame_path, BASE_DIR)}
        
        finally:
            cap.release()
            logging.debug("Đã giải phóng tài nguyên video (cap.release) trong finalize_roi.")
    
    except Exception as e:
        logging.error(f"Lỗi trong finalize_roi: {str(e)}")
        return {"success": False, "error": f"Lỗi hệ thống: {str(e)}"}

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: python3 hand_detection.py <video_path> <camera_id>")
        sys.exit(1)
    
    video_path = sys.argv[1]
    camera_id = sys.argv[2]
    try:
        roi_result = select_roi(video_path, camera_id)
        if not roi_result["success"]:
            print(roi_result["error"])
    except Exception as e:
        logging.error(f"Lỗi khi chạy script: {str(e)}")
        print(f"Lỗi khi chạy script: {str(e)}")

```
## 📄 File: `frame_sampler_no_trigger.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/frame_sampler_no_trigger.py`

```python
import cv2
import os
import logging
import sqlite3
import threading
import subprocess
import json
import queue
import numpy as np
import mediapipe as mp
from datetime import datetime, timezone, timedelta
from modules.db_utils import get_db_connection
from modules.scheduler.db_sync import frame_sampler_event, db_rwlock
import math
from modules.config.logging_config import get_logger


BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "models", "wechat_qr")
DETECT_PROTO = os.path.join(MODEL_DIR, "detect.prototxt")
DETECT_MODEL = os.path.join(MODEL_DIR, "detect.caffemodel")
SR_PROTO = os.path.join(MODEL_DIR, "sr.prototxt")
SR_MODEL = os.path.join(MODEL_DIR, "sr.caffemodel")

class FrameSamplerNoTrigger:
    def __init__(self):
        self.setup_logging()
        self.load_config()
        self.video_lock = threading.Lock()
        self.setup_wechat_qr()
        # Initialize MediaPipe Hands
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(static_image_mode=False, max_num_hands=2, min_detection_confidence=0.5)
        # Initialize log queue and writer thread
        self.log_queue = queue.Queue()
        self.log_thread = threading.Thread(target=self._log_writer)
        self.log_thread.daemon = True
        self.log_thread.start()

    def setup_logging(self):
        self.logger = get_logger(__name__, {"video_id": os.path.basename(self.video_file)})
        self.logger.info("Logging initialized")

    def setup_wechat_qr(self):
        for model_file in [DETECT_PROTO, DETECT_MODEL, SR_PROTO, SR_MODEL]:
            if not os.path.exists(model_file):
                logging.error(f"Model file not found: {model_file}")
                raise FileNotFoundError(f"Model file not found: {model_file}")
        try:
            self.qr_detector = cv2.wechat_qrcode_WeChatQRCode(DETECT_PROTO, DETECT_MODEL, SR_PROTO, SR_MODEL)
            logging.info("WeChat QRCode detector initialized")
        except Exception as e:
            logging.error(f"Failed to initialize WeChat QRCode: {str(e)}")
            raise

    def load_config(self):
        logging.info("Loading configuration from database")
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT input_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            self.video_root = result[0] if result else os.path.join(BASE_DIR, "Inputvideo")
            cursor.execute("SELECT output_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            self.output_path = result[0] if result else os.path.join(BASE_DIR, "output_clips")
            self.log_dir = os.path.join(self.output_path, "LOG", "Frame")
            os.makedirs(self.log_dir, exist_ok=True)
            cursor.execute("SELECT timezone FROM general_info WHERE id = 1")
            result = cursor.fetchone()
            tz_hours = int(result[0].split("+")[1]) if result and "+" in result[0] else 7
            self.video_timezone = timezone(timedelta(hours=tz_hours))
            cursor.execute("SELECT frame_rate, frame_interval, min_packing_time, motion_threshold, stable_duration_sec FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            self.fps, self.frame_interval, self.min_packing_time, self.motion_threshold, self.stable_duration_sec = result if result else (30, 5, 3, 0.1, 1.0)
            conn.close()
            logging.info(f"Config loaded: video_root={self.video_root}, output_path={self.output_path}, timezone={self.video_timezone}, fps={self.fps}, frame_interval={self.frame_interval}, min_packing_time={self.min_packing_time}, motion_threshold={self.motion_threshold}, stable_duration_sec={self.stable_duration_sec}")

    def get_packing_area(self, camera_name):
        logging.info(f"Querying qr_mvd_area for camera {camera_name}")
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT qr_mvd_area FROM packing_profiles WHERE profile_name = ?", (camera_name,))
            result = cursor.fetchone()
            conn.close()
        if result and result[0]:
            try:
                qr_mvd_area = result[0]
                if qr_mvd_area.startswith('(') and qr_mvd_area.endswith(')'):
                    x, y, w, h = map(int, qr_mvd_area.strip('()').split(','))
                else:
                    parsed = json.loads(qr_mvd_area)
                    if isinstance(parsed, list) and len(parsed) == 4:
                        x, y, w, h = parsed
                    else:
                        x, y, w, h = parsed['x'], parsed['y'], parsed['w'], parsed['h']
                roi = (x, y, w, h)
                logging.info(f"Using qr_mvd_area: {roi}")
            except (ValueError, json.JSONDecodeError, KeyError, TypeError) as e:
                logging.error(f"Error parsing qr_mvd_area for camera {camera_name}: {str(e)}")
                roi = None
        else:
            logging.warning(f"No qr_mvd_area found for camera {camera_name}")
            roi = None
        return roi

    def get_video_duration(self, video_file):
        try:
            cmd = ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", video_file]
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            return float(result.stdout.strip())
        except Exception:
            logging.error(f"Failed to get duration of video {video_file}")
            return None

    def load_video_files(self):
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT file_path FROM file_list WHERE is_processed = 0 AND status != 'xong' ORDER BY priority DESC, created_at ASC")
            video_files = [row[0] for row in cursor.fetchall()]
            conn.close()
        if not video_files:
            logging.info("No video files found with is_processed = 0 and status != 'xong'.")
        return video_files

    def process_frame(self, frame, frame_count):
        try:
            if len(frame.shape) == 2:
                frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
            texts, _ = self.qr_detector.detectAndDecode(frame)
            for text in texts:
                if text and text != "TimeGo":
                    logging.info(f"Second {round((frame_count - 1) / self.fps)}: QR texts={texts}, mvd={text}")
                    return text
            return ""
        except Exception as e:
            logging.error(f"Error processing frame {frame_count}: {str(e)}")
            return ""

    def detect_hand(self, frame):
        try:
            # Convert BGR to RGB
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            # Process frame with MediaPipe Hands
            results = self.hands.process(rgb_frame)
            # Return True if hand landmarks are detected
            return bool(results.multi_hand_landmarks)
        except Exception as e:
            logging.error(f"Error in hand detection: {str(e)}")
            return False

    def compute_motion_level(self, prev_frame, curr_frame):
        try:
            if len(prev_frame.shape) == 3:
                prev_frame = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
            if len(curr_frame.shape) == 3:
                curr_frame = cv2.cvtColor(curr_frame, cv2.COLOR_BGR2GRAY)
            diff = cv2.absdiff(prev_frame, curr_frame)
            motion_level = np.mean(diff) / 255.0
            return motion_level
        except Exception as e:
            logging.error(f"Error computing motion level: {str(e)}")
            return 1.0

    def _get_video_start_time(self, video_file):
        try:
            result = subprocess.check_output(['ffprobe', '-v', 'quiet', '-show_entries', 'format_tags=creation_time', '-of', 'default=noprint_wrappers=1:nokey=1', video_file])
            return datetime.strptime(result.decode().strip(), '%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=timezone.utc).astimezone(self.video_timezone)
        except (subprocess.CalledProcessError, ValueError):
            try:
                result = subprocess.check_output(['exiftool', '-CreateDate', '-d', '%Y-%m-%d %H:%M:%S', video_file])
                return datetime.strptime(result.decode().split('CreateDate')[1].strip().split('\n')[0].strip(), '%Y-%m-%d %H:%M:%S').replace(tzinfo=self.video_timezone)
            except (subprocess.CalledProcessError, IndexError):
                try:
                    result = subprocess.check_output(['exiftool', '-FileCreateDate', '-d', '%Y-%m-%d %H:%M:%S', video_file])
                    return datetime.strptime(result.decode().split('FileCreateDate')[1].strip().split('\n')[0].strip(), '%Y-%m-%d %H:%M:%S').replace(tzinfo=self.video_timezone)
                except (subprocess.CalledProcessError, IndexError):
                    logging.warning("No metadata found, using file creation time.")
                    return datetime.fromtimestamp(os.path.getctime(video_file), tz=self.video_timezone)

    def _log_writer(self):
        while True:
            log_file, entry, timestamp = self.log_queue.get()
            with threading.Lock():
                mode = 'w' if not os.path.exists(log_file) else 'a'
                with open(log_file, mode) as f:
                    if mode == 'w':
                        f.write(f"# Start: {timestamp['start']}, End: {timestamp['end']}, Start_Time: {timestamp['start_time']}, Camera_Name: {timestamp['camera']}, Video_File: {timestamp['video']}\n")
                    f.write(f"{entry}\n")
                    f.flush()
            self.log_queue.task_done()

    def _update_log_file(self, log_file, start_second, end_second, start_time, camera_name, video_file):
        timestamp = {
            'start': start_second,
            'end': end_second,
            'start_time': start_time.strftime('%Y-%m-%d %H:%M:%S'),
            'camera': camera_name,
            'video': video_file
        }
        with db_rwlock.gen_wlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM processed_logs WHERE log_file = ?", (log_file,))
            if not cursor.fetchone():
                cursor.execute("INSERT INTO processed_logs (log_file, is_processed) VALUES (?, 0)", (log_file,))
            conn.commit()
            conn.close()
        return lambda entry, ts: self.log_queue.put((log_file, f"{ts},{entry}", timestamp))

    def run(self):
        while True:
            frame_sampler_event.wait()
            video_files = self.load_video_files()
            if not video_files:
                logging.info("No videos to process")
                frame_sampler_event.clear()
                continue
            for video_file in video_files:
                log_file = self.process_video(video_file, self.video_lock, self.get_packing_area, self.process_frame, self.frame_interval)
                if log_file:
                    logging.info(f"Completed processing video {video_file}, log at {log_file}")
                else:
                    logging.error(f"Failed to process video {video_file}")
            frame_sampler_event.clear()

    def process_video(self, video_file, video_lock, get_packing_area_func, process_frame_func, frame_interval, start_time=0, end_time=None):
        with video_lock:
            logging.info(f"Processing video: {video_file} from {start_time}s to {end_time}s")
            if not os.path.exists(video_file):
                logging.error(f"File '{video_file}' does not exist")
                with db_rwlock.gen_wlock():
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("lỗi", video_file))
                    conn.commit()
                    conn.close()
                return None
            with db_rwlock.gen_wlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("đang frame sampler ...", video_file))
                cursor.execute("SELECT camera_name FROM file_list WHERE file_path = ?", (video_file,))
                result = cursor.fetchone()
                camera_name = result[0] if result and result[0] else "CamTest"
                conn.commit()
                conn.close()
            video = cv2.VideoCapture(video_file)
            if not video.isOpened():
                logging.error(f"Failed to open video '{video_file}'")
                with db_rwlock.gen_wlock():
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("lỗi", video_file))
                    conn.commit()
                    conn.close()
                return None
            start_time_obj = self._get_video_start_time(video_file)
            roi = get_packing_area_func(camera_name)
            total_seconds = self.get_video_duration(video_file)
            if total_seconds is None:
                logging.error(f"Failed to get duration of video {video_file}")
                with db_rwlock.gen_wlock():
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("lỗi", video_file))
                    conn.commit()
                    conn.close()
                return None
            logging.info(f"Video duration {video_file}: {total_seconds} seconds")
            video_name = os.path.splitext(os.path.basename(video_file))[0]
            segment_duration = 300
            # Xác định các đoạn 300s chứa [start_time, end_time]
            end_time = total_seconds if end_time is None else min(end_time, total_seconds)
            start_segment = math.floor(start_time / segment_duration) * segment_duration
            end_segment = math.ceil(end_time / segment_duration) * segment_duration
            current_start_second = start_segment
            current_end_second = min(current_start_second + segment_duration, end_segment)
            camera_log_dir = os.path.join(self.log_dir, camera_name)
            os.makedirs(camera_log_dir, exist_ok=True)
            log_file = os.path.join(camera_log_dir, f"log_{video_name}_{current_start_second:04d}_{current_end_second:04d}.txt")
            log_file_handle = self._update_log_file(log_file, current_start_second, current_end_second, start_time_obj + timedelta(seconds=current_start_second), camera_name, video_file)
            # Bắt đầu từ khung hình tại start_time
            start_frame = int(start_time * self.fps)
            end_frame = int(end_time * self.fps)
            video.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
            frame_count = start_frame
            prev_frame = None
            stable_segments = []
            qr_events = []
            stable_start = None
            last_te = -self.min_packing_time * self.fps
            is_stable = False
            while video.isOpened() and frame_count < end_frame:
                ret, frame = video.read()
                if not ret:
                    break
                if roi:
                    x, y, w, h = roi
                    frame_height, frame_width = frame.shape[:2]
                    if w > 0 and h > 0 and y + h <= frame_height and x + w <= frame_width:
                        frame = frame[y:y + h, x:x + w]
                    else:
                        logging.warning(f"Invalid ROI for frame {frame_count}: {roi}, frame_size: {frame_width}x{frame_height}")
                        frame = frame
                frame_count += 1
                if frame_count % frame_interval != 0:
                    continue
                if frame.size == 0 or frame.shape[0] == 0 or frame.shape[1] == 0:
                    logging.warning(f"Empty frame {frame_count}, skipping")
                    continue
                # QR detection
                mvd = process_frame_func(frame, frame_count)
                if mvd:
                    qr_events.append((frame_count, mvd))
                # Motion detection
                if prev_frame is not None:
                    motion_level = self.compute_motion_level(prev_frame, frame)
                    min_stable_frames = max(6, int(self.fps * self.stable_duration_sec / self.frame_interval))
                    if motion_level < self.motion_threshold:
                        if not is_stable:
                            stable_start = frame_count
                            is_stable = True
                    else:
                        if is_stable and (frame_count - stable_start) >= min_stable_frames * frame_interval:
                            start_second = round((stable_start - 1) / self.fps, 1)
                            end_second = round((frame_count - frame_interval - 1) / self.fps, 1)
                            if start_second >= start_time and end_second <= end_time:
                                stable_segments.append((stable_start, frame_count - frame_interval))
                                logging.info(f"Stable segment: start={start_second}s, end={end_second}s")
                        is_stable = False
                prev_frame = frame.copy()
                second_in_video = (frame_count - 1) / self.fps
                second = round(second_in_video)
                if second >= current_end_second and second < end_time:
                    current_start_second = current_end_second
                    current_end_second = min(current_start_second + segment_duration, end_segment)
                    camera_log_dir = os.path.join(self.log_dir, camera_name)
                    os.makedirs(camera_log_dir, exist_ok=True)
                    log_file = os.path.join(camera_log_dir, f"log_{video_name}_{current_start_second:04d}_{current_end_second:04d}.txt")
                    log_file_handle = self._update_log_file(log_file, current_start_second, current_end_second, start_time_obj + timedelta(seconds=current_start_second), camera_name, video_file)
            if is_stable and (frame_count - stable_start) >= min_stable_frames * frame_interval:
                start_second = round((stable_start - 1) / self.fps, 1)
                end_second = round((frame_count - 1) / self.fps, 1)
                if start_second >= start_time and end_second <= end_time:
                    stable_segments.append((stable_start, frame_count))
                    logging.info(f"Stable segment: start={start_second}s, end={end_second}s")
            # Group QR codes and select the last frame of each sequence
            grouped_qr = []
            current_mvd = None
            current_frames = []
            for frame, mvd in qr_events:
                if mvd == "TimeGo":
                    continue
                if mvd != current_mvd:
                    if current_mvd and current_frames:
                        grouped_qr.append((current_frames[-1], current_mvd))
                    current_mvd = mvd
                    current_frames = [frame]
                else:
                    current_frames.append(frame)
            if current_mvd and current_frames:
                grouped_qr.append((current_frames[-1], current_mvd))
            # Log last QR event
            if grouped_qr:
                last_qr_frame, last_qr_code = grouped_qr[-1]
                last_qr_second = round((last_qr_frame - 1) / self.fps, 1)
                if last_qr_second >= start_time and last_qr_second <= end_time:
                    logging.info(f"Last QR event: Te={last_qr_second}s, QR={last_qr_code}")
            # Find Ts/Te
            video.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
            frame_count = start_frame
            last_te = -self.min_packing_time * self.fps
            prev_te_frame = None
            for idx, (te_frame, qr_code) in enumerate(grouped_qr):
                if te_frame <= last_te + self.min_packing_time * self.fps:
                    logging.info(f"Skipping event for QR {qr_code} at frame {te_frame}: too close to last_te {last_te}")
                    continue
                second_te = round((te_frame - 1) / self.fps)
                if second_te < start_time or second_te > end_time:
                    continue
                segment_index = math.floor(second_te / segment_duration)
                target_start_second = segment_index * segment_duration
                target_end_second = (segment_index + 1) * segment_duration
                if second_te >= current_end_second or target_start_second != current_start_second:
                    current_start_second = target_start_second
                    current_end_second = min(target_start_second + segment_duration, end_segment)
                    camera_log_dir = os.path.join(self.log_dir, camera_name)
                    os.makedirs(camera_log_dir, exist_ok=True)
                    log_file = os.path.join(camera_log_dir, f"log_{video_name}_{current_start_second:04d}_{current_end_second:04d}.txt")
                    log_file_handle = self._update_log_file(log_file, current_start_second, current_end_second, start_time_obj + timedelta(seconds=current_start_second), camera_name, video_file)
                ts_frame = None
                # Trường hợp đặc biệt: Te đầu tiên
                if idx == 0:
                    has_stable_segment = any(start <= te_frame for start, end in stable_segments)
                    if not has_stable_segment:
                        log_file_handle(f"On,{qr_code}", second_te)
                        logging.info(f"Logged only Te for QR {qr_code} at second {second_te}: no stable segments for first Te")
                        last_te = te_frame
                        prev_te_frame = te_frame
                        continue
                # Tìm vùng ổn định sau Te phía trước (hoặc đầu video nếu không có Te trước)
                closest_stable = None
                search_start = max(prev_te_frame if prev_te_frame is not None else start_frame, start_frame)
                for start, end in stable_segments:
                    if start > search_start and end < te_frame:
                        if closest_stable is None or start < closest_stable[0]:
                            closest_stable = (start, end)
                if closest_stable:
                    # Tìm tay sau vùng ổn định
                    video.set(cv2.CAP_PROP_POS_FRAMES, closest_stable[1])
                    hand_frame_count = closest_stable[1]
                    while hand_frame_count < te_frame and hand_frame_count < end_frame:
                        ret, frame = video.read()
                        if not ret:
                            break
                        if roi:
                            x, y, w, h = roi
                            frame_height, frame_width = frame.shape[:2]
                            if w > 0 and h > 0 and y + h <= frame_height and x + w <= frame_width:
                                frame = frame[y:y + h, x:x + w]
                        hand_frame_count += 1
                        if hand_frame_count % self.frame_interval != 0:
                            continue
                        if self.detect_hand(frame) and hand_frame_count > last_te + self.min_packing_time * self.fps:
                            ts_frame = hand_frame_count
                            second_ts = round((ts_frame - 1) / self.fps, 1)
                            if second_ts >= start_time and second_ts <= end_time:
                                logging.info(f"Hand detected for Ts: frame={ts_frame}, time={second_ts}s")
                                break
                            ts_frame = None
                else:
                    # Không có vùng ổn định, tìm tay ngay sau Te phía trước
                    if prev_te_frame is not None:
                        video.set(cv2.CAP_PROP_POS_FRAMES, max(prev_te_frame, start_frame))
                        hand_frame_count = max(prev_te_frame, start_frame)
                        while hand_frame_count < te_frame and hand_frame_count < end_frame:
                            ret, frame = video.read()
                            if not ret:
                                break
                            if roi:
                                x, y, w, h = roi
                                frame_height, frame_width = frame.shape[:2]
                                if w > 0 and h > 0 and y + h <= frame_height and x + w <= frame_width:
                                    frame = frame[y:y + h, x:x + w]
                            hand_frame_count += 1
                            if hand_frame_count % self.frame_interval != 0:
                                continue
                            if self.detect_hand(frame) and hand_frame_count > last_te + self.min_packing_time * self.fps:
                                ts_frame = hand_frame_count
                                second_ts = round((ts_frame - 1) / self.fps, 1)
                                if second_ts >= start_time and second_ts <= end_time:
                                    logging.info(f"Hand detected for Ts: frame={ts_frame}, time={second_ts}s")
                                    break
                                ts_frame = None
                # Ghi log
                if ts_frame:
                    second_ts = round((ts_frame - 1) / self.fps)
                    segment_index = math.floor(max(second_ts, second_te) / segment_duration)
                    target_start_second = segment_index * segment_duration
                    target_end_second = (segment_index + 1) * segment_duration
                    if max(second_ts, second_te) >= current_end_second or target_start_second != current_start_second:
                        current_start_second = target_start_second
                        current_end_second = min(target_start_second + segment_duration, end_segment)
                        camera_log_dir = os.path.join(self.log_dir, camera_name)
                        os.makedirs(camera_log_dir, exist_ok=True)
                        log_file = os.path.join(camera_log_dir, f"log_{video_name}_{current_start_second:04d}_{current_end_second:04d}.txt")
                        log_file_handle = self._update_log_file(log_file, current_start_second, current_end_second, start_time_obj + timedelta(seconds=current_start_second), camera_name, video_file)
                    log_file_handle("On,", second_ts - 1)
                    log_file_handle("Off,", second_ts)
                    log_file_handle("Off,", second_te - 1)
                    log_file_handle(f"On,{qr_code}", second_te)
                    logging.info(f"Event logged: Ts={second_ts}, Te={second_te}, QR={qr_code}")
                else:
                    second_ts = second_te - self.min_packing_time - 1
                    if second_ts >= start_time and second_ts >= (last_te / self.fps):
                        segment_index = math.floor(max(second_ts, second_te) / segment_duration)
                        target_start_second = segment_index * segment_duration
                        target_end_second = (segment_index + 1) * segment_duration
                        if max(second_ts, second_te) >= current_end_second or target_start_second != current_start_second:
                            current_start_second = target_start_second
                            current_end_second = min(target_start_second + segment_duration, end_segment)
                            camera_log_dir = os.path.join(self.log_dir, camera_name)
                            os.makedirs(camera_log_dir, exist_ok=True)
                            log_file = os.path.join(camera_log_dir, f"log_{video_name}_{current_start_second:04d}_{current_end_second:04d}.txt")
                            log_file_handle = self._update_log_file(log_file, current_start_second, current_end_second, start_time_obj + timedelta(seconds=current_start_second), camera_name, video_file)
                        log_file_handle("On,", second_ts - 1)
                        log_file_handle("Off,", second_ts)
                        log_file_handle("Off,", second_te - 1)
                        log_file_handle(f"On,{qr_code}", second_te)
                        logging.info(f"Assumed Ts={second_ts} for Te={second_te}, QR={qr_code}")
                    else:
                        log_file_handle("Off,", second_te - 1)
                        log_file_handle(f"On,{qr_code}", second_te)
                        logging.info(f"Logged only Te for QR {qr_code} at second {second_te}: assumed Ts={second_ts} invalid (out of range or too close to last_te)")
                last_te = te_frame
                prev_te_frame = te_frame
            video.release()
            with db_rwlock.gen_wlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("UPDATE file_list SET is_processed = 1, status = ? WHERE file_path = ?", ("xong", video_file))
                conn.commit()
                conn.close()
            logging.info(f"Completed processing video: {video_file}")
            return log_file

```
## 📄 File: `frame_sampler_trigger.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/frame_sampler_trigger.py`

```python
import cv2
import os
import logging
import sqlite3
import threading
import subprocess
import json
import numpy as np
from datetime import datetime, timezone, timedelta
from modules.db_utils import get_db_connection
from modules.scheduler.db_sync import frame_sampler_event, db_rwlock
import math
from modules.config.logging_config import get_logger


BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "models", "wechat_qr")
DETECT_PROTO = os.path.join(MODEL_DIR, "detect.prototxt")
DETECT_MODEL = os.path.join(MODEL_DIR, "detect.caffemodel")
SR_PROTO = os.path.join(MODEL_DIR, "sr.prototxt")
SR_MODEL = os.path.join(MODEL_DIR, "sr.caffemodel")

class FrameSamplerTrigger:
    def __init__(self):
        self.setup_logging()
        self.load_config()
        self.video_lock = threading.Lock()
        self.setup_wechat_qr()

    def setup_logging(self):
        self.logger = get_logger(__name__, {"video_id": os.path.basename(self.video_file)})
        self.logger.info("Logging initialized")

    def load_config(self):
        logging.info("Loading configuration from database")
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT input_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            self.video_root = result[0] if result else os.path.join(BASE_DIR, "Inputvideo")
            cursor.execute("SELECT output_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            self.output_path = result[0] if result else os.path.join(BASE_DIR, "output_clips")
            self.log_dir = os.path.join(self.output_path, "LOG", "Frame")
            os.makedirs(self.log_dir, exist_ok=True)
            cursor.execute("SELECT timezone FROM general_info WHERE id = 1")
            result = cursor.fetchone()
            tz_hours = int(result[0].split("+")[1]) if result and "+" in result[0] else 7
            self.video_timezone = timezone(timedelta(hours=tz_hours))
            cursor.execute("SELECT frame_rate, frame_interval, min_packing_time FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            self.fps, self.frame_interval, self.min_packing_time = result if result else (30, 5, 5)
            logging.info(f"Config loaded: video_root={self.video_root}, output_path={self.output_path}, timezone={self.video_timezone}, fps={self.fps}, frame_interval={self.frame_interval}, min_packing_time={self.min_packing_time}")

    def get_packing_area(self, camera_name):
        logging.info(f"Querying qr_mvd_area and jump_time_ratio for camera {camera_name}")
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT qr_mvd_area, jump_time_ratio FROM packing_profiles WHERE profile_name = ?", (camera_name,))
            result = cursor.fetchone()
            cursor.execute("SELECT qr_trigger_area FROM packing_profiles WHERE profile_name = ?", (camera_name,))
            trigger_result = cursor.fetchone()
            conn.close()
        if result and result[1] is not None:
            self.jump_time_ratio = float(result[1])
            logging.info(f"Loaded jump_time_ratio: {self.jump_time_ratio}")
        else:
            self.jump_time_ratio = 0.5
            logging.info(f"Using default jump_time_ratio: {self.jump_time_ratio}")

        if result and result[0]:
            try:
                qr_mvd_area = result[0]
                if qr_mvd_area.startswith('(') and qr_mvd_area.endswith(')'):
                    x, y, w, h = map(int, qr_mvd_area.strip('()').split(','))
                else:
                    parsed = json.loads(qr_mvd_area)
                    if isinstance(parsed, list) and len(parsed) == 4:
                        x, y, w, h = parsed
                    else:
                        x, y, w, h = parsed['x'], parsed['y'], parsed['w'], parsed['h']
                roi = (x, y, w, h)
                logging.info(f"Using qr_mvd_area: {roi}")
            except (ValueError, json.JSONDecodeError, KeyError, TypeError) as e:
                logging.error(f"Error parsing qr_mvd_area for camera {camera_name}: {str(e)}")
                roi = None
        else:
            logging.warning(f"No qr_mvd_area found for camera {camera_name}")
            roi = None
        trigger = json.loads(trigger_result[0]) if trigger_result and trigger_result[0] else [0, 0, 0, 0]
        logging.info(f"Using trigger: {trigger}")
        return roi, trigger

    def get_video_duration(self, video_file):
        try:
            cmd = ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", video_file]
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            return float(result.stdout.strip())
        except Exception:
            logging.error(f"Failed to get duration of video {video_file}")
            return None

    def load_video_files(self):
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT file_path FROM file_list WHERE is_processed = 0 AND status != 'xong' ORDER BY priority DESC, created_at ASC")
            video_files = [row[0] for row in cursor.fetchall()]
            conn.close()
        if not video_files:
            logging.info("No video files found with is_processed = 0 and status != 'xong'.")
        return video_files

    def process_frame(self, frame, frame_count):
        try:
            if len(frame.shape) == 2:
                frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
            texts, _ = self.qr_detector.detectAndDecode(frame)
            state = "Off"
            mvd = ""
            for text in texts:
                if text == "TimeGo":
                    state = "On"
                elif text:
                    mvd = text
            return state, mvd
        except Exception as e:
            logging.error(f"Error processing frame {frame_count}: {str(e)}")
            return "", ""

    def _get_video_start_time(self, video_file):
        try:
            result = subprocess.check_output(['ffprobe', '-v', 'quiet', '-show_entries', 'format_tags=creation_time', '-of', 'default=noprint_wrappers=1:nokey=1', video_file])
            return datetime.strptime(result.decode().strip(), '%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=timezone.utc).astimezone(self.video_timezone)
        except (subprocess.CalledProcessError, ValueError):
            try:
                result = subprocess.check_output(['exiftool', '-CreateDate', '-d', '%Y-%m-%d %H:%M:%S', video_file])
                return datetime.strptime(result.decode().split('CreateDate')[1].strip().split('\n')[0].strip(), '%Y-%m-%d %H:%M:%S').replace(tzinfo=self.video_timezone)
            except (subprocess.CalledProcessError, IndexError):
                try:
                    result = subprocess.check_output(['exiftool', '-FileCreateDate', '-d', '%Y-%m-%d %H:%M:%S', video_file])
                    return datetime.strptime(result.decode().split('FileCreateDate')[1].strip().split('\n')[0].strip(), '%Y-%m-%d %H:%M:%S').replace(tzinfo=self.video_timezone)
                except (subprocess.CalledProcessError, IndexError):
                    logging.warning("No metadata found, using file creation time.")
                    return datetime.fromtimestamp(os.path.getctime(video_file), tz=self.video_timezone)

    def _update_log_file(self, log_file, start_second, end_second, start_time, camera_name, video_file):
        log_file_handle = open(log_file, 'w')
        log_file_handle.write(f"# Start: {start_second}, End: {end_second}, Start_Time: {start_time.strftime('%Y-%m-%d %H:%M:%S')}, Camera_Name: {camera_name}, Video_File: {video_file}\n")
        log_file_handle.flush()
        with db_rwlock.gen_wlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM processed_logs WHERE log_file = ?", (log_file,))
            if not cursor.fetchone():
                cursor.execute("INSERT INTO processed_logs (log_file, is_processed) VALUES (?, 0)", (log_file,))
            conn.commit()
            conn.close()
        return log_file_handle

    def run(self):
        while True:
            frame_sampler_event.wait()
            video_files = self.load_video_files()
            if not video_files:
                logging.info("No videos to process")
                frame_sampler_event.clear()
                continue
            for video_file in video_files:
                log_file = self.process_video(video_file, self.video_lock, self.get_packing_area, self.process_frame, self.frame_interval)
                if log_file:
                    logging.info(f"Completed processing video {video_file}, log at {log_file}")
                else:
                    logging.error(f"Failed to process video {video_file}")
            frame_sampler_event.clear()

    def process_video(self, video_file, video_lock, get_packing_area_func, process_frame_func, frame_interval, start_time=0, end_time=None):
        with video_lock:
            logging.info(f"Processing video: {video_file} from {start_time}s to {end_time}s")
            if not os.path.exists(video_file):
                logging.error(f"File '{video_file}' does not exist")
                with db_rwlock.gen_wlock():
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("lỗi", video_file))
                    conn.commit()
                    conn.close()
                return None
            with db_rwlock.gen_wlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("đang frame sampler ...", video_file))
                cursor.execute("SELECT camera_name FROM file_list WHERE file_path = ?", (video_file,))
                result = cursor.fetchone()
                camera_name = result[0] if result and result[0] else "CamTest"
                conn.commit()
                conn.close()
            video = cv2.VideoCapture(video_file)
            if not video.isOpened():
                logging.error(f"Failed to open video '{video_file}'")
                with db_rwlock.gen_wlock():
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("lỗi", video_file))
                    conn.commit()
                    conn.close()
                return None
            start_time_obj = self._get_video_start_time(video_file)
            roi, trigger = get_packing_area_func(camera_name)
            total_seconds = self.get_video_duration(video_file)
            if total_seconds is None:
                logging.error(f"Failed to get duration of video {video_file}")
                with db_rwlock.gen_wlock():
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("lỗi", video_file))
                    conn.commit()
                    conn.close()
                return None
            logging.info(f"Video duration {video_file}: {total_seconds} seconds")
            video_name = os.path.splitext(os.path.basename(video_file))[0]
            segment_duration = 300
            # Xác định các đoạn 300s chứa [start_time, end_time]
            end_time = total_seconds if end_time is None else min(end_time, total_seconds)
            start_segment = math.floor(start_time / segment_duration) * segment_duration
            end_segment = math.ceil(end_time / segment_duration) * segment_duration
            current_start_second = start_segment
            current_end_second = min(current_start_second + segment_duration, end_segment)
            camera_log_dir = os.path.join(self.log_dir, camera_name)
            os.makedirs(camera_log_dir, exist_ok=True)
            log_file = os.path.join(camera_log_dir, f"log_{video_name}_{current_start_second:04d}_{current_end_second:04d}.txt")
            log_file_handle = self._update_log_file(log_file, current_start_second, current_end_second, start_time_obj + timedelta(seconds=current_start_second), camera_name, video_file)
            # Bắt đầu từ khung hình tại start_time
            start_frame = int(start_time * self.fps)
            end_frame = int(end_time * self.fps)
            video.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
            frame_count = start_frame
            frame_states = []
            mvd_list = []
            last_state = None
            last_mvd = ""
            jump_time_ratio = getattr(self, 'jump_time_ratio', 0.5)  # Lấy từ config hoặc mặc định 0.5
            while video.isOpened() and frame_count < end_frame:
                ret, frame = video.read()
                if not ret:
                    break
                if roi:
                    x, y, w, h = roi
                    frame_height, frame_width = frame.shape[:2]
                    if w > 0 and h > 0 and y + h <= frame_height and x + w <= frame_width:
                        frame = frame[y:y + h, x:x + w]
                    else:
                        logging.warning(f"Invalid ROI for frame {frame_count}: {roi}, frame size: {frame_width}x{frame_height}")
                        frame = frame
                frame_count += 1
                if frame_count % frame_interval != 0:
                    continue
                if frame.size == 0 or frame.shape[0] == 0 or frame.shape[1] == 0:
                    logging.warning(f"Empty frame {frame_count}, skipping")
                    continue
                state, mvd = process_frame_func(frame, frame_count)
                second_in_video = (frame_count - 1) / self.fps
                second = round(second_in_video)
                if second >= current_end_second and second < end_time:
                    log_file_handle.close()
                    current_start_second = current_end_second
                    current_end_second = min(current_start_second + segment_duration, end_segment)
                    camera_log_dir = os.path.join(self.log_dir, camera_name)
                    os.makedirs(camera_log_dir, exist_ok=True)
                    log_file = os.path.join(camera_log_dir, f"log_{video_name}_{current_start_second:04d}_{current_end_second:04d}.txt")
                    log_file_handle = self._update_log_file(log_file, current_start_second, current_end_second, start_time_obj + timedelta(seconds=current_start_second), camera_name, video_file)
                if second >= start_time and second <= end_time:
                    # Ghi MVD ngay nếu có và khác last_mvd
                    if mvd and mvd != last_mvd:
                        log_line = f"{second},{state},{mvd}\n"
                        log_file_handle.write(log_line)
                        logging.info(f"Log second {second}: state={state}, mvd={mvd}")
                        log_file_handle.flush()
                        last_mvd = mvd
                    # Tiếp tục thu thập trạng thái cho final_state
                    frame_states.append(state)
                    mvd_list.append(mvd)
                    if len(frame_states) == 5:
                        on_count = sum(1 for s in frame_states if s == "On")
                        off_count = sum(1 for s in frame_states if s == "Off")
                        frame_states_str = " ".join(frame_states).lower()
                        final_state = None
                        if on_count >= 3:
                            final_state = "On"
                        elif off_count == 5:
                            final_state = "Off"
                        if final_state:
                            if final_state != last_state:
                                log_line = f"{second},{final_state},\n"
                                log_file_handle.write(log_line)
                                logging.info(f"Log second {second}: {frame_states_str}: {final_state}")
                                log_file_handle.flush()
                                if last_state == "On" and final_state == "Off":
                                    jump_frames = int(jump_time_ratio * self.min_packing_time * self.fps)
                                    new_frame_count = frame_count + jump_frames
                                    if new_frame_count < end_frame:
                                        video.set(cv2.CAP_PROP_POS_FRAMES, new_frame_count)
                                        frame_count = new_frame_count
                                        logging.info(f"Jumped {jump_frames} frames to {frame_count} after On->Off transition")
                                last_state = final_state
                        else:
                            logging.info(f"Skipped second {second}: {frame_states_str}, on_count={on_count}, off_count={off_count}")
                            log_file_handle.flush()
                        frame_states = []
                        mvd_list = []
            log_file_handle.close()
            video.release()
            with db_rwlock.gen_wlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("UPDATE file_list SET is_processed = 1, status = ? WHERE file_path = ?", ("xong", video_file))
                conn.commit()
                conn.close()
            logging.info(f"Completed processing video: {video_file}")
            return log_file

```
## 📄 File: `cutter_complete.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/cutter/cutter_complete.py`

```python
import subprocess

def cut_complete_event(event, video_buffer, video_length, output_file):
    """Cắt video cho sự kiện hoàn chỉnh (có cả ts và te)."""
    ts = event.get("ts")
    te = event.get("te")
    video_file = event.get("video_file")

    start_time = max(0, ts - video_buffer)  # Thêm buffer trước ts
    end_time = min(te + video_buffer, video_length)  # Thêm buffer sau te
    duration = end_time - start_time

    if duration <= 0:
        print(f"Bỏ qua: Duration không hợp lệ ({duration}s) cho sự kiện {event.get('event_id')}")
        return False

    try:
        cmd = [
            "ffmpeg",
            "-i", video_file,
            "-ss", str(start_time),
            "-t", str(duration),
            "-c:v", "copy",
            "-c:a", "copy",
            "-y",
            output_file
        ]
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print(f"Đã cắt video: {output_file}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Lỗi khi cắt video {video_file}: {e}")
        return False
    except Exception as e:
        print(f"Lỗi không xác định: {e}")
        return False
```
## 📄 File: `cutter_incomplete.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/cutter/cutter_incomplete.py`

```python
import os
import subprocess
from .cutter_utils import generate_merged_filename, generate_output_filename

def cut_incomplete_event(event, video_buffer, video_length, output_file):
    """Cắt video cho sự kiện dở dang (thiếu ts hoặc te)."""
    ts = event.get("ts")
    te = event.get("te")
    video_file = event.get("video_file")

    # Log độ dài video gốc
    print(f"Video gốc {video_file} có độ dài: {video_length} giây")

    # Log giá trị video_buffer
    print(f"Sử dụng video_buffer: {video_buffer} giây")

    if ts is not None and te is None:  # Chỉ có ts
        start_time = max(0, ts - video_buffer)
        duration = video_length - start_time
    elif ts is None and te is not None:  # Chỉ có te
        start_time = 0
        duration = min(te + video_buffer, video_length)
    else:
        print(f"Bỏ qua: Sự kiện {event.get('event_id')} không có ts hoặc te")
        return False

    if duration <= 0:
        print(f"Bỏ qua: Duration không hợp lệ ({duration}s) cho sự kiện {event.get('event_id')}")
        return False

    try:
        cmd = [
            "ffmpeg",
            "-i", video_file,
            "-ss", str(start_time),
            "-t", str(duration),
            "-c:v", "copy",
            "-c:a", "copy",
            "-y",
            output_file
        ]
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print(f"Đã cắt video: {output_file}")

        # Log độ dài của file dở dang vừa tạo
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", output_file],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        duration = float(probe.stdout.strip())
        print(f"File dở dang {output_file} có độ dài: {duration} giây")

        event["cut_video_file"] = output_file
        return True
    except subprocess.CalledProcessError as e:
        print(f"Lỗi khi cắt video {video_file}: {e}")
        return False
    except Exception as e:
        print(f"Lỗi không xác định: {e}")
        return False

def merge_incomplete_events(event_a, event_b, video_buffer, video_length_a, video_length_b, output_dir, max_packing_time, brand_name="Alan"):
    """Ghép nối hai sự kiện dở dang (A có ts, B có te) và tạo file ghép với tên tối ưu."""
    video_file_a = event_a.get("video_file")
    video_file_b = event_b.get("video_file")

    # Kiểm tra nếu file đã được cắt sẵn
    temp_file_a = event_a.get("cut_video_file")
    temp_file_b = event_b.get("cut_video_file")
    files_to_cleanup = []

    # Tạo thư mục temp_clips để lưu file tạm
    temp_clips_dir = os.path.join(os.path.dirname(output_dir), "temp_clips")
    if not os.path.exists(temp_clips_dir):
        os.makedirs(temp_clips_dir)

    # Nếu không có file cắt sẵn, cắt ngay lập tức và lưu vào temp_clips_dir
    if not temp_file_a or not os.path.exists(temp_file_a):
        temp_file_a = os.path.join(temp_clips_dir, f"temp_a_{event_a.get('event_id')}_incomplete.mp4")
        if not cut_incomplete_event(event_a, video_buffer, video_length_a, temp_file_a):
            print(f"Lỗi: Không thể cắt file tạm cho sự kiện {event_a.get('event_id')}")
            return None
    if not temp_file_b or not os.path.exists(temp_file_b):
        temp_file_b = os.path.join(temp_clips_dir, f"temp_b_{event_b.get('event_id')}_incomplete.mp4")
        if not cut_incomplete_event(event_b, video_buffer, video_length_b, temp_file_b):
            print(f"Lỗi: Không thể cắt file tạm cho sự kiện {event_b.get('event_id')}")
            return None

    # Tạo tên file đầu ra tối ưu dựa trên temp_file_a và temp_file_b
    file_name_a = os.path.basename(temp_file_a)
    file_name_b = os.path.basename(temp_file_b)
    parts_a = file_name_a.split("_")
    parts_b = file_name_b.split("_")

    # Lấy Brand từ file đầu tiên
    brand_name = parts_a[0]

    # Lấy mã vận đơn từ cả hai file, loại bỏ "NoCode"
    tracking_codes = []
    if len(parts_a) >= 2 and parts_a[1] != "NoCode":
        tracking_codes.append(parts_a[1])
    if len(parts_b) >= 2 and parts_b[1] != "NoCode":
        tracking_codes.append(parts_b[1])

    # Lấy thời gian từ file đầu tiên
    date = parts_a[2] if len(parts_a) >= 3 else "unknown"
    hour = parts_a[3].split(".")[0] if len(parts_a) >= 4 else "0000"
    time_str = f"{date}_{hour}"

    # Tạo tên mã vận đơn: dùng một mã hoặc ghép nhiều mã bằng "-"
    tracking_str = "-".join(tracking_codes) if tracking_codes else "unknown"

    # Tạo tên file đầu ra
    output_file = os.path.join(output_dir, f"{brand_name}_{tracking_str}_{time_str}.mp4")

    # Ghép nối video A và B
    concat_list_file = os.path.join(output_dir, f"concat_list_{event_a.get('event_id')}.txt")
    try:
        with open(concat_list_file, 'w') as f:
            f.write(f"file '{temp_file_a}'\nfile '{temp_file_b}'\n")

        cmd_concat = [
            "ffmpeg",
            "-f", "concat",
            "-safe", "0",
            "-i", concat_list_file,
            "-c", "copy",
            "-y",
            output_file
        ]
        subprocess.run(cmd_concat, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        print(f"Đã ghép và cắt video: {output_file}")

        # Log độ dài của file ghép
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", output_file],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        duration = float(probe.stdout.strip())
        print(f"File ghép {output_file} có độ dài: {duration} giây")

        # Xóa các file tạm và file concat_list sau khi ghép thành công
        if os.path.exists(temp_file_a):
            os.remove(temp_file_a)
        if os.path.exists(temp_file_b):
            os.remove(temp_file_b)
        if os.path.exists(concat_list_file):
            os.remove(concat_list_file)

        return output_file

    except subprocess.CalledProcessError as e:
        print(f"Lỗi khi ghép video: {e}")
        # Xóa các file tạm và file concat_list trong trường hợp lỗi
        if os.path.exists(temp_file_a):
            os.remove(temp_file_a)
        if os.path.exists(temp_file_b):
            os.remove(temp_file_b)
        if os.path.exists(concat_list_file):
            os.remove(concat_list_file)
        return None
    except Exception as e:
        print(f"Lỗi không xác định khi ghép video: {e}")
        # Xóa các file tạm và file concat_list trong trường hợp lỗi
        if os.path.exists(temp_file_a):
            os.remove(temp_file_a)
        if os.path.exists(temp_file_b):
            os.remove(temp_file_b)
        if os.path.exists(concat_list_file):
            os.remove(concat_list_file)
        return None
```
## 📄 File: `cutter_utils.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/cutter/cutter_utils.py`

```python
import os
from datetime import datetime
import ast

def is_reasonable_timestamp(ts):
    """Kiểm tra xem timestamp có hợp lệ không (lớn hơn năm 2020)."""
    return ts and int(ts) > 1577836800000  # Trên năm 2020

def generate_output_filename(event, tracking_codes_filter, output_dir, brand_name="Alan"):
    """Tạo tên file đầu ra dựa trên tracking code và thời gian ưu tiên: packing_time_start > packing_time_end."""
    tracking_codes_str = event.get("tracking_codes")
    packing_time_start = event.get("packing_time_start")
    packing_time_end = event.get("packing_time_end")

    try:
        tracking_codes = ast.literal_eval(tracking_codes_str) if tracking_codes_str else []
    except (ValueError, SyntaxError) as e:
        print(f"Lỗi parse tracking_codes_str cho event {event.get('event_id')}: {e}")
        tracking_codes = []

    # Chọn tracking code ưu tiên
    if tracking_codes_filter:
        selected_tracking_code = next((code for code in tracking_codes_filter if code in tracking_codes), "NoCode")
    else:
        selected_tracking_code = tracking_codes[-1] if tracking_codes else "NoCode"

    # Ưu tiên chọn thời gian: packing_time_start > packing_time_end > fallback
    timestamp = next(
        (t for t in [packing_time_start, packing_time_end] if is_reasonable_timestamp(t)),
        0  # Fallback
    )
    try:
        time_str = datetime.fromtimestamp(int(timestamp) / 1000).strftime("%Y%m%d_%H%M")
    except Exception:
        time_str = "19700101_0000"

    return os.path.join(output_dir, f"{brand_name}_{selected_tracking_code}_{time_str}.mp4")

def generate_merged_filename(event_a, event_b, output_dir, brand_name="Alan"):
    """Tạo tên file ghép cho hai sự kiện dở dang, ưu tiên thời gian: packing_time_start > packing_time_end."""
    tracking_codes_a_str = event_a.get("tracking_codes")
    tracking_codes_b_str = event_b.get("tracking_codes")
    packing_time_start_a = event_a.get("packing_time_start")
    packing_time_end_b = event_b.get("packing_time_end")

    # Chọn tracking code (ưu tiên sự kiện có mã vận đơn)
    try:
        tracking_codes_a = ast.literal_eval(tracking_codes_a_str) if tracking_codes_a_str else []
    except (ValueError, SyntaxError):
        tracking_codes_a = []
    try:
        tracking_codes_b = ast.literal_eval(tracking_codes_b_str) if tracking_codes_b_str else []
    except (ValueError, SyntaxError):
        tracking_codes_b = []

    selected_tracking_code = tracking_codes_b[-1] if tracking_codes_b else (tracking_codes_a[-1] if tracking_codes_a else "NoCode")

    # Ưu tiên chọn thời gian: packing_time_start > packing_time_end > fallback
    timestamp = next(
        (t for t in [packing_time_start_a, packing_time_end_b] if is_reasonable_timestamp(t)),
        0  # Fallback
    )
    try:
        time_str = datetime.fromtimestamp(int(timestamp) / 1000).strftime("%Y%m%d_%H%M")
    except Exception:
        time_str = "19700101_0000"

    return os.path.join(output_dir, f"{brand_name}_{selected_tracking_code}_{time_str}.mp4")

def update_event_in_db(cursor, event_id, output_file):
    """Cập nhật CSDL cho một sự kiện."""
    cursor.execute("""
        UPDATE events 
        SET is_processed = 1, output_file = ? 
        WHERE event_id = ?
    """, (output_file, event_id))
```