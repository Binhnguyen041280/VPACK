# 📦 Tổng hợp mã nguồn Vtrack

**Tổng cộng:** 41 file `.py`, 32 file `.js`

---

## 📄 File: `GPT_heatmap.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/GPT_heatmap.py`

```python
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.widgets import Button

# Cấu hình khung
frame_width = 1280
frame_height = 720
qr_frames = []
frame_id = 1
MAX_BLOCKS = 90
EVALUATE_EVERY = 10
is_r1_confirmed = False

# Cấu hình vùng
R1 = []
R1_zones = []
R2_groups = []
R2_zone_lists = []
R2_colors = ["orange", "gold", "tomato", "chocolate", "salmon"]
R2_MIN_QR = 5

def create_expanded_zone(x, y, size=100):
    return (x - size // 2, y - size // 2, size, size)

def is_overlapping_zone(x, y, zones):
    zx, zy, zw, zh = create_expanded_zone(x, y)
    for (ox, oy, ow, oh) in zones:
        if not (zx + zw < ox or ox + ow < zx or zy + zh < oy or oy + oh < zy):
            return True
    return False

def cluster_remaining_qrs(qrs):
    clusters, zones = [], []
    for (x, y) in qrs:
        added = False
        for idx, cluster in enumerate(clusters):
            if is_overlapping_zone(x, y, zones[idx]):
                cluster.append((x, y))
                zones[idx].append(create_expanded_zone(x, y))
                added = True
                break
        if not added:
            clusters.append([(x, y)])
            zones.append([create_expanded_zone(x, y)])
    return [(c, z) for c, z in zip(clusters, zones) if len(c) >= R2_MIN_QR]

def compute_bounding_box_from_zones(zones):
    if not zones:
        return (0, 0, 0, 0)
    x1s = [x for x, y, w, h in zones]
    y1s = [y for x, y, w, h in zones]
    x2s = [x + w for x, y, w, h in zones]
    y2s = [y + h for x, y, w, h in zones]
    return min(x1s), min(y1s), max(x2s) - min(x1s), max(y2s) - min(y1s)

def compute_area_percent(w, h):
    return round((w * h) / (frame_width * frame_height) * 100, 2)

def evaluate_regions_with_r1_correction():
    global R1, R1_zones, R2_groups, R2_zone_lists, is_r1_confirmed
    print("🔍 Đánh giá QR mới. R1 sẽ được hiệu chỉnh nếu cần.")
    all_qrs = [qr for frame in qr_frames for qr in frame['qr_points']]
    clustered = cluster_remaining_qrs(all_qrs)
    if not clustered:
        print("⚠️ Không tìm thấy cụm nào đủ QR.")
        return
    clustered.sort(key=lambda c: len(c[0]), reverse=True)
    largest_cluster = clustered[0]

    if not is_r1_confirmed:
        R1 = largest_cluster[0]
        R1_zones = largest_cluster[1]
        is_r1_confirmed = True
        print(f"✅ Khởi tạo R1 từ cụm lớn nhất (QR: {len(R1)})")
    else:
        if len(largest_cluster[0]) > len(R1):
            print(f"🔁 Cập nhật R1 vì cụm mới lớn hơn ({len(largest_cluster[0])} > {len(R1)})")
            R1 = largest_cluster[0]
            R1_zones = largest_cluster[1]

    # Xác định R2
    R2_groups = []
    R2_zone_lists = []
    for c, z in clustered[1:]:
        if len(c) >= R2_MIN_QR:
            R2_groups.append(c)
            R2_zone_lists.append(z)

def redraw():
    ax.clear()
    ax.set_xlim(0, frame_width)
    ax.set_ylim(0, frame_height)
    ax.invert_yaxis()
    ax.set_title("R1 từ vùng mở rộng. R2 nếu đủ QR. R3 = phần còn lại.")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")

    for frame in qr_frames:
        for x, y in frame['qr_points']:
            rect = patches.Rectangle((x - 50, y - 50), 100, 100, linewidth=1, edgecolor='gray', facecolor='none', linestyle='--')
            ax.add_patch(rect)
        ax.text(frame['qr_points'][0][0], frame['qr_points'][0][1] - 60, f"B{frame['frame_id']}", color='gray', fontsize=8)

    total_area = frame_width * frame_height
    used_area = 0

    if R1_zones:
        rx, ry, rw, rh = compute_bounding_box_from_zones(R1_zones)
        used_area += rw * rh
        r1_pct = compute_area_percent(rw, rh)
        rect = patches.Rectangle((rx, ry), rw, rh, linewidth=2, edgecolor='red', facecolor='none')
        ax.add_patch(rect)
        ax.text(rx + 5, ry - 10, f"R1 ({r1_pct}%)", color='red', fontsize=10)

    r2_total = 0
    for i, group in enumerate(R2_groups):
        color = R2_colors[i % len(R2_colors)]
        rx, ry, rw, rh = compute_bounding_box_from_zones([create_expanded_zone(x, y) for (x, y) in group])
        area_pct = compute_area_percent(rw, rh)
        r2_total += rw * rh
        rect = patches.Rectangle((rx, ry), rw, rh, linewidth=2, edgecolor=color, facecolor='none')
        ax.add_patch(rect)
        ax.text(rx + 5, ry - 10, f"R2.{i+1} ({area_pct}%)", color=color, fontsize=10)

    r3_area = total_area - used_area - r2_total
    r3_pct = round(r3_area / total_area * 100, 2)
    ax.text(frame_width - 180, 20, f"R3: {r3_pct}%", color='green', fontsize=11)

    fig.canvas.draw()

def onclick(event):
    global frame_id
    if frame_id > MAX_BLOCKS:
        print("⚠️ Đã đạt giới hạn 90 block.")
        return
    if event.xdata and event.ydata:
        x, y = int(event.xdata), int(event.ydata)
        qr_frames.append({'frame_id': frame_id, 'qr_points': [(x, y)]})
        print(f"✅ Block {frame_id}: QR tại ({x}, {y})")
        frame_id += 1
        if (frame_id - 1) % EVALUATE_EVERY == 0:
            evaluate_regions_with_r1_correction()
        redraw()

def load_qr_points_from_file(filepath):
    global qr_frames, frame_id
    qr_frames = []
    with open(filepath, "r") as f:
        lines = f.readlines()
    for idx, line in enumerate(lines):
        x, y = map(int, line.strip().split(","))
        qr_frames.append({'frame_id': idx + 1, 'qr_points': [(x, y)]})
    frame_id = len(qr_frames) + 1
    evaluate_regions_with_r1_correction()
    redraw()
    print(f"📥 Đã nạp {len(qr_frames)} QR từ file: {filepath}")

def on_import_button_click(event):
    fixed_path = input("📂 Nhập đường dẫn file QR (.txt): ").strip()
    if fixed_path and fixed_path.endswith(".txt"):
        load_qr_points_from_file(fixed_path)

# Giao diện chính
fig, ax = plt.subplots(figsize=(10, 6))
ax.set_xlim(0, frame_width)
ax.set_ylim(0, frame_height)
ax.invert_yaxis()
fig.canvas.mpl_connect('key_press_event', lambda event: None)
fig.canvas.mpl_connect('button_press_event', onclick)

# Nút Import file QR
btn_ax = fig.add_axes([0.8, 0.02, 0.15, 0.05])
import_button = Button(btn_ax, '📥 Import QR File')
import_button.on_clicked(on_import_button_click)

plt.show()
input("✅ Nhấn Enter để thoát...")

```
## 📄 File: `GPT_QR_MVD.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/GPT_QR_MVD.py`

```python
import cv2
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from pyzbar.pyzbar import decode
from collections import defaultdict
import numpy as np
import matplotlib.widgets as widgets

# ======= Cài đặt khung hình DỌC =======
frame_width = 720
frame_height = 1280
total_duration = 10  # giây
frames_per_second = 2  # mỗi giây đọc 2 frame → tổng 20 frame

qr_positions = defaultdict(list)
fig, ax = plt.subplots(figsize=(6, 10))
ax.set_xlim(0, frame_width)
ax.set_ylim(0, frame_height)
ax.invert_yaxis()
qr_mvd_label = ax.text(20, 20, "", fontsize=14)

# ======= Tính quãng đường di chuyển =======
def path_length(points):
    return sum(np.linalg.norm(np.array(p2) - np.array(p1)) for p1, p2 in zip(points, points[1:]))

# ======= Ưu tiên chọn QR MVD theo path > freq =======
def get_qr_mvd_by_path(qr_positions):
    qr_paths = {
        qr: path_length(positions)
        for qr, positions in qr_positions.items()
        if len(positions) >= 1
    }
    if not qr_paths:
        return None
    max_path = max(qr_paths.values())
    candidates = [qr for qr, path in qr_paths.items() if path == max_path]
    if len(candidates) == 1:
        return candidates[0]
    return max(candidates, key=lambda qr: len(qr_positions[qr]))

# ======= Vẽ kết quả =======
def draw_qr_points():
    ax.clear()
    ax.set_xlim(0, frame_width)
    ax.set_ylim(0, frame_height)
    ax.invert_yaxis()
    colors = ['blue', 'green', 'orange', 'purple', 'brown']
    color_map = {}
    for i, (qr_data, positions) in enumerate(qr_positions.items()):
        for pt in positions:
            color = color_map.setdefault(qr_data, colors[i % len(colors)])
            ax.plot(pt[0], pt[1], 'o', color=color)
            ax.text(pt[0]+5, pt[1]-5, f"{qr_data}", fontsize=9, color=color)

    if qr_positions:
        qr_mvd = get_qr_mvd_by_path(qr_positions)
        if not qr_mvd:
            return
        pts = qr_positions[qr_mvd]
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        if xs and ys:
            x_min, x_max = min(xs), max(xs)
            y_min, y_max = min(ys), max(ys)
            ax.add_patch(patches.Rectangle((x_min, y_min), x_max - x_min, y_max - y_min,
                                           linewidth=2, edgecolor='red', facecolor='none'))
            center_x = int(np.median(xs))
            center_y = int(np.median(ys))
            ax.plot(center_x, center_y, 'rx', markersize=12)
            ax.text(center_x+5, center_y, f"({center_x},{center_y})", fontsize=10, color='red')
            qr_mvd_label.set_text(f"📌 QR MVD: {qr_mvd} – ưu tiên path")
    fig.canvas.draw()

# ======= Đọc video và nhận QR =======
def import_video_callback(event=None):
    global qr_positions
    path = input("📂 Nhập đường dẫn video: ").strip()
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        print(f"❌ Không thể mở video: {path}")
        return

    qr_positions.clear()
    fps = cap.get(cv2.CAP_PROP_FPS)
    if fps <= 0:
        print("⚠️ Không xác định được FPS của video.")
        return

    total_frames = int(fps * total_duration)
    step = int(fps / frames_per_second)
    frame_indexes = [i for i in range(0, total_frames, step)][:20]

    print(f"🎞️ Sẽ lấy {len(frame_indexes)} frame cách đều trong 10s đầu...")

    for idx in frame_indexes:
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = cap.read()
        if not ret:
            print(f"⚠️ Frame {idx} không đọc được.")
            continue

        decoded = decode(frame)
        if not decoded:
            print(f"📦 Frame {idx}: ❌ Không phát hiện QR")
        for qr in decoded:
            data = qr.data.decode("utf-8").strip()
            (x, y, w, h) = qr.rect
            cx, cy = x + w // 2, y + h // 2
            qr_positions[data].append((cx, cy))
            print(f"📦 Frame {idx}: QR {data} tại ({cx}, {cy})")

    cap.release()
    print("📊 Đã đọc xong video. Tổng số QR đã đọc:")
    for qr, pts in qr_positions.items():
        print(f"🔹 QR: {qr} – {len(pts)} lần – path: {round(path_length(pts), 1)} px")

    draw_qr_points()

    if not qr_positions:
        print("❌ Không tìm thấy QR nào.")
    else:
        qr_mvd = get_qr_mvd_by_path(qr_positions)
        if qr_mvd:
            print(f"✅ QR MVD: {qr_mvd} (ưu tiên path)")
        else:
            print("⚠️ Không xác định được QR MVD.")
    input("✅ Nhấn Enter để thoát...")

# ======= Giao diện nút =======
btn_ax = plt.axes([0.75, 0.01, 0.20, 0.05])
btn = widgets.Button(btn_ax, "📂 Import Video")
btn.on_clicked(import_video_callback)

ax.set_title("📂 QR MVD: ưu tiên path – mỗi giây 2 frame")
plt.show()

```
## 📄 File: `tailwind.config.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/tailwind.config.js`

```javascript
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        'blue-custom': '#0066CC',
        'red-custom': '#E32222',
        'gray-custom': '#3F3F3F',
        'yellow-custom': '#FFD700',
      },
    },
  },
  plugins: [],
};
```
## 📄 File: `postcss.config.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/postcss.config.js`

```javascript
module.exports = {
   plugins: {
     tailwindcss: {},
     autoprefixer: {},
   },
 };
```
## 📄 File: `reportWebVitals.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/reportWebVitals.js`

```javascript
const reportWebVitals = onPerfEntry => {
  if (onPerfEntry && onPerfEntry instanceof Function) {
    import('web-vitals').then(({ getCLS, getFID, getFCP, getLCP, getTTFB }) => {
      getCLS(onPerfEntry);
      getFID(onPerfEntry);
      getFCP(onPerfEntry);
      getLCP(onPerfEntry);
      getTTFB(onPerfEntry);
    });
  }
};

export default reportWebVitals;

```
## 📄 File: `Sidebar.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Sidebar.js`

```javascript
import { Play, Search, Settings, User } from "lucide-react";
import Title from "./Title";

const Sidebar = ({ setActiveMenu, activeMenu }) => (
  <div className="w-64 bg-black text-white min-h-screen p-4 flex flex-col font-montserrat">
    <Title text="V_TRACK UI" />
    <ul>
      {[
        { name: "Chương trình", icon: <Play className="mr-2 text-blue-custom" /> },
        { name: "Truy vấn", icon: <Search className="mr-2 text-red-custom" /> },
        { name: "Cấu hình", icon: <Settings className="mr-2 text-gray-custom" /> },
        { name: "Tài khoản", icon: <User className="mr-2 text-yellow-custom" /> },
      ].map((item) => (
        <li
          key={item.name}
          className={`flex items-center p-3 hover:bg-gray-800 cursor-pointer transition duration-300 ${
            activeMenu === item.name ? "bg-gray-800" : ""
          }`}
          onClick={() => setActiveMenu(item.name)}
        >
          {item.icon} {item.name}
        </li>
      ))}
    </ul>
  </div>
);

export default Sidebar;
```
## 📄 File: `index.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/index.js`

```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import "@fontsource/montserrat";
import "react-datepicker/dist/react-datepicker.css";

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

```
## 📄 File: `QueryComponent.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/QueryComponent.js`

```javascript
import { useState, useEffect } from "react";
import SearchModeSelector from "./components/ui/SearchModeSelector";
import FileInputSection from "./components/query/FileInputSection";
import TextInputSection from "./components/query/TextInputSection";
import TimeAndQuerySection from "./components/query/TimeAndQuerySection";
import ResultList from "./components/result/ResultList";
import VideoCutter from "./components/result/VideoCutter"; // Thay CutVideoSection bằng VideoCutter
import ColumnSelectorModal from "./components/query/ColumnSelectorModal";
import api from "./api";

const QueryComponent = () => {
  const [searchType, setSearchType] = useState("Text");
  const [path, setPath] = useState("");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [results, setResults] = useState([]);
  const [selectedVideos, setSelectedVideos] = useState([]);
  const [cutVideos, setCutVideos] = useState([]);
  const [searchString, setSearchString] = useState("");
  const [defaultDays, setDefaultDays] = useState(30);
  const [fileContent, setFileContent] = useState("");
  const [trackingCodes, setTrackingCodes] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [headers, setHeaders] = useState([]);
  const [selectedColumn, setSelectedColumn] = useState("tracking_codes");
  const [history, setHistory] = useState({
    Shopee: "Mã vận đơn",
    Lazada: "Vận đơn",
    Tiktok: "QR mã vận đơn",
    Custom1: "Custom 1",
    Custom2: "Custom 2",
  });
  const [selectedPlatform, setSelectedPlatform] = useState("Shopee");
  const [shopeeLabel, setShopeeLabel] = useState("Shopee");
  const [lazadaLabel, setLazadaLabel] = useState("Lazada");
  const [tiktokLabel, setTiktokLabel] = useState("Tiktok");
  const [customLabel1, setCustomLabel1] = useState("Custom 1");
  const [customLabel2, setCustomLabel2] = useState("Custom 2");
  const [queryCount, setQueryCount] = useState(0);
  const [trackingCodeCount, setTrackingCodeCount] = useState(0);
  const [foundCount, setFoundCount] = useState(0);
  const [isQuerying, setIsQuerying] = useState(false);
  const [selectedCameras, setSelectedCameras] = useState([]);
  const [availableCameras, setAvailableCameras] = useState([]);
  const [hasQueried, setHasQueried] = useState(false);

  useEffect(() => {
    const savedHistory = localStorage.getItem("trackingColumnHistory");
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
    const savedLabels = localStorage.getItem("platformLabels");
    if (savedLabels) {
      const labels = JSON.parse(savedLabels);
      setShopeeLabel(labels.Shopee || "Shopee");
      setLazadaLabel(labels.Lazada || "Lazada");
      setTiktokLabel(labels.Tiktok || "Tiktok");
      setCustomLabel1(labels.Custom1 || "Custom 1");
      setCustomLabel2(labels.Custom2 || "Custom 2");
    }

    const isConfigSet = localStorage.getItem("configSet");
    if (isConfigSet) {
      const fetchCameras = async () => {
        try {
          const response = await api.get("/get-cameras");
          setAvailableCameras(response.data.cameras || []);
          const savedCameras = localStorage.getItem("selectedCameras");
          if (savedCameras) {
            setSelectedCameras(JSON.parse(savedCameras));
          }
        } catch (error) {
          console.error("Error fetching cameras:", error);
        }
      };
      fetchCameras();
    }
  }, []);

  useEffect(() => {
    let count = 0;
    if (searchString) {
      const lines = searchString.split("\n");
      count = lines.filter(line => line.trim() !== "" && line.split('. ')[1]?.trim()).length;
    }
    setTrackingCodeCount(count);
  }, [searchString]);

  const debounce = (func, delay) => {
    let timeoutId;
    return (...args) => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func(...args), delay);
    };
  };

  const handleQuery = async () => {
    setIsQuerying(true);
    setHasQueried(true);
    try {
      const queryData = {
        search_string: searchString,
        default_days: defaultDays,
        from_time: startDate ? startDate.toISOString() : null,
        to_time: endDate ? endDate.toISOString() : null,
        selected_cameras: selectedCameras,
      };

      const response = await api.post("/query", queryData);
      const events = response.data.events || [];

      setResults(events);
      setSelectedVideos(events.map(event => event.event_id));
      setQueryCount(prev => prev + 1);
      setFoundCount(events.length);
    } catch (error) {
      console.error("Error in query:", error);
    } finally {
      setIsQuerying(false);
    }
  };

  const debouncedHandleQuery = debounce(handleQuery, 1000);

  const handleCameraSelection = (camera) => {
    const updatedCameras = selectedCameras.includes(camera)
      ? selectedCameras.filter((c) => c !== camera)
      : [...selectedCameras, camera];
    setSelectedCameras(updatedCameras);
    localStorage.setItem("selectedCameras", JSON.stringify(updatedCameras));
  };

  return (
    <div className="p-6 flex gap-6 w-screen h-screen">
      <div className="w-[26.67%] bg-gray-800 p-6 rounded-lg flex flex-col">
        <h1 className="text-3xl font-bold mb-4">Truy vấn</h1>
        <SearchModeSelector searchType={searchType} setSearchType={setSearchType} />
        {searchType === "File" && (
          <FileInputSection
            path={path}
            setPath={setPath}
            fileContent={fileContent}
            setFileContent={setFileContent}
            setShowModal={setShowModal}
            setHeaders={setHeaders}
          />
        )}
        <TextInputSection
          searchString={searchString}
          setSearchString={setSearchString}
          searchType={searchType}
        />
        <div className="mb-4">
          <label className="block mb-1">Truy vấn tại camera:</label>
          <div className="max-h-24 overflow-y-auto">
            {availableCameras.map((camera) => (
              <label key={camera} className="flex items-center mb-2">
                <input
                  type="checkbox"
                  checked={selectedCameras.includes(camera)}
                  onChange={() => handleCameraSelection(camera)}
                  className="mr-2"
                />
                {camera}
              </label>
            ))}
          </div>
        </div>
        <TimeAndQuerySection
          startDate={startDate}
          setStartDate={setStartDate}
          endDate={endDate}
          setEndDate={setEndDate}
          defaultDays={defaultDays}
          setDefaultDays={setDefaultDays}
          searchString={searchString}
          searchType={searchType}
          fileContent={fileContent}
          results={results}
          setResults={setResults}
          setSelectedVideos={setSelectedVideos}
          setQueryCount={setQueryCount}
          setFoundCount={setFoundCount}
          foundCount={foundCount}
          onQuery={debouncedHandleQuery}
          isQuerying={isQuerying}
        />
      </div>
      <div className="w-[53.33%] bg-gray-800 p-6 rounded-lg flex flex-col">
        <div className="flex items-center mb-4">
          <h1 className="text-3xl font-bold mr-4">Kết quả</h1>
          {(trackingCodeCount > 0 || foundCount > 0) && (
            <span className="text-lg text-gray-300">
              (Truy vấn {trackingCodeCount}/ Tìm được {foundCount})
            </span>
          )}
        </div>
        <ResultList
          results={results}
          selectedVideos={selectedVideos}
          setSelectedVideos={setSelectedVideos}
          hasQueried={hasQueried}
        />
        <VideoCutter
          results={results}
          selectedVideos={selectedVideos}
          setResults={setResults}
          setSelectedVideos={setSelectedVideos}
        /> {/* Thay CutVideoSection bằng VideoCutter */}
      </div>
      <ColumnSelectorModal
        showModal={showModal}
        setShowModal={setShowModal}
        headers={headers}
        selectedColumn={selectedColumn}
        setSelectedColumn={setSelectedColumn}
        history={history}
        setHistory={setHistory}
        selectedPlatform={selectedPlatform}
        setSelectedPlatform={setSelectedPlatform}
        shopeeLabel={shopeeLabel}
        setShopeeLabel={setShopeeLabel}
        lazadaLabel={lazadaLabel}
        setLazadaLabel={setLazadaLabel}
        tiktokLabel={tiktokLabel}
        setTiktokLabel={setTiktokLabel}
        customLabel1={customLabel1}
        setCustomLabel1={setCustomLabel1}
        customLabel2={customLabel2}
        setCustomLabel2={setCustomLabel2}
        path={path}
        fileContent={fileContent}
        setSearchString={setSearchString}
        setSearchType={setSearchType}
      />
    </div>
  );
};

export default QueryComponent;
```
## 📄 File: `Title.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Title.js`

```javascript
const Title = ({ text }) => {
   return <h2 className="text-xl font-bold text-center mb-6 tracking-widest">{text}</h2>;
 };
 
 export default Title;
```
## 📄 File: `Account.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Account.js`

```javascript
const Account = () => {
   return (
     <div className="p-6">
       <h1 className="text-3xl font-bold">Tài khoản</h1>
       <p>Đây là trang Tài khoản. Nội dung sẽ được thêm sau.</p>
     </div>
   );
 };
 
 export default Account;
```
## 📄 File: `App.test.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/App.test.js`

```javascript
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});

```
## 📄 File: `VtrackConfig.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/VtrackConfig.js`

```javascript
import React from "react"; // Thêm import React
import useVtrackConfig from "./hooks/useVtrackConfig";
import GeneralInfoForm from "./components/config/GeneralInfoForm";
import ConfigForm from "./components/config/ConfigForm";
import CameraDialog from "./components/config/CameraDialog";
import ProcessingRegionForm from "./components/config/ProcessingRegionForm"; // Thêm import

const VtrackConfig = () => {
  const {
    fromTime,
    setFromTime,
    toTime,
    setToTime,
    country,
    setCountry,
    timezone,
    setTimezone,
    brandName,
    setBrandName,
    inputPath,
    setInputPath,
    outputPath,
    setOutputPath,
    workingDays,
    setWorkingDays,
    defaultDays,
    setDefaultDays,
    minPackingTime,
    setMinPackingTime,
    maxPackingTime,
    setMaxPackingTime,
    frameRate,
    setFrameRate,
    frameInterval,
    setFrameInterval,
    videoBuffer,
    setVideoBuffer,
    cameras,
    setCameras,
    selectedCameras,
    setSelectedCameras,
    showCameraDialog,
    setShowCameraDialog,
    error,
    setError,
    handleCountryChange,
    handleFromTimeChange,
    handleToTimeChange,
    handleWorkingDayChange,
    handleOpenExplorer,
    handleSaveGeneralInfo,
    handleSaveConfig,
    handleShowCameraDialog,
    handleCameraSelection,
    runDefaultOnStart,
    setRunDefaultOnStart,
  } = useVtrackConfig();

  // Thêm state cho ProcessingRegionForm
  const [videoPath, setVideoPath] = React.useState("");
  const [qrSize, setQrSize] = React.useState("");
  const handleAnalyzeRegions = () => {
    // Hàm tạm thời cho Bước 1
    console.log("Phân tích vùng:", videoPath, qrSize);
  };

  const countries = [
    "Việt Nam", "Nhật Bản", "Hàn Quốc", "Thái Lan", "Singapore",
    "Mỹ", "Anh", "Pháp", "Đức", "Úc"
  ];

  return (
    <div className="p-6 flex gap-6 w-[100%]">
      <GeneralInfoForm
        country={country}
        setCountry={setCountry}
        timezone={timezone}
        setTimezone={setTimezone}
        brandName={brandName}
        setBrandName={setBrandName}
        workingDays={workingDays}
        setWorkingDays={setWorkingDays}
        fromTime={fromTime}
        setFromTime={setFromTime}
        toTime={toTime}
        setToTime={setToTime}
        handleCountryChange={handleCountryChange}
        handleFromTimeChange={handleFromTimeChange}
        handleToTimeChange={handleToTimeChange}
        handleWorkingDayChange={handleWorkingDayChange}
        handleSaveGeneralInfo={handleSaveGeneralInfo}
        countries={countries}
      />
      <ConfigForm
        inputPath={inputPath}
        setInputPath={setInputPath}
        outputPath={outputPath}
        setOutputPath={setOutputPath}
        defaultDays={defaultDays}
        setDefaultDays={setDefaultDays}
        minPackingTime={minPackingTime}
        setMinPackingTime={setMinPackingTime}
        maxPackingTime={maxPackingTime}
        setMaxPackingTime={setMaxPackingTime}
        frameRate={frameRate}
        setFrameRate={setFrameRate}
        frameInterval={frameInterval}
        setFrameInterval={setFrameInterval}
        videoBuffer={videoBuffer}
        setVideoBuffer={setVideoBuffer}
        error={error}
        handleOpenExplorer={handleOpenExplorer}
        handleShowCameraDialog={handleShowCameraDialog}
        runDefaultOnStart={runDefaultOnStart}
        setRunDefaultOnStart={setRunDefaultOnStart}
      />
      <ProcessingRegionForm // Thêm component
        videoPath={videoPath}
        setVideoPath={setVideoPath}
        qrSize={qrSize}
        setQrSize={setQrSize}
        handleAnalyzeRegions={handleAnalyzeRegions}
      />
      <CameraDialog
        showCameraDialog={showCameraDialog}
        setShowCameraDialog={setShowCameraDialog}
        cameras={cameras}
        selectedCameras={selectedCameras}
        handleCameraSelection={handleCameraSelection}
        handleSaveConfig={handleSaveConfig}
      />
    </div>
  );
};

export default VtrackConfig;
```
## 📄 File: `Dashboard.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/Dashboard.js`

```javascript
import Sidebar from "./Sidebar";
import VtrackConfig from "./VtrackConfig";
import QueryComponent from "./QueryComponent";
import Account from "./Account";
import ProgramTab from "./components/program/ProgramTab";
import useProgramLogic from "./hooks/useProgramLogic";

const Dashboard = ({ setActiveMenu, activeMenu }) => {
  const {
    runningCard,
    fileList,
    customPath,
    showConfirmButton,
    firstRunCompleted,
    handleRunStop,
    handleConfirmRun,
    isRunning,
    setCustomPath,
  } = useProgramLogic();

  return (
    <div className="flex min-h-screen bg-gray-900 text-white font-montserrat">
      <Sidebar setActiveMenu={setActiveMenu} activeMenu={activeMenu} />
      <div className="flex-1 p-6 w-full">
        {activeMenu === "Chương trình" ? (
          <ProgramTab
            runningCard={runningCard}
            fileList={fileList}
            customPath={customPath}
            showConfirmButton={showConfirmButton}
            firstRunCompleted={firstRunCompleted}
            handleRunStop={handleRunStop}
            handleConfirmRun={handleConfirmRun}
            isRunning={isRunning}
            setCustomPath={setCustomPath}
          />
        ) : activeMenu === "Cấu hình" ? (
          <VtrackConfig />
        ) : activeMenu === "Truy vấn" ? (
          <QueryComponent />
        ) : activeMenu === "Tài khoản" ? (
          <Account />
        ) : (
          <div>
            <h1 className="text-3xl font-bold">Đang phát triển: {activeMenu}</h1>
            <p>Nội dung cho {activeMenu} sẽ được thêm sau.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
```
## 📄 File: `api.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/api.js`

```javascript
import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8080",
});

export const getConfig = () => api.get("/config");
export const updateConfig = (configData) => api.post("/config", configData);
export const runQuery = (queryData) => api.post("/query", queryData);
export const runProgram = (programData) => api.post("/program", programData);
export const confirmRun = (confirmData) => api.post("/confirm-run", confirmData);
export const getCameras = () => api.get("/get-cameras");
export const cutVideos = (cutData) => api.post("/cut-videos", cutData); // Thêm hàm gọi endpoint /cut-videos
export const analyzeRegions = (data) => api.post("/analyze-regions", data);

export default api;
```
## 📄 File: `setupTests.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/setupTests.js`

```javascript
// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';

```
## 📄 File: `App.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/App.js`

```javascript
import "@fontsource/montserrat";
import { useState } from "react";
import Dashboard from "./Dashboard";

function App() {
  const [activeMenu, setActiveMenu] = useState("Chương trình");
  return (
    <div className="flex min-h-screen bg-gray-900 text-white font-montserrat">
      <Dashboard setActiveMenu={setActiveMenu} activeMenu={activeMenu} />
    </div>
  );
}

export default App;
```
## 📄 File: `SearchModeSelector.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/ui/SearchModeSelector.js`

```javascript
const SearchModeSelector = ({ searchType, setSearchType }) => {
  return (
    <div className="mb-4">
      <label className="block mb-1">Loại tìm kiếm:</label>
      <div className="flex gap-4">
        <label className="flex items-center">
          <input
            type="radio"
            name="searchType"
            value="File"
            className="mr-1"
            checked={searchType === "File"}
            onChange={() => setSearchType("File")}
          />
          File
        </label>
        <label className="flex items-center">
          <input
            type="radio"
            name="searchType"
            value="Text"
            className="mr-1"
            checked={searchType === "Text"}
            onChange={() => setSearchType("Text")}
          />
          Text
        </label>
      </div>
    </div>
  );
};

export default SearchModeSelector;
```
## 📄 File: `Button.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/ui/Button.js`

```javascript
const Button = ({ text }) => {
   return (
     <button className="bg-red-600 text-white font-bold py-2 px-4 rounded mt-4">
       {text}
     </button>
   );
 };
 
 export default Button;
```
## 📄 File: `Card.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/ui/Card.js`

```javascript
// Card.js
import { useState } from "react";

const Card = ({ title, description, isRunning, onRunStop, onPathChange, isLocked }) => {
  const [path, setPath] = useState("");

  const handleOpenExplorer = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.webkitdirectory = title === "Chỉ định" && document.querySelector('input[name="type"]:checked')?.value === "Folder";
    input.onchange = (e) => {
      const selectedPath = e.target.files[0]?.webkitRelativePath || e.target.files[0]?.name || "";
      setPath(selectedPath);
      if (onPathChange) {
        onPathChange(selectedPath);
      }
    };
    input.click();
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg flex flex-col items-center h-full">
      <h3 className="text-lg font-bold mb-2">{title}</h3>
      <p className="mb-4 text-center flex-1">{description}</p>
      <div className="mt-auto w-full flex flex-col items-center">
        {title === "Chỉ định" && (
          <div className="mb-4 w-full">
            <div className="flex justify-center gap-4 mb-2">
              <label className="flex items-center">
                <input type="radio" name="type" value="Folder" className="mr-1" defaultChecked />
                Folder
              </label>
              <label className="flex items-center">
                <input type="radio" name="type" value="File" className="mr-1" />
                File
              </label>
            </div>
            <div className="relative w-full">
              <input
                type="text"
                value={path}
                onChange={(e) => {
                  setPath(e.target.value);
                  if (onPathChange) {
                    onPathChange(e.target.value);
                  }
                }}
                placeholder="Nhập đường dẫn..."
                className="w-full p-2 rounded bg-gray-700 text-white"
              />
              <button
                type="button"
                onClick={handleOpenExplorer}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
              >
                ...
              </button>
            </div>
          </div>
        )}
        {isLocked || (title === "Lần đầu" && isRunning) ? (
          <button
            className="w-1/2 py-2 px-4 rounded font-bold text-white bg-gray-500"
            disabled
          >
            LOCKED
          </button>
        ) : (
          <button
            className={`w-1/2 py-2 px-4 rounded font-bold text-white ${
              isRunning && title !== "Lần đầu" ? "bg-[#E82127]" : "bg-[#00D4FF]"
            }`}
            onClick={onRunStop}
            disabled={title === "Chỉ định" && !path && !isRunning} // Vô hiệu hóa nếu chưa có đường dẫn
          >
            {(isRunning && title !== "Lần đầu") ? "STOP" : "RUN"}
          </button>
        )}
      </div>
    </div>
  );
};

export default Card;
```
## 📄 File: `ResultList.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/result/ResultList.js`

```javascript
import React from "react";

const ResultList = ({ results, selectedVideos, setSelectedVideos, hasQueried }) => {
  const handleSelectVideo = (eventId) => {
    if (selectedVideos.includes(eventId)) {
      setSelectedVideos(selectedVideos.filter((id) => id !== eventId));
    } else {
      setSelectedVideos([...selectedVideos, eventId]);
    }
  };

  React.useEffect(() => {
    if (results.length > 0) {
      const newSelectedVideos = results.map(event => event.event_id);
      setSelectedVideos(newSelectedVideos);
    }
  }, [results]);

  return (
    <div className="flex-1 mb-4 bg-gray-700 rounded p-2 overflow-y-auto">
      {hasQueried ? (
        results.length > 0 ? (
          results.map((event, index) => (
            <label key={event.event_id} className="flex items-center mb-2">
              <input
                type="checkbox"
                className="mr-2"
                checked={selectedVideos.includes(event.event_id)}
                onChange={() => handleSelectVideo(event.event_id)}
              />
              {`${index + 1}. ${event.video_file}`}
            </label>
          ))
        ) : (
          <p>Không có kết quả</p>
        )
      ) : (
        <p>Vui lòng thực hiện truy vấn</p>
      )}
    </div>
  );
};

export default ResultList;

```
## 📄 File: `CutVideoSection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/result/CutVideoSection.js`

```javascript
import api from "../../api"; // Thêm import api để gọi /cut-videos

const CutVideoSection = ({ results, selectedVideos, setResults, setSelectedVideos, cutVideos, setCutVideos }) => {
  const handleCutVideos = async () => {
    if (selectedVideos.length === 0) {
      alert("Vui lòng chọn ít nhất một sự kiện để cắt video.");
      return;
    }
    const videosToCut = results.filter((event) => selectedVideos.includes(event.event_id));
    try {
      const cutData = {
        selected_events: videosToCut,
      };
      const response = await api.post("/cut-videos", cutData); // Gọi API /cut-videos
      const cutFiles = response.data.cut_files || []; // Lấy danh sách file từ phản hồi
      setCutVideos(prev => [...prev, ...cutFiles]); // Tối ưu với prev
      setResults(results.filter((event) => !selectedVideos.includes(event.event_id)));
      setSelectedVideos([]);
    } catch (error) {
      console.error("Error cutting videos:", error);
      alert("Có lỗi xảy ra khi cắt video. Vui lòng thử lại.");
    }
  };

  const handleRefresh = () => {
    setResults([]);
    setSelectedVideos([]);
    setCutVideos([]); // Xóa danh sách video đã cắt
  };

  return (
    <>
      <div className="flex gap-4 mb-4">
        <button
          className="w-1/2 py-2 bg-red-600 text-white font-bold rounded"
          onClick={handleCutVideos}
        >
          Cắt Video
        </button>
        <button
          className="w-1/2 py-2 px-4 rounded font-bold text-white bg-[#00D4FF]"
          onClick={handleRefresh}
        >
          Refresh
        </button>
      </div>
      <div className="flex-1 bg-gray-700 rounded p-2 overflow-y-auto">
        {cutVideos.map((video, index) => (
          <label key={index} className="flex items-center mb-2">
            <input type="checkbox" className="mr-2" />
            {`${index + 1}. ${video}`}
          </label>
        ))}
      </div>
    </>
  );
};

export default CutVideoSection;
```
## 📄 File: `VideoCutter.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/result/VideoCutter.js`

```javascript
import { useState } from "react";
import api from "../../api"; // Điều chỉnh đường dẫn tương đối từ thư mục result

const VideoCutter = ({ results, selectedVideos, setResults, setSelectedVideos }) => {
  const [cutVideos, setCutVideos] = useState([]);
  const [selectedCutVideo, setSelectedCutVideo] = useState(null); // Thêm trạng thái để lưu video đã cắt được chọn

  // Hàm xử lý yêu cầu cắt video
  const handleCutVideos = async () => {
    if (selectedVideos.length === 0) {
      alert("Vui lòng chọn ít nhất một sự kiện để cắt video.");
      return;
    }
    try {
      const selectedEvents = results.filter(event => selectedVideos.includes(event.event_id));
      const cutData = {
        selected_events: selectedEvents,
        // tracking_codes_filter sẽ được thêm sau nếu cần từ QueryComponent
      };

      const response = await api.post("/cut-videos", cutData); // Gọi API cắt video
      const cutFiles = response.data.cut_files || [];

      setCutVideos(prev => [...prev, ...cutFiles]); // Cập nhật danh sách video đã cắt
      setResults(prev => prev.filter(event => !selectedVideos.includes(event.event_id))); // Xóa sự kiện đã cắt
      setSelectedVideos([]); // Reset danh sách chọn
    } catch (error) {
      console.error("Error cutting videos:", error);
      alert("Có lỗi xảy ra khi cắt video. Vui lòng thử lại.");
    }
  };

  const handleRefresh = () => {
    setResults([]);
    setSelectedVideos([]);
    setCutVideos([]);
    setSelectedCutVideo(null); // Reset video đã chọn khi refresh
  };

  // Hàm xử lý khi nhấn nút "Play Video"
  const handlePlayVideo = () => {
    if (!selectedCutVideo) {
      alert("Vui lòng chọn một video để phát");
      return;
    }
    alert(`Đang phát video "${selectedCutVideo}" được chọn`);
  };

  return (
    <>
      <div className="flex gap-4 mb-4">
        <button
          className="w-1/3 py-2 bg-red-600 text-white font-bold rounded"
          onClick={handleCutVideos}
        >
          Cắt Video
        </button>
        <button
          className="w-1/3 py-2 px-4 rounded font-bold text-white bg-[#00D4FF]"
          onClick={handleRefresh}
        >
          Refresh
        </button>
        <button
          className="w-1/3 py-2 px-4 rounded font-bold text-white bg-green-600"
          onClick={handlePlayVideo}
        >
          Play Video
        </button>
      </div>
      <div className="flex-1 bg-gray-700 rounded p-2 overflow-y-auto">
        {cutVideos.map((video, index) => (
          <label
            key={index}
            className="flex items-center mb-2 cursor-pointer hover:bg-gray-600 transition duration-300"
            onClick={() => setSelectedCutVideo(video)}
          >
            <input
              type="radio"
              name="cutVideo"
              className="mr-2"
              checked={selectedCutVideo === video}
              onChange={() => setSelectedCutVideo(video)}
            />
            <span className="flex-1 truncate">{`${index + 1}. ${video}`}</span>
          </label>
        ))}
      </div>
    </>
  );
};

export default VideoCutter;
```
## 📄 File: `ConfigForm.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/ConfigForm.js`

```javascript
const ConfigForm = ({
  inputPath,
  setInputPath,
  outputPath,
  setOutputPath,
  defaultDays,
  setDefaultDays,
  minPackingTime,
  setMinPackingTime,
  maxPackingTime,
  setMaxPackingTime,
  frameRate,
  setFrameRate,
  frameInterval,
  setFrameInterval,
  videoBuffer,
  setVideoBuffer,
  error,
  handleOpenExplorer,
  handleShowCameraDialog,
}) => {
  return (
    <div className="w-[25%] bg-gray-800 p-6 rounded-lg flex flex-col">
      <h1 className="text-3xl font-bold mb-4">Cấu hình</h1>
      {error && <div style={{ color: 'red' }}>{error}</div>}
      <div className="mb-4">
        <label className="block mb-1">Vị trí Input Video:</label>
        <div className="relative w-full">
          <input
            type="text"
            value={inputPath}
            onChange={(e) => setInputPath(e.target.value)}
            placeholder="Vị trí Input Video (e.g., /Users/annhu/vtrack_app/V_Track/Inputvideo)"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
          <button
            type="button"
            onClick={() => handleOpenExplorer("input")}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
          >
            ...
          </button>
        </div>
      </div>
      <div className="mb-4">
        <label className="block mb-1">Vị trí Output Video:</label>
        <div className="relative w-full">
          <input
            type="text"
            value={outputPath}
            onChange={(e) => setOutputPath(e.target.value)}
            placeholder="Vị trí Output Video (e.g., /Users/annhu/vtrack_app/V_Track/output_clips)"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
          <button
            type="button"
            onClick={() => handleOpenExplorer("output")}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
          >
            ...
          </button>
        </div>
      </div>
      <div className="flex flex-col gap-4 mb-4">
        <div>
          <label className="block mb-1">Thời gian lưu trữ (ngày):</label>
          <input
            type="number"
            value={defaultDays}
            onChange={(e) => setDefaultDays(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Thời gian đóng hàng nhanh nhất (giây):</label>
          <input
            type="number"
            value={minPackingTime}
            onChange={(e) => setMinPackingTime(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Thời gian đóng hàng chậm nhất (giây):</label>
          <input
            type="number"
            value={maxPackingTime}
            onChange={(e) => setMaxPackingTime(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Tốc độ frame:</label>
          <input
            type="number"
            value={frameRate}
            onChange={(e) => setFrameRate(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Khoảng cách Frame:</label>
          <input
            type="number"
            value={frameInterval}
            onChange={(e) => setFrameInterval(Number(e.target.value))}
            min="2"
            max="30"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div>
          <label className="block mb-1">Buffer Video (giây):</label>
          <input
            type="number"
            value={videoBuffer}
            onChange={(e) => setVideoBuffer(Number(e.target.value))}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
      </div>
      <div className="mt-auto flex justify-center">
        <button
          onClick={handleShowCameraDialog}
          className="w-1/2 py-2 bg-blue-600 text-white font-bold rounded"
        >
          Gửi
        </button>
      </div>
    </div>
  );
};

export default ConfigForm;
```
## 📄 File: `GeneralInfoForm.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/GeneralInfoForm.js`

```javascript
import DatePicker from "react-datepicker";

const GeneralInfoForm = ({
  country,
  setCountry,
  timezone,
  setTimezone,
  brandName,
  setBrandName,
  workingDays,
  setWorkingDays,
  fromTime,
  setFromTime,
  toTime,
  setToTime,
  handleCountryChange,
  handleFromTimeChange,
  handleToTimeChange,
  handleWorkingDayChange,
  handleSaveGeneralInfo,
  countries,
}) => {
  return (
    <div className="w-[25%] bg-gray-800 p-6 rounded-lg flex flex-col">
      <h1 className="text-3xl font-bold mb-4">Thông tin chung</h1>
      <div className="mb-4">
        <label className="block mb-1">Quốc gia:</label>
        <select
          value={country}
          onChange={handleCountryChange}
          className="w-full p-2 rounded bg-gray-700 text-white"
        >
          {countries.map((country) => (
            <option key={country} value={country}>
              {country}
            </option>
          ))}
        </select>
      </div>
      <div className="mb-4">
        <label className="block mb-1">Múi giờ:</label>
        <input
          type="text"
          value={timezone}
          readOnly
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <div className="mb-4">
        <label className="block mb-1">Tên thương hiệu:</label>
        <input
          type="text"
          value={brandName}
          onChange={(e) => setBrandName(e.target.value)}
          placeholder="Nhập tên thương hiệu"
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <div className="mb-4">
        <h3 className="text-lg font-bold mb-2">Ngày làm việc</h3>
        {["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"].map((day) => (
          <label key={day} className="flex items-center mb-2">
            <input
              type="checkbox"
              className="mr-2"
              onChange={() => handleWorkingDayChange(day)}
              checked={workingDays.includes(day)}
            />
            {day}
          </label>
        ))}
      </div>
      <div className="mb-4">
        <h3 className="text-lg font-bold mb-2">Thời gian làm việc</h3>
        <div className="flex gap-4">
          <div className="flex-1">
            <label className="block mb-1">Từ:</label>
            <DatePicker
              selected={fromTime}
              onChange={handleFromTimeChange}
              showTimeSelect
              showTimeSelectOnly
              timeIntervals={30}
              timeCaption="Giờ"
              dateFormat="HH:mm"
              className="w-full p-2 rounded bg-gray-700 text-white"
            />
          </div>
          <div className="flex-1">
            <label className="block mb-1">Đến:</label>
            <DatePicker
              selected={toTime}
              onChange={handleToTimeChange}
              showTimeSelect
              showTimeSelectOnly
              timeIntervals={30}
              timeCaption="Giờ"
              dateFormat="HH:mm"
              className="w-full p-2 rounded bg-gray-700 text-white"
            />
          </div>
        </div>
      </div>
      <div className="mt-auto flex justify-center">
        <button
          onClick={handleSaveGeneralInfo}
          className="w-1/2 py-2 bg-blue-600 text-white font-bold rounded"
        >
          Gửi
        </button>
      </div>
    </div>
  );
};

export default GeneralInfoForm;
```
## 📄 File: `ProcessingRegionForm.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/ProcessingRegionForm.js`

```javascript
import { useState } from "react";
import api from "../../api";

const ProcessingRegionForm = ({ handleAnalyzeRegions }) => {
  const [videoPath, setVideoPath] = useState("");
  const [qrSize, setQrSize] = useState("");
  const [error, setError] = useState("");
  const [analysisResult, setAnalysisResult] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const validateInputs = () => {
    if (!videoPath) {
      setError("Vui lòng chọn video baseline.");
      return false;
    }
    if (!qrSize || qrSize <= 0) {
      setError("Kích thước QR Timego phải lớn hơn 0.");
      return false;
    }
    setError("");
    return true;
  };

  const handleClickAnalyze = async () => {
    if (validateInputs()) {
      setIsAnalyzing(true);
      try {
        const response = await api.post("/analyze-regions", { video_path: videoPath, qr_size: qrSize }); // Điều chỉnh: Sử dụng api.post thay vì api.analyzeRegions
        setAnalysisResult(response.data);
      } catch (err) {
        setAnalysisResult({ success: false, message: "Lỗi khi gọi API phân tích." });
      } finally {
        setIsAnalyzing(false);
      }
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      setVideoPath(e.target.files[0]?.webkitRelativePath || e.target.files[0]?.name || ""); // Giữ nguyên: Chỉ lấy tên file để gửi lên backend
      setError("");
    } else {
      setVideoPath("");
    }
  };

  return (
    <div className="w-[25%] bg-gray-800 p-6 rounded-lg flex flex-col">
      <h1 className="text-3xl font-bold mb-4">Vùng xử lý</h1>
      <p className="text-gray-300 mb-4">
        Tải lên video baseline (5s-1 phút) để xác định các vùng xử lý QR và đóng gói.
      </p>
      <div className="mb-4">
        <label className="block mb-1">Video baseline:</label>
        <div className="relative w-full">
          <input
            type="text"
            value={videoPath}
            onChange={(e) => setVideoPath(e.target.value)}
            placeholder="Chọn video (e.g., /Users/annhu/vtrack_app/V_Track/baseline.mp4)"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
          <button
            type="button"
            onClick={() => {
              const input = document.createElement("input");
              input.type = "file";
              input.accept = "video/*";
              input.onchange = handleFileSelect;
              input.click();
            }}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
          >
            ...
          </button>
        </div>
      </div>
      <div className="mb-4">
        <label className="block mb-1">Kích thước QR Timego (cm):</label>
        <input
          type="number"
          value={qrSize}
          onChange={(e) => {
            setQrSize(Number(e.target.value));
            setError("");
          }}
          placeholder="Nhập kích thước cạnh QR (cm)"
          className="w-full p-2 rounded bg-gray-700 text-white"
          min="0"
          step="0.1"
        />
        <p className="text-sm text-gray-400 mt-1">
          Đo chiều dài cạnh của QR Timego in trên tờ A4 (cm).
        </p>
      </div>
      {error && (
        <div className="mb-4 text-red-500 text-sm">{error}</div>
      )}
      <div className="mb-4">
        <h3 className="text-lg font-bold mb-2">Hướng dẫn:</h3>
        <ul className="list-disc pl-5 text-gray-300">
          <li>In 2 tờ A4 chứa mã QR Timego từ hệ thống.</li>
          <li>Đặt tờ thứ nhất ở vị trí trung tâm khung hình (QR Trigger).</li>
          <li>Đặt tờ thứ hai ở vị trí đặt mã vận đơn (QR mã vận đơn).</li>
          <li>Ghi video baseline bàn làm việc tiêu chuẩn với cả hai mã QR rõ ràng.</li>
        </ul>
      </div>
      {analysisResult && (
        <div className="mb-4">
          <h3 className="text-lg font-bold mb-2">Kết quả:</h3>
          <div className={`text-sm ${analysisResult.success ? "text-green-500" : "text-red-500"}`}>
            {analysisResult.success
              ? "Đã xác định vùng QR Trigger, mã vận đơn, đóng gói."
              : "Không tìm thấy QR, kiểm tra video."}
          </div>
        </div>
      )}
      <div className="mt-auto flex justify-center">
        <button
          onClick={handleClickAnalyze}
          disabled={!videoPath || !qrSize || isAnalyzing}
          className={`w-1/2 py-2 text-white font-bold rounded ${
            !videoPath || !qrSize || isAnalyzing ? "bg-gray-500 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-700"
          }`}
        >
          Phân tích
        </button>
      </div>
    </div>
  );
};

export default ProcessingRegionForm;
```
## 📄 File: `CameraDialog.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/config/CameraDialog.js`

```javascript
const CameraDialog = ({
  showCameraDialog,
  setShowCameraDialog,
  cameras,
  selectedCameras,
  handleCameraSelection,
  handleSaveConfig,
}) => {
  if (!showCameraDialog) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-gray-800 p-6 rounded-lg w-1/2">
        <h2 className="text-2xl font-bold mb-4 text-white">Xác nhận camera</h2>
        <div className="max-h-64 overflow-y-auto">
          {cameras.map((camera) => (
            <label key={camera.name} className="flex items-center mb-2 text-white">
              <input
                type="checkbox"
                className="mr-2"
                checked={selectedCameras.includes(camera.name)}
                onChange={() => handleCameraSelection(camera.name)}
              />
              {camera.name} ({camera.path})
            </label>
          ))}
        </div>
        <div className="mt-4 flex justify-end gap-4">
          <button
            onClick={() => setShowCameraDialog(false)}
            className="py-2 px-4 bg-gray-600 text-white font-bold rounded"
          >
            Hủy
          </button>
          <button
            onClick={handleSaveConfig}
            className="py-2 px-4 bg-blue-600 text-white font-bold rounded"
          >
            Xác nhận
          </button>
        </div>
      </div>
    </div>
  );
};

export default CameraDialog;
```
## 📄 File: `FileList.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/program/FileList.js`

```javascript
const FileList = ({ fileList }) => {
  if (!fileList || fileList.length === 0) {
    return (
      <div className="mt-4">
        <h3 className="text-lg font-bold">Kết quả:</h3>
        <p>Không có file nào để hiển thị.</p>
      </div>
    );
  }

  return (
    <div className="mt-4">
      <h3 className="text-lg font-bold">Kết quả:</h3>
      <ul className="list-disc pl-5">
        {fileList.map((item, index) => (
          <li key={index}>{`${item.file}: ${item.status}`}</li>
        ))}
      </ul>
    </div>
  );
};

export default FileList;
```
## 📄 File: `ProgramTab.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/program/ProgramTab.js`

```javascript
import { useState, useEffect } from "react"; // Thêm useState và useEffect
import Card from "../ui/Card";
import FileList from "./FileList";

const ProgramTab = ({
  runningCard,
  fileList,
  customPath,
  showConfirmButton,
  firstRunCompleted,
  handleRunStop,
  handleConfirmRun,
  isRunning,
  setCustomPath,
}) => {
  const [updatedFileList, setUpdatedFileList] = useState(fileList); // State để lưu danh sách file cập nhật

  // Cập nhật tự động mỗi 10 giây trong 2 phút
  useEffect(() => {
    const fetchProgress = async () => {
      try {
        const response = await fetch("http://localhost:8080/program-progress", {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        });
        const data = await response.json();
        if (response.ok) {
          setUpdatedFileList(data.files); // Cập nhật danh sách file từ API
        } else {
          console.error("Failed to fetch program progress:", data.error);
        }
      } catch (error) {
        console.error("Error fetching program progress:", error);
      }
    };

    fetchProgress(); // Gọi lần đầu ngay khi component mount
    const intervalId = setInterval(fetchProgress, 10000); // Gọi lại mỗi 10 giây
    const timeoutId = setTimeout(() => {
      clearInterval(intervalId); // Dừng polling sau 2 phút
      console.log("Stopped polling /program-progress after 2 minutes");
    }, 120000); // 120 giây = 2 phút

    return () => {
      clearInterval(intervalId); // Dọn dẹp interval
      clearTimeout(timeoutId); // Dọn dẹp timeout
    };
  }, [runningCard]); // Chạy lại khi runningCard thay đổi

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-3 gap-6">
        {!firstRunCompleted && (
          <Card
            title="Lần đầu"
            description="Chạy lần đầu để xử lý dữ liệu cơ sở."
            isRunning={isRunning("Lần đầu")}
            onRunStop={firstRunCompleted ? null : () => handleRunStop("Lần đầu")}
            isLocked={firstRunCompleted}
          />
        )}
        <Card
          title="Mặc định"
          description="Chạy khi khởi động, chạy nền."
          isRunning={isRunning("Mặc định")} // Đảm bảo hiển thị STOP khi chạy mặc định
          onRunStop={() => handleRunStop("Mặc định")}
        />
        <Card
          title="Chỉ định"
          description="Chỉ định folder/file cụ thể."
          isRunning={isRunning("Chỉ định")}
          onRunStop={() => handleRunStop("Chỉ định", customPath)}
          onPathChange={(path) => setCustomPath(path)}
        />
      </div>
      {showConfirmButton && (
        <div className="flex justify-center">
          <button
            className="py-2 px-4 bg-green-600 text-white font-bold rounded"
            onClick={handleConfirmRun}
          >
            Chạy chương trình
          </button>
        </div>
      )}
      <FileList fileList={updatedFileList} /> {/* Dùng updatedFileList thay vì fileList */}
    </div>
  );
};

export default ProgramTab;
```
## 📄 File: `TextInputSection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/TextInputSection.js`

```javascript
const TextInputSection = ({ searchString, setSearchString, searchType }) => {
  const handleTextInputChange = (e) => {
    const value = e.target.value;
    const lines = value.split("\n");
    const codes = [];
    
    lines.forEach(line => {
      const trimmedLine = line.trim();
      if (!trimmedLine) return;
      const match = trimmedLine.match(/^\d+\.\s*(.+)$/);
      const lineContent = match ? match[1].trim() : trimmedLine;
      const lineCodes = lineContent.split(";").map(code => code.trim()).filter(code => code);
      codes.push(...lineCodes);
    });

    let formattedCodes = codes
      .map((code, index) => `${index + 1}. ${code}`)
      .join("\n");

    if (value.endsWith("\n")) {
      formattedCodes += `\n${codes.length + 1}. `;
    }

    setSearchString(formattedCodes);
  };

  return (
    <textarea
      value={searchString}
      onChange={handleTextInputChange}
      placeholder="Nhập chuỗi tìm kiếm (mỗi mã trên một dòng)"
      className="w-full p-2 mb-4 rounded bg-gray-700 text-white h-1/2 overflow-y-auto whitespace-pre-wrap resize-none"
      disabled={searchType === "File"}
    />
  );
};

export default TextInputSection;
```
## 📄 File: `TimeAndQuerySection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/TimeAndQuerySection.js`

```javascript
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const TimeAndQuerySection = ({
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  defaultDays,
  setDefaultDays,
  searchString,
  searchType,
  fileContent,
  results,
  setResults,
  setSelectedVideos,
  setQueryCount,
  setFoundCount,
  foundCount,
  onQuery, // Prop để nhận hàm debounce từ QueryComponent
  isQuerying, // Prop để vô hiệu hóa nút
}) => {
  const handleStartDateChange = (date) => {
    setStartDate(date);
    if (endDate) {
      const diffDays = (endDate - date) / (1000 * 60 * 60 * 24);
      if (diffDays > 30) {
        setEndDate(new Date(date.getTime() + 30 * 24 * 60 * 60 * 1000));
      } else if (date > endDate) {
        setEndDate(date);
      }
    }
  };

  const handleEndDateChange = (date) => {
    const today = new Date();
    if (date > today) {
      date = today;
    }
    if (startDate) {
      const diffDays = (date - startDate) / (1000 * 60 * 60 * 24);
      if (diffDays > 30) {
        setStartDate(new Date(date.getTime() - 30 * 24 * 60 * 60 * 1000));
      } else if (date < startDate) {
        setStartDate(date);
      }
    }
    setEndDate(date);
  };

  return (
    <>
      <div className="mb-4">
        <label className="block mb-1">Thời gian mặc định (ngày):</label>
        <input
          type="number"
          value={defaultDays}
          onChange={(e) => setDefaultDays(Number(e.target.value))}
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <div className="flex gap-4 mb-4">
        <div className="flex-1">
          <label className="block mb-1">Từ:</label>
          <DatePicker
            selected={startDate}
            onChange={handleStartDateChange}
            showTimeSelect
            timeIntervals={60}
            dateFormat="Pp"
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
        <div className="flex-1">
          <label className="block mb-1">Đến:</label>
          <DatePicker
            selected={endDate}
            onChange={handleEndDateChange}
            showTimeSelect
            timeIntervals={60}
            dateFormat="Pp"
            maxDate={new Date()}
            className="w-full p-2 rounded bg-gray-700 text-white"
          />
        </div>
      </div>
      <button
        onClick={onQuery} // Dùng onQuery từ props
        disabled={isQuerying} // Vô hiệu hóa nút khi đang xử lý
        className={`w-full py-2 bg-green-600 text-white font-bold rounded ${isQuerying ? "opacity-50 cursor-not-allowed" : ""}`}
      >
        Truy vấn
      </button>
    </>
  );
};

export default TimeAndQuerySection;
```
## 📄 File: `FileInputSection.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/FileInputSection.js`

```javascript
const FileInputSection = ({ path, setPath, fileContent, setFileContent, setShowModal, setHeaders }) => {
  const handleOpenExplorer = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".csv,.xlsx";
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const fileName = file.name.toLowerCase();
      const fileType = file.type;

      // Kiểm tra đuôi file
      if (!fileName.endsWith(".csv") && !fileName.endsWith(".xlsx")) {
        alert("Vui lòng chọn file CSV hoặc Excel (.csv, .xlsx)");
        return;
      }

      // Kiểm tra MIME type
      const validCsvMimeTypes = ["text/csv", "application/csv"];
      const validXlsxMimeTypes = [
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-excel",
      ];
      if (fileName.endsWith(".csv") && !validCsvMimeTypes.includes(fileType)) {
        alert("File không đúng định dạng CSV. Vui lòng chọn file CSV hợp lệ.");
        return;
      }
      if (fileName.endsWith(".xlsx") && !validXlsxMimeTypes.includes(fileType)) {
        alert("File không đúng định dạng Excel. Vui lòng chọn file XLSX hợp lệ.");
        return;
      }

      setPath(file.name);

      const reader = new FileReader();
      reader.onload = (event) => {
        const arrayBuffer = event.target.result;
        const bytes = new Uint8Array(arrayBuffer);
        const binary = Array.from(bytes).map((b) => String.fromCharCode(b)).join("");
        const base64 = btoa(binary); // Base64 encode từ nhị phân
        setFileContent(base64);
      };
      reader.onerror = () => {
        alert("Lỗi khi đọc file");
      };
      reader.readAsArrayBuffer(file); // Đọc raw binary
    };
    input.click();
  };

  const handleConfirmFile = async () => {
    if (!path) {
      alert("Vui lòng chọn file CSV hoặc nhập đường dẫn");
      return;
    }
    try {
      const response = await fetch("http://localhost:8080/get-csv-headers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          file_path: path,
          file_content: fileContent || "",
          is_excel: path.toLowerCase().endsWith(".xlsx"),
        }),
      });
      const result = await response.json();
      if (response.ok) {
        setHeaders(result.headers || []);
        setShowModal(true);
      } else {
        throw new Error(result.error || "Failed to get CSV headers");
      }
    } catch (error) {
      console.error("Error getting CSV headers:", error);
      alert(error.message || "Failed to get CSV headers");
    }
  };

  return (
    <div className="mb-4">
      <div className="relative w-full mb-2">
        <input
          type="text"
          value={path}
          onChange={(e) => setPath(e.target.value)}
          placeholder="Chọn file định dạng *.csv hoặc *.xlsx"
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
        <button
          type="button"
          onClick={handleOpenExplorer}
          className="absolute right-2 top-1/2 transform -translate-y-1/2 text-white"
        >
          ...
        </button>
      </div>
      <button
        onClick={handleConfirmFile}
        className="w-full py-2 bg-yellow-500 text-white font-bold rounded"
      >
        Xác nhận
      </button>
    </div>
  );
};

export default FileInputSection;
```
## 📄 File: `ColumnSelectorModal.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/components/query/ColumnSelectorModal.js`

```javascript
const ColumnSelectorModal = ({
  showModal,
  setShowModal,
  headers,
  selectedColumn,
  setSelectedColumn,
  history,
  setHistory,
  selectedPlatform,
  setSelectedPlatform,
  shopeeLabel,
  setShopeeLabel,
  lazadaLabel,
  setLazadaLabel,
  tiktokLabel,
  setTiktokLabel,
  customLabel1,
  setCustomLabel1,
  customLabel2,
  setCustomLabel2,
  path,
  fileContent,
  setSearchString,
  setSearchType,
}) => {
  const handleModalConfirm = async () => {
    const columnName = history[selectedPlatform] || "tracking_codes";
    const data = {
      file_path: path,
      file_content: fileContent || "",
      column_name: columnName,
      is_excel: path.toLowerCase().endsWith(".xlsx"), // Thêm logic xác định is_excel dựa trên path
    };
    try {
      console.log("Sending file data:", data);
      const response = await fetch("http://localhost:8080/parse-csv", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      console.log("Response from parse-csv:", result);
      if (response.ok) {
        const trackingCodes = result.tracking_codes || [];
        const formattedCodes = trackingCodes
          .map((code, index) => `${index + 1}. ${code}`)
          .join("\n");
        setSearchString(formattedCodes);
        setSearchType("Text");
        setShowModal(false);
      } else {
        throw new Error(result.error || "Failed to parse CSV");
      }
    } catch (error) {
      console.error("Error parsing CSV:", error);
      alert(error.message || "Failed to parse CSV");
    }
  };

  const handleUpdateColumn = () => {
    const newColumn = selectedColumn;
    const updatedHistory = { ...history };
    updatedHistory[selectedPlatform] = newColumn;
    setHistory(updatedHistory);
    localStorage.setItem("trackingColumnHistory", JSON.stringify(updatedHistory));

    const updatedLabels = {
      Shopee: shopeeLabel,
      Lazada: lazadaLabel,
      Tiktok: tiktokLabel,
      Custom1: customLabel1,
      Custom2: customLabel2,
    };
    localStorage.setItem("platformLabels", JSON.stringify(updatedLabels));
  };

  const handlePlatformChange = (platform) => {
    setSelectedPlatform(platform);
    setSelectedColumn(history[platform] || "tracking_codes");
  };

  if (!showModal) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-gray-800 p-6 rounded-lg w-1/2">
        <h2 className="text-xl font-bold mb-4">Chọn cột mã vận đơn</h2>
        <div className="mb-4">
          <label className="block mb-1">Chọn từ danh sách:</label>
          <select
            value={selectedColumn}
            onChange={(e) => setSelectedColumn(e.target.value)}
            className="w-full p-2 rounded bg-gray-700 text-white"
          >
            {headers.map((header, index) => (
              <option key={index} value={header}>{header}</option>
            ))}
          </select>
        </div>
        <div className="mb-4">
          <button
            onClick={handleUpdateColumn}
            className="w-full py-2 bg-blue-600 text-white font-bold rounded"
          >
            Cập nhật
          </button>
        </div>
        <div className="mb-4">
          <h3 className="text-lg font-bold mb-2">Lịch sử lựa chọn:</h3>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Shopee"
              checked={selectedPlatform === "Shopee"}
              onChange={() => handlePlatformChange("Shopee")}
              className="mr-2"
            />
            <input
              type="text"
              value={shopeeLabel}
              onChange={(e) => setShopeeLabel(e.target.value)}
              placeholder="Tên Shopee"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Shopee}
              onChange={(e) => setHistory({ ...history, Shopee: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Lazada"
              checked={selectedPlatform === "Lazada"}
              onChange={() => handlePlatformChange("Lazada")}
              className="mr-2"
            />
            <input
              type="text"
              value={lazadaLabel}
              onChange={(e) => setLazadaLabel(e.target.value)}
              placeholder="Tên Lazada"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Lazada}
              onChange={(e) => setHistory({ ...history, Lazada: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Tiktok"
              checked={selectedPlatform === "Tiktok"}
              onChange={() => handlePlatformChange("Tiktok")}
              className="mr-2"
            />
            <input
              type="text"
              value={tiktokLabel}
              onChange={(e) => setTiktokLabel(e.target.value)}
              placeholder="Tên Tiktok"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Tiktok}
              onChange={(e) => setHistory({ ...history, Tiktok: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Custom1"
              checked={selectedPlatform === "Custom1"}
              onChange={() => handlePlatformChange("Custom1")}
              className="mr-2"
            />
            <input
              type="text"
              value={customLabel1}
              onChange={(e) => setCustomLabel1(e.target.value)}
              placeholder="Tên tùy chỉnh 1"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Custom1}
              onChange={(e) => setHistory({ ...history, Custom1: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
          <label className="flex items-center mb-2">
            <input
              type="radio"
              name="platform"
              value="Custom2"
              checked={selectedPlatform === "Custom2"}
              onChange={() => handlePlatformChange("Custom2")}
              className="mr-2"
            />
            <input
              type="text"
              value={customLabel2}
              onChange={(e) => setCustomLabel2(e.target.value)}
              placeholder="Tên tùy chỉnh 2"
              className="mr-2 p-1 rounded bg-gray-700 text-white"
            />
            <input
              type="text"
              value={history.Custom2}
              onChange={(e) => setHistory({ ...history, Custom2: e.target.value })}
              className="p-1 rounded bg-gray-700 text-white"
            />
          </label>
        </div>
        <div className="flex justify-end gap-4">
          <button
            onClick={() => setShowModal(false)}
            className="py-2 px-4 bg-gray-600 text-white rounded"
          >
            Hủy
          </button>
          <button
            onClick={handleModalConfirm}
            className="py-2 px-4 bg-green-600 text-white rounded"
          >
            Xác nhận
          </button>
        </div>
      </div>
    </div>
  );
};

export default ColumnSelectorModal;
```
## 📄 File: `useVtrackConfig.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/hooks/useVtrackConfig.js`

```javascript
import { useState, useEffect } from "react";

const useVtrackConfig = () => {
  const [fromTime, setFromTime] = useState(null);
  const [toTime, setToTime] = useState(null);
  const [country, setCountry] = useState("Việt Nam");
  const [timezone, setTimezone] = useState("UTC+7");
  const [brandName, setBrandName] = useState("");
  const [inputPath, setInputPath] = useState("");
  const [outputPath, setOutputPath] = useState("");
  const [workingDays, setWorkingDays] = useState([]);
  const [defaultDays, setDefaultDays] = useState(30);
  const [minPackingTime, setMinPackingTime] = useState(10);
  const [maxPackingTime, setMaxPackingTime] = useState(120);
  const [frameRate, setFrameRate] = useState(30);
  const [frameInterval, setFrameInterval] = useState(5);
  const [videoBuffer, setVideoBuffer] = useState(2);
  const [cameras, setCameras] = useState([]);
  const [selectedCameras, setSelectedCameras] = useState([]);
  const [showCameraDialog, setShowCameraDialog] = useState(false);
  const [error, setError] = useState(null);
  const [runDefaultOnStart, setRunDefaultOnStart] = useState(false);

  const countries = [
    "Việt Nam", "Nhật Bản", "Hàn Quốc", "Thái Lan", "Singapore",
    "Mỹ", "Anh", "Pháp", "Đức", "Úc"
  ];

  const countryTimezones = {
    "Việt Nam": "UTC+7", "Nhật Bản": "UTC+9", "Hàn Quốc": "UTC+9",
    "Thái Lan": "UTC+7", "Singapore": "UTC+8", "Mỹ": "UTC-5",
    "Anh": "UTC+0", "Pháp": "UTC+1", "Đức": "UTC+1", "Úc": "UTC+10"
  };

  const BASE_DIR = "/Users/annhu/vtrack_app/V_Track";

  useEffect(() => {
    const fetchCameraFolders = async () => {
      try {
        const response = await fetch("http://localhost:8080/get-camera-folders");
        const data = await response.json();
        if (Array.isArray(data.folders)) {
          setCameras(data.folders);
          setError(null);
        } else {
          setCameras([]);
          setError(data.error || "Failed to load camera folders");
        }
      } catch (error) {
        console.error("Error fetching camera folders:", error);
        setError("Error fetching camera folders: " + error.message);
      }
    };
    fetchCameraFolders();
  }, []);

  const handleCountryChange = (e) => {
    const selectedCountry = e.target.value;
    setCountry(selectedCountry);
    setTimezone(countryTimezones[selectedCountry] || "UTC+0");
  };

  const handleFromTimeChange = (time) => {
    setFromTime(time);
    if (toTime && time > toTime) setToTime(time);
  };

  const handleToTimeChange = (time) => {
    if (fromTime && time < fromTime) setFromTime(time);
    setToTime(time);
  };

  const handleWorkingDayChange = (day) => {
    setWorkingDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };

  useEffect(() => {
    console.log("workingDays updated:", workingDays);
  }, [workingDays]);

  const handleOpenExplorer = (type) => {
    const input = document.createElement("input");
    input.type = "file";
    input.webkitdirectory = true;
    input.onchange = (e) => {
      const files = e.target.files;
      if (files.length > 0) {
        const file = files[0];
        let selectedPath = file.path || file.webkitRelativePath || file.name || "";
        if (!selectedPath.startsWith('/')) {
          selectedPath = `${BASE_DIR}/${selectedPath}`;
        }
        selectedPath = selectedPath.split('/').slice(0, -1).join('/');
        if (selectedPath.includes('.DS_Store')) {
          selectedPath = selectedPath.replace('/.DS_Store', '');
        }
        console.log(`Selected ${type} path:`, selectedPath);
        if (type === "input") setInputPath(selectedPath);
        else setOutputPath(selectedPath);
      }
    };
    input.click();
  };

  const handleSaveGeneralInfo = async () => {
    const data = {
      country,
      timezone,
      brand_name: brandName,
      working_days: workingDays.length > 0 ? workingDays : ["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"],
      from_time: fromTime ? fromTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false }) : "07:00",
      to_time: toTime ? toTime.toLocaleTimeString('en-GB', { hour: "2-digit", minute: "2-digit", hour12: false }) : "23:00",
    };
    console.log("Data sent to /save-general-info:", data);
    try {
      const response = await fetch("http://localhost:8080/save-general-info", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (response.ok) alert("General info saved successfully");
      else throw new Error("Failed to save general info");
    } catch (error) {
      console.error("Error saving general info:", error);
      alert("Failed to save general info");
    }
  };

  const handleSaveConfig = async () => {
    let normalizedInputPath = inputPath.trim();
    if (!normalizedInputPath) {
      alert("Input path cannot be empty");
      return;
    }
    if (!normalizedInputPath.startsWith('/')) {
      normalizedInputPath = `${BASE_DIR}/${normalizedInputPath}`;
    }
    if (normalizedInputPath.includes('.DS_Store')) {
      normalizedInputPath = normalizedInputPath.replace('/.DS_Store', '');
    }

    let normalizedOutputPath = outputPath.trim();
    if (!normalizedOutputPath) {
      normalizedOutputPath = `${BASE_DIR}/output_clips`;
    }
    if (!normalizedOutputPath.startsWith('/')) {
      normalizedOutputPath = `${BASE_DIR}/${normalizedOutputPath}`;
    }
    if (normalizedOutputPath.includes('.DS_Store')) {
      normalizedOutputPath = normalizedOutputPath.replace('/.DS_Store', '');
    }

    const data = {
      video_root: normalizedInputPath,
      output_path: normalizedOutputPath,
      db_path: "/Users/annhu/Downloads/V_Track project/events.db",
      default_days: defaultDays,
      min_packing_time: minPackingTime,
      max_packing_time: maxPackingTime,
      frame_rate: frameRate,
      frame_interval: frameInterval,
      video_buffer: videoBuffer,
      selected_cameras: selectedCameras,
    };
    console.log("Data sent to /save-config:", data);
    try {
      const response = await fetch("http://localhost:8080/save-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      if (response.ok) {
        localStorage.setItem("configSet", "true");
        alert("Configuration saved successfully");
        setShowCameraDialog(false);
        const cameraResponse = await fetch("http://localhost:8080/get-cameras");
        const cameraData = await cameraResponse.json();
        if (cameraData && Array.isArray(cameraData.cameras)) {
          setCameras(cameraData.cameras.map(name => ({ name, path: "" })));
          setError(null);
        } else {
          setCameras([]);
          setError(cameraData?.error || "Failed to load cameras");
        }
      } else {
        throw new Error(result.error || "Failed to save config");
      }
    } catch (error) {
      console.error("Error saving config:", error);
      alert("Failed to save config: " + error.message);
    }
  };

  const handleShowCameraDialog = () => {
    setShowCameraDialog(true);
  };

  const handleCameraSelection = (cameraName) => {
    setSelectedCameras((prev) =>
      prev.includes(cameraName) ? prev.filter((c) => c !== cameraName) : [...prev, cameraName]
    );
  };

  return {
    fromTime,
    setFromTime,
    toTime,
    setToTime,
    country,
    setCountry,
    timezone,
    setTimezone,
    brandName,
    setBrandName,
    inputPath,
    setInputPath,
    outputPath,
    setOutputPath,
    workingDays,
    setWorkingDays,
    defaultDays,
    setDefaultDays,
    minPackingTime,
    setMinPackingTime,
    maxPackingTime,
    setMaxPackingTime,
    frameRate,
    setFrameRate,
    frameInterval,
    setFrameInterval,
    videoBuffer,
    setVideoBuffer,
    cameras,
    setCameras,
    selectedCameras,
    setSelectedCameras,
    showCameraDialog,
    setShowCameraDialog,
    error,
    setError,
    handleCountryChange,
    handleFromTimeChange,
    handleToTimeChange,
    handleWorkingDayChange,
    handleOpenExplorer,
    handleSaveGeneralInfo,
    handleSaveConfig,
    handleShowCameraDialog,
    handleCameraSelection,
    runDefaultOnStart,
    setRunDefaultOnStart,
  };
};

export default useVtrackConfig;
```
## 📄 File: `useProgramLogic.js`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/frontend/src/hooks/useProgramLogic.js`

```javascript
import { useState, useEffect } from "react";
import { runProgram, confirmRun } from "../api";

const useProgramLogic = () => {
  const [runningCard, setRunningCard] = useState(null);
  const [fileList, setFileList] = useState([]);
  const [customPath, setCustomPath] = useState("");
  const [showConfirmButton, setShowConfirmButton] = useState(false);
  const [firstRunCompleted, setFirstRunCompleted] = useState(false);

  const checkFirstRun = async () => {
    try {
      const response = await fetch("http://localhost:8080/check-first-run");
      const data = await response.json();
      setFirstRunCompleted(data.first_run_completed);
    } catch (error) {
      console.error("Error checking first run:", error);
    }
  };

  // Thêm hàm kiểm tra trạng thái chạy mặc định từ backend
  const checkDefaultRunning = async () => {
    try {
      const response = await fetch("http://localhost:8080/program", {
        method: "GET",
      });
      const data = await response.json();
      if (data.current_running) {
        setRunningCard(data.current_running); // Cập nhật runningCard từ backend
      }
    } catch (error) {
      console.error("Error checking default running state:", error);
    }
  };

  useEffect(() => {
    const initializeState = async () => {
      await checkFirstRun(); // Gọi API để lấy firstRunCompleted
      await checkDefaultRunning(); // Gọi API để lấy runningCard
    };
    initializeState();
  }, []);

  const handleRunStop = async (cardTitle, path = "") => {
    if (cardTitle === "Lần đầu" && firstRunCompleted) {
      return;
    }

    try {
      let days = null;
      if (cardTitle === "Lần đầu" && !isRunning(cardTitle)) {
        days = prompt("Bạn muốn xử lý bao nhiêu ngày? (Tối đa 30 ngày)", "30");
        days = parseInt(days);
        if (isNaN(days) || days <= 0 || days > 30) {
          alert("Số ngày không hợp lệ. Vui lòng nhập từ 1 đến 30.");
          return;
        }
      } else if (cardTitle === "Chỉ định" && !isRunning(cardTitle)) {
        if (!path) {
          alert("Vui lòng chọn đường dẫn cho chương trình Chỉ định.");
          return;
        }
      }

      const response = await runProgram({
        card: cardTitle,
        action: isRunning(cardTitle) ? "stop" : "run",
        days: days,
        custom_path: cardTitle === "Chỉ định" ? path : ""
      });

      if (response.status === 200) {
        if (isRunning(cardTitle)) {
          setRunningCard(null);
          setShowConfirmButton(false);
          setFileList([]);
          alert(`Đã dừng chương trình ${cardTitle}`);
        } else {
          if (cardTitle !== "Lần đầu" || !firstRunCompleted) {
            setRunningCard(cardTitle);
            setShowConfirmButton(true);
            if (cardTitle === "Lần đầu") {
              alert(`Đang chạy chương trình Lần đầu với ${days} ngày`);
            } else if (cardTitle === "Mặc định") {
              alert(`Đang chạy chương trình Mặc định`);
            } else if (cardTitle === "Chỉ định") {
              alert(`Đang chạy chương trình Chỉ định với đường dẫn: ${path}`);
            }
          }
        }
      }
    } catch (error) {
      console.error("Error calling API:", error);
      alert("Có lỗi xảy ra khi gọi API. Vui lòng kiểm tra server.");
    }
  };

  const handleConfirmRun = async () => {
    try {
      const response = await confirmRun({ card: runningCard });
      if (response.status === 200) {
        alert(`Đã xác nhận chạy chương trình ${runningCard}`);
        setShowConfirmButton(false);
        setFileList(response.data.files || []);
        if (runningCard === "Lần đầu") {
          setFirstRunCompleted(true); // Đặt firstRunCompleted thành true
          await checkFirstRun(); // Cập nhật lại trạng thái từ backend
        }
        // Chỉ đặt lại runningCard nếu không phải "Mặc định" và firstRunCompleted không ảnh hưởng
        if (runningCard !== "Mặc định" && runningCard !== "Lần đầu") {
          setRunningCard(null);
        }
      }
    } catch (error) {
      console.error("Error confirming run:", error);
      alert("Có lỗi xảy ra khi xác nhận chạy chương trình.");
    }
  };

  const isRunning = (cardTitle) => runningCard === cardTitle;

  return {
    runningCard,
    setRunningCard,
    fileList,
    setFileList,
    customPath,
    setCustomPath,
    showConfirmButton,
    setShowConfirmButton,
    firstRunCompleted,
    setFirstRunCompleted,
    handleRunStop,
    handleConfirmRun,
    isRunning,
  };
};

export default useProgramLogic;
```
## 📄 File: `update_database.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/update_database.py`

```python
import sqlite3
import os
import json
from modules.db_utils import find_project_root

# Xác định thư mục gốc của dự án
BASE_DIR = find_project_root(os.path.abspath(__file__))

# Đường dẫn tương đối cho cơ sở dữ liệu
DB_DIR = os.path.join(BASE_DIR, "backend/database")
DB_PATH = os.path.join(DB_DIR, "events.db")

# Đường dẫn mặc định cho input_path và output_path (không tạo thư mục tự động)
INPUT_VIDEO_DIR = os.path.join(BASE_DIR, "resources/Inputvideo")
OUTPUT_CLIPS_DIR = os.path.join(BASE_DIR, "resources/output_clips")

def get_db_connection():
    # Bỏ kiểm tra os.path.exists(DB_PATH) để SQLite tự động tạo file nếu không tồn tại
    if not os.access(DB_DIR, os.R_OK):
        raise PermissionError(f"No read permission for directory: {DB_DIR}")
    if not os.access(DB_DIR, os.W_OK):
        raise PermissionError(f"No write permission for directory: {DB_DIR}")
    return sqlite3.connect(DB_PATH)

def update_database():
    try:
        # Kiểm tra quyền ghi
        if not os.access(DB_DIR, os.W_OK):
            raise PermissionError(f"No write permission for directory: {DB_DIR}. Please check directory permissions.")

        conn = get_db_connection()
        cursor = conn.cursor()

        # Tạo bảng file_list với cột is_processed, priority và status
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS file_list (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                program_type TEXT NOT NULL,
                days INTEGER,
                custom_path TEXT,
                file_path TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_processed INTEGER DEFAULT 0,
                priority INTEGER DEFAULT 0,
                status TEXT DEFAULT 'chưa bắt đầu',
                log_file_path TEXT,
                camera_name TEXT
            )
        """)

        # Kiểm tra và thêm cột is_processed nếu chưa có
        cursor.execute("PRAGMA table_info(file_list)")
        columns = [col[1] for col in cursor.fetchall()]
        if "is_processed" not in columns:
            cursor.execute("ALTER TABLE file_list ADD COLUMN is_processed INTEGER DEFAULT 0")
        # Kiểm tra và thêm cột priority nếu chưa có
        if "priority" not in columns:
            cursor.execute("ALTER TABLE file_list ADD COLUMN priority INTEGER DEFAULT 0")
        # Kiểm tra và thêm cột status nếu chưa có
        if "status" not in columns:
            cursor.execute("ALTER TABLE file_list ADD COLUMN status TEXT DEFAULT 'chưa bắt đầu'")
        # Kiểm tra và thêm cột log_file_path nếu chưa có
        if "log_file_path" not in columns:
            cursor.execute("ALTER TABLE file_list ADD COLUMN log_file_path TEXT")
        # Đổi tên cột cam_name thành camera_name nếu chưa đổi
        if "cam_name" in columns and "camera_name" not in columns:
            cursor.execute("ALTER TABLE file_list RENAME COLUMN cam_name TO camera_name")

        # Tạo bảng program_status
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS program_status (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL,
                value TEXT NOT NULL
            )
        """)
        cursor.execute("INSERT OR IGNORE INTO program_status (key, value) VALUES ('first_run_completed', 'false')")

        # Tạo bảng processing_config với cột run_default_on_start
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS processing_config (
                id INTEGER PRIMARY KEY,
                input_path TEXT,
                output_path TEXT,
                storage_duration INTEGER,
                min_packing_time INTEGER,
                max_packing_time INTEGER,
                frame_rate INTEGER,
                frame_interval INTEGER,
                video_buffer INTEGER,
                default_frame_mode TEXT,
                selected_cameras TEXT,
                db_path TEXT NOT NULL,
                run_default_on_start INTEGER DEFAULT 1
            )
        """)
        # Kiểm tra và thêm cột selected_cameras nếu chưa có
        cursor.execute("PRAGMA table_info(processing_config)")
        columns = [col[1] for col in cursor.fetchall()]
        if "selected_cameras" not in columns:
            cursor.execute("ALTER TABLE processing_config ADD COLUMN selected_cameras TEXT DEFAULT '[]'")
        # Kiểm tra và thêm cột db_path nếu chưa có
        if "db_path" not in columns:
            cursor.execute("ALTER TABLE processing_config ADD COLUMN db_path TEXT NOT NULL DEFAULT '/Users/annhu/vtrack_app/V_Track/database/events.db'")
        # Kiểm tra và thêm cột run_default_on_start nếu chưa có
        if "run_default_on_start" not in columns:
            cursor.execute("ALTER TABLE processing_config ADD COLUMN run_default_on_start INTEGER DEFAULT 1")
        # Cập nhật db_path cho các bản ghi hiện có nếu là null
        cursor.execute("UPDATE processing_config SET db_path = ? WHERE db_path IS NULL", (DB_PATH,))
        # Cập nhật run_default_on_start cho các bản ghi hiện có nếu là null
        cursor.execute("UPDATE processing_config SET run_default_on_start = 1 WHERE run_default_on_start IS NULL")

        # Kiểm tra và chèn dữ liệu mặc định nếu bảng rỗng
        cursor.execute("SELECT COUNT(*) FROM processing_config")
        if cursor.fetchone()[0] == 0:
            cursor.execute("""
                INSERT INTO processing_config (
                    id, input_path, output_path, storage_duration, min_packing_time, 
                    max_packing_time, frame_rate, frame_interval, video_buffer, default_frame_mode, selected_cameras, db_path, run_default_on_start
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (1, INPUT_VIDEO_DIR, OUTPUT_CLIPS_DIR, 30, 10, 120, 30, 5, 2, "default", "[]", DB_PATH, 1))

        # Tạo bảng frame_settings
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS frame_settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mode TEXT NOT NULL,
                frame_rate INTEGER,
                frame_interval INTEGER,
                description TEXT
            )
        """)
        cursor.execute("SELECT COUNT(*) FROM frame_settings")
        if cursor.fetchone()[0] == 0:
            cursor.execute("""
                INSERT INTO frame_settings (mode, frame_rate, frame_interval, description)
                VALUES (?, ?, ?, ?)
            """, ("default", 30, 5, "Chế độ mặc định từ giao diện"))

        # Tạo bảng general_info
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS general_info (
                id INTEGER PRIMARY KEY,
                country TEXT,
                timezone TEXT,
                brand_name TEXT,
                working_days TEXT,
                from_time TEXT,
                to_time TEXT
            )
        """)
        cursor.execute("SELECT COUNT(*) FROM general_info")
        if cursor.fetchone()[0] == 0:
            working_days = ["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"]
            cursor.execute("""
                INSERT INTO general_info (
                    id, country, timezone, brand_name, working_days, from_time, to_time
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (1, "Việt Nam", "UTC+7", "MyBrand", str(working_days), "07:00", "23:00"))

        # Tạo bảng events
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS events (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER,
                te INTEGER,
                duration INTEGER,
                tracking_codes TEXT,
                video_file TEXT NOT NULL,
                buffer INTEGER NOT NULL,
                camera_name TEXT,
                packing_time_start INTEGER,
                packing_time_end INTEGER,
                is_processed INTEGER DEFAULT 0,
                processed_timestamp INTEGER,
                output_video_path TEXT,
                session_id TEXT,
                output_file TEXT
            )
        """)

        # Tạo bảng processed_logs cho Event Detector với cột is_processed
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS processed_logs (
                log_file TEXT PRIMARY KEY,
                processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_processed INTEGER DEFAULT 0
            )
        """)

        # Tạo bảng packing_profiles nếu chưa có
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS packing_profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                profile_name TEXT NOT NULL,
                qr_trigger_area TEXT,
                qr_mvd_area TEXT,
                packing_area TEXT,
                min_packing_time INTEGER,
                jump_time_ratio REAL,
                scan_mode TEXT,
                fixed_threshold INTEGER,
                margin INTEGER,
                additional_params TEXT
            )
        ''')

        # Kiểm tra xem bảng packing_profiles có dữ liệu chưa
        cursor.execute("SELECT COUNT(*) FROM packing_profiles")
        profile_count = cursor.fetchone()[0]

        # Nếu bảng trống, chèn các profile mặc định
        if profile_count == 0:
            # Profile FS3 (Nhiễu loạn) - Mặc định
            fs3 = {
                "profile_name": "FS3",
                "qr_trigger_area": json.dumps([0, 0, 0, 0]),
                "qr_mvd_area": json.dumps([0, 0, 0, 0]),
                "packing_area": json.dumps([0, 0, 0, 0]),
                "min_packing_time": 10,
                "jump_time_ratio": 0.5,  # Nhảy 50%
                "scan_mode": "full",
                "fixed_threshold": 20,
                "margin": 60,
                "additional_params": json.dumps({})
            }

            # Profile FS1 (Tiêu chuẩn) - Mặc định
            fs1 = {
                "profile_name": "FS1",
                "qr_trigger_area": json.dumps([0, 0, 0, 0]),
                "qr_mvd_area": json.dumps([0, 0, 0, 0]),
                "packing_area": json.dumps([0, 0, 0, 0]),
                "min_packing_time": 10,
                "jump_time_ratio": 0.7,  # Nhảy 70%
                "scan_mode": "fixed",
                "fixed_threshold": 20,
                "margin": 60,
                "additional_params": json.dumps({})
            }

            # Profile FS2 (Tự do) - Mặc định
            fs2 = {
                "profile_name": "FS2",
                "qr_trigger_area": json.dumps([0, 0, 0, 0]),
                "qr_mvd_area": json.dumps([0, 0, 0, 0]),
                "packing_area": json.dumps([0, 0, 0, 0]),
                "min_packing_time": 10,
                "jump_time_ratio": 0.5,  # Nhảy 50%
                "scan_mode": "hybrid",
                "fixed_threshold": 20,
                "margin": 60,
                "additional_params": json.dumps({})
            }

            # Chèn các profile vào CSDL
            profiles = [fs3, fs1, fs2]
            for profile in profiles:
                cursor.execute('''
                    INSERT INTO packing_profiles (
                        profile_name, qr_trigger_area, qr_mvd_area, packing_area,
                        min_packing_time, jump_time_ratio, scan_mode,
                        fixed_threshold, margin, additional_params
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    profile["profile_name"],
                    profile["qr_trigger_area"],
                    profile["qr_mvd_area"],
                    profile["packing_area"],
                    profile["min_packing_time"],
                    profile["jump_time_ratio"],
                    profile["scan_mode"],
                    profile["fixed_threshold"],
                    profile["margin"],
                    profile["additional_params"]
                ))

            print(f"Đã khởi tạo các profile gốc: FS1, FS2, FS3 với min_packing_time = 10")
        else:
            print("Bảng packing_profiles đã có dữ liệu, bỏ qua khởi tạo.")

        conn.commit()
        conn.close()
        print(f"CSDL tại {DB_PATH} đã được cập nhật thành công.")
    except Exception as e:
        print(f"Error updating database: {e}")
        raise

if __name__ == "__main__":
    # Chỉ tạo DB_DIR khi chạy trực tiếp trong setup
    os.makedirs(DB_DIR, exist_ok=True)
    update_database()
```
## 📄 File: `app.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/app.py`

```python
from flask import Flask
from flask_cors import CORS
from datetime import datetime
import sqlite3
import os
import threading
from modules.db_utils import find_project_root, get_db_connection
from modules.scheduler.program import program_bp
from modules.config.config import config_bp
from modules.query.query import query_bp
from modules.scheduler.program_runner import start_frame_sampler_thread, start_event_detector_thread
from modules.scheduler.db_sync import frame_sampler_event, db_rwlock  # Thêm import db_rwlock
from apscheduler.schedulers.background import BackgroundScheduler
from modules.scheduler.file_lister import list_files
from modules.technician.cutter.cutter import cutter_bp

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "http://localhost:3000"}})

BASE_DIR = find_project_root(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "backend/database", "events.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

def get_db_path():
    default_db_path = DB_PATH
    try:
        with db_rwlock.gen_rlock():  # Thêm khóa đọc
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT db_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            conn.close()
        return result[0] if result else default_db_path
    except Exception as e:
        print(f"Error getting DB_PATH from database: {e}")
        return default_db_path

DB_PATH = get_db_path()
print(f"Using DB_PATH: {DB_PATH}")

app.register_blueprint(program_bp)
app.register_blueprint(config_bp)
app.register_blueprint(query_bp)
app.register_blueprint(cutter_bp)

def save_last_stop_time():
    try:
        with db_rwlock.gen_wlock():  # Thêm khóa ghi
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS program_status (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT NOT NULL,
                    value TEXT NOT NULL
                )
            ''')
            cursor.execute("SELECT id FROM program_status WHERE key = ?", ('last_stop_time',))
            result = cursor.fetchone()
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            if result:
                cursor.execute('''
                    UPDATE program_status SET value = ? WHERE key = ?
                ''', (current_time, 'last_stop_time'))
            else:
                cursor.execute('''
                    INSERT INTO program_status (key, value) VALUES (?, ?)
                ''', ('last_stop_time', current_time))
            conn.commit()
            conn.close()
        print("Last stop time saved successfully.")
    except Exception as e:
        print(f"Failed to save last stop time: {str(e)}")
        raise

def scheduled_default_scan():
    try:
        with db_rwlock.gen_rlock():  # Thêm khóa đọc
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT input_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            video_root = result[0] if result else os.path.join(BASE_DIR, "Inputvideo")
            conn.close()
        video_files = list_files(video_root, "default", None, None, DB_PATH)
        print(f"Scheduled scan at {datetime.now()}: Found {len(video_files)} new files")
    except Exception as e:
        print(f"Error in scheduled scan: {str(e)}")

scheduler = BackgroundScheduler()
scheduler.add_job(scheduled_default_scan, 'cron', hour='*', minute='6,36', start_date='2025-03-28 00:06:00')

if __name__ == "__main__":
    try:
        with db_rwlock.gen_rlock():  # Thêm khóa đọc
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT value FROM program_status WHERE key = "first_run_completed"')
            result = cursor.fetchone()
            cursor.execute('SELECT run_default_on_start FROM processing_config WHERE id = 1')
            run_default_result = cursor.fetchone()
            run_default = run_default_result[0] if run_default_result else 1
            first_run_completed = result[0] == 'true' if result else False
            conn.close()

        if first_run_completed and run_default:
            scheduled_default_scan()
            frame_sampler_thread = start_frame_sampler_thread()
            frame_sampler_event.set()

        scheduler.start()
        app.run(debug=True, host='0.0.0.0', port=8080)
    finally:
        print("Saving last stop time...")
        save_last_stop_time()
        print("Server stopped.")
```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/__init__.py`

```python

```
## 📄 File: `config.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/config/config.py`

```python
from flask import Blueprint, request, jsonify
import os
import json
import sqlite3
from modules.db_utils import find_project_root, get_db_connection

config_bp = Blueprint('config', __name__)

# Xác định thư mục gốc của dự án
BASE_DIR = find_project_root(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")

# Hàm đọc cấu hình từ file hoặc biến môi trường
def load_config():
    default_config = {
        "db_path": os.path.join(BASE_DIR, "database", "events.db"),
        "input_path": os.path.join(BASE_DIR, "Inputvideo"),
        "output_path": os.path.join(BASE_DIR, "output_clips")
    }
    
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading config file: {e}")
            return default_config
    
    return {
        "db_path": os.getenv("DB_PATH", default_config["db_path"]),
        "input_path": os.getenv("INPUT_PATH", default_config["input_path"]),
        "output_path": os.getenv("OUTPUT_PATH", default_config["output_path"])
    }

# Load cấu hình từ processing_config thay vì config.json
config = load_config()
DB_PATH = config["db_path"]
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

# Hàm lấy DB_PATH với giá trị mặc định
def get_db_path():
    default_db_path = DB_PATH
    temp_db_path = default_db_path
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT db_path FROM processing_config WHERE id = 1")
        result = cursor.fetchone()
        conn.close()
        return result[0] if result else default_db_path
    except Exception as e:
        print(f"Error getting DB_PATH from database: {e}")
        return default_db_path

DB_PATH = get_db_path()
print(f"Using DB_PATH: {DB_PATH}")

# Truy vấn cấu hình từ processing_config
try:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT input_path, output_path, frame_rate, frame_interval FROM processing_config WHERE id = 1")
    result = cursor.fetchone()
    conn.close()
    if result:
        INPUT_PATH, OUTPUT_PATH, FRAME_RATE, FRAME_INTERVAL = result
    else:
        INPUT_PATH = config["input_path"]
        OUTPUT_PATH = config["output_path"]
        FRAME_RATE = 30  # Giá trị mặc định nếu không có trong DB
        FRAME_INTERVAL = 6  # Giá trị mặc định nếu không có trong DB
except Exception as e:
    print(f"Error querying processing_config: {e}")
    INPUT_PATH = config["input_path"]
    OUTPUT_PATH = config["output_path"]
    FRAME_RATE = 30
    FRAME_INTERVAL = 6

@config_bp.route('/get-cameras', methods=['GET'])
def get_cameras():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT input_path FROM processing_config WHERE id = 1")
        result = cursor.fetchone()
        conn.close()

        if not result:
            return jsonify({"error": "video_root not found in configuration. Please update via /save-config endpoint."}), 400

        video_root = result[0]
        if not os.path.exists(video_root):
            return jsonify({"error": f"Directory {video_root} does not exist. Ensure the path is correct or create the directory."}), 400

        cameras = []
        for item in os.listdir(video_root):
            item_path = os.path.join(video_root, item)
            if os.path.isdir(item_path):
                cameras.append({"name": item, "path": item_path})

        return jsonify(cameras), 200
    except Exception as e:
        return jsonify({"error": f"Failed to retrieve cameras: {str(e)}"}), 500

@config_bp.route('/save-config', methods=['POST'])
def save_config():
    data = request.json
    video_root = data.get('video_root')
    output_path = data.get('output_path', config["output_path"])
    default_days = data.get('default_days')
    min_packing_time = data.get('min_packing_time', 10)
    max_packing_time = data.get('max_packing_time', 120)
    frame_rate = data.get('frame_rate')
    frame_interval = data.get('frame_interval')
    video_buffer = data.get('video_buffer', 2)
    selected_cameras = data.get('selected_cameras', [])
    run_default_on_start = data.get('run_default_on_start', 1)

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Thêm cột run_default_on_start nếu chưa tồn tại
        try:
            cursor.execute("ALTER TABLE processing_config ADD COLUMN run_default_on_start INTEGER DEFAULT 1")
        except sqlite3.OperationalError:
            pass  # Cột đã tồn tại
        cursor.execute("""
            INSERT OR REPLACE INTO processing_config (
                id, input_path, output_path, storage_duration, min_packing_time, 
                max_packing_time, frame_rate, frame_interval, video_buffer, default_frame_mode, selected_cameras, db_path, run_default_on_start
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (1, video_root, output_path, default_days, min_packing_time, max_packing_time, frame_rate, frame_interval, video_buffer, "default", json.dumps(selected_cameras), DB_PATH, run_default_on_start))

        cursor.execute("""
            INSERT OR REPLACE INTO frame_settings (id, mode, frame_rate, frame_interval, description)
            VALUES (?, ?, ?, ?, ?)
        """, (1, "default", frame_rate, frame_interval, "Chế độ mặc định từ giao diện"))

        conn.commit()
    except PermissionError as e:
        return jsonify({"error": f"Permission denied: {str(e)}. Check database file permissions."}), 403
    except Exception as e:
        return jsonify({"error": f"Database error: {str(e)}. Ensure the database is accessible."}), 500
    finally:
        conn.close()

    print("Config saved:", data)
    return jsonify({"message": "Configuration saved"}), 200

@config_bp.route('/save-general-info', methods=['POST'])
def save_general_info():
    data = request.json
    country = data.get('country')
    timezone = data.get('timezone')
    brand_name = data.get('brand_name')
    working_days = data.get('working_days', ["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"])
    from_time = data.get('from_time', "07:00")
    to_time = data.get('to_time', "23:00")

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO general_info (
                id, country, timezone, brand_name, working_days, from_time, to_time
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (1, country, timezone, brand_name, str(working_days), from_time, to_time))

        conn.commit()
    except PermissionError as e:
        return jsonify({"error": f"Permission denied: {str(e)}. Check database file permissions."}), 403
    except Exception as e:
        return jsonify({"error": f"Database error: {str(e)}. Ensure the database is accessible."}), 500
    finally:
        conn.close()

    print("General info saved:", data)
    return jsonify({"message": "General info saved"}), 200
```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/config/__init__.py`

```python

```
## 📄 File: `file_lister.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/scheduler/file_lister.py`

```python
import os
import sqlite3
from datetime import datetime, timedelta
import json
from modules.db_utils import find_project_root, get_db_connection
from .db_sync import frame_sampler_event, db_rwlock

# Xác định thư mục gốc của dự án
BASE_DIR = find_project_root(os.path.abspath(__file__))

# Định nghĩa DB_PATH dựa trên BASE_DIR, trỏ lên 2 cấp thư mục
DB_PATH = os.path.join(BASE_DIR, "../../database", "events.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

# Hàm lấy DB_PATH với giá trị mặc định
def get_db_path():
    default_db_path = DB_PATH
    temp_db_path = default_db_path
    
    try:
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT db_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            conn.close()
        return result[0] if result else default_db_path
    except Exception as e:
        print(f"Error getting DB_PATH from database: {e}")
        return default_db_path

DB_PATH = get_db_path()
print(f"Using DB_PATH: {DB_PATH}")

def list_files(video_root, scan_action, custom_path, days, db_path):
    try:
        with db_rwlock.gen_wlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            
            cursor.execute('SELECT value FROM program_status WHERE key = "first_run_completed"')
            first_run_completed = cursor.fetchone()
            first_run_completed = first_run_completed[0] == 'true' if first_run_completed else False

            cursor.execute('SELECT MAX(created_at) FROM file_list')
            last_scan = cursor.fetchone()[0]
            last_scan_time = datetime.strptime(last_scan, '%Y-%m-%d %H:%M:%S.%f') if last_scan else None

            cursor.execute('SELECT file_path FROM file_list')
            scanned_files = set(row[0] for row in cursor.fetchall())

            # Lấy video_root và selected_cameras từ processing_config
            cursor.execute("SELECT input_path, selected_cameras FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            if result:
                video_root = result[0]
                selected_cameras = json.loads(result[1]) if result[1] else []
            else:
                selected_cameras = []
            print(f"Using video_root: {video_root}")
            print(f"Selected cameras: {selected_cameras}")

            video_files = []
            path_to_scan = custom_path if scan_action == "custom" else video_root
            if not os.path.exists(path_to_scan):
                try:
                    os.makedirs(path_to_scan, exist_ok=True)
                    print(f"Created directory: {path_to_scan}")
                except Exception as e:
                    print(f"Failed to create directory: {path_to_scan}, error: {str(e)}")
                    return []

            video_extensions = ('.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv')

            if scan_action == "custom" and custom_path:
                if os.path.isfile(custom_path):
                    if custom_path.lower().endswith(video_extensions) and custom_path not in scanned_files:
                        file_name = os.path.basename(custom_path)
                        video_files = [file_name]  # Lưu đường dẫn tương đối (tên file)
                        print(f"Found file (custom file): {custom_path}")
                elif os.path.isdir(custom_path):
                    for root, dirs, files in os.walk(custom_path):
                        for file in files:
                            if file.lower().endswith(video_extensions):
                                file_path = os.path.join(root, file)
                                if file_path not in scanned_files:
                                    relative_path = os.path.relpath(file_path, path_to_scan)  # Tính đường dẫn tương đối
                                    video_files.append(relative_path)
                                    print(f"Found file (custom dir): {file_path}")
            elif scan_action == "first" and days:
                time_threshold = datetime.now() - timedelta(days=days)
                for root, dirs, files in os.walk(video_root):
                    if root != video_root:
                        relative_path = os.path.relpath(root, video_root)
                        camera_name = relative_path.split(os.sep)[0] if relative_path != "." else os.path.basename(video_root)
                        if selected_cameras and camera_name not in selected_cameras:
                            print(f"Skipping directory {root} (camera_name: {camera_name} not in selected_cameras)")
                            continue
                    for file in files:
                        if file.lower().endswith(video_extensions):
                            file_path = os.path.join(root, file)
                            if file_path in scanned_files:
                                print(f"Skipping file {file_path} (already scanned)")
                                continue
                            file_mtime = datetime.fromtimestamp(os.path.getmtime(file_path))
                            if file_mtime >= time_threshold:
                                relative_path = os.path.relpath(file_path, video_root)
                                video_files.append(relative_path)
                                print(f"Found file (first): {file_path}")
                if scan_action == "first":
                    cursor.execute('''
                        INSERT OR REPLACE INTO program_status (id, key, value)
                        VALUES ((SELECT id FROM program_status WHERE key = 'first_run_completed'), 'first_run_completed', 'true')
                    ''')
                    conn.commit()
            else:  # "default"
                time_threshold = datetime.now() - timedelta(hours=1)
                for root, dirs, files in os.walk(video_root):
                    if root != video_root:
                        relative_path = os.path.relpath(root, video_root)
                        camera_name = relative_path.split(os.sep)[0] if relative_path != "." else os.path.basename(video_root)
                        if selected_cameras and camera_name not in selected_cameras:
                            print(f"Skipping directory {root} (camera_name: {camera_name} not in selected_cameras)")
                            continue
                    for file in files:
                        if file.lower().endswith(video_extensions):
                            file_path = os.path.join(root, file)
                            if file_path in scanned_files:
                                print(f"Skipping file {file_path} (already scanned)")
                                continue
                            file_mtime = datetime.fromtimestamp(os.path.getmtime(file_path))
                            if file_mtime >= time_threshold:
                                relative_path = os.path.relpath(file_path, video_root)
                                video_files.append(relative_path)
                                print(f"Found file (default): {file_path}")

            # Ghi dữ liệu vào file_list với priority = 1 cho "custom" và thêm camera_name
            for file_path in video_files:
                absolute_path = os.path.join(path_to_scan, file_path) if scan_action != "custom" or not os.path.isfile(custom_path) else custom_path
                if absolute_path not in scanned_files:
                    priority = 1 if scan_action == "custom" else 0
                    relative_path = os.path.relpath(absolute_path, video_root) if scan_action != "custom" else os.path.dirname(absolute_path)
                    camera_name = relative_path.split(os.sep)[0] if relative_path != "." else os.path.basename(video_root)
                    cursor.execute('''
                        INSERT INTO file_list (program_type, days, custom_path, file_path, created_at, priority, camera_name)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (scan_action, days, custom_path, absolute_path, datetime.now(), priority, camera_name))
                    conn.commit()
                    scanned_files.add(absolute_path)
                    print(f"Inserted into file_list: {absolute_path} with priority {priority}")

            # Thông báo cho Frame Sampler thread nếu có file mới
            if video_files:
                frame_sampler_event.set()

            conn.close()
        print(f"Found {len(video_files)} video files: {video_files}")
        return video_files
    except Exception as e:
        raise Exception(f"Error in list_files: {str(e)}")
```
## 📄 File: `db_sync.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/scheduler/db_sync.py`

```python
# backend/modules/scheduler/db_sync.py
from readerwriterlock import rwlock
import threading

db_rwlock = rwlock.RWLockFairD()  # Sử dụng RWLockFairD để tránh deadlock
frame_sampler_event = threading.Event()
event_detector_event = threading.Event()
event_detector_done = threading.Event()
event_detector_done.set()  # Ban đầu cho phép Frame Sampler chạy
```
## 📄 File: `program_runner.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/scheduler/program_runner.py`

```python
import threading
import time
from modules.db_utils import get_db_connection
from modules.technician.Frame_Sampler import process_video
from modules.technician.event_detector import process_single_log
from .db_sync import db_rwlock, frame_sampler_event, event_detector_event, event_detector_done
# Biến tạm để lưu trạng thái chạy và số ngày
running_state = {"current_running": None, "days": None, "custom_path": None, "files": []}

def start_frame_sampler_thread():
    frame_sampler_thread = threading.Thread(target=run_frame_sampler)
    frame_sampler_thread.start()
    return frame_sampler_thread

def run_frame_sampler():
    while True:  # Vòng lặp vô hạn để thread luôn chạy
        frame_sampler_event.wait()  # Chờ thông báo từ event
        try:
            with db_rwlock.gen_rlock():  # Đồng bộ hóa truy cập database
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT file_path FROM file_list WHERE is_processed = 0 ORDER BY priority DESC, created_at ASC")
                video_files = [row[0] for row in cursor.fetchall()]
                conn.close()

            if not video_files:
                frame_sampler_event.clear()  # Xóa event và tiếp tục chờ
                continue

            for video_file in video_files:
                with db_rwlock.gen_wlock():  # Khóa khi cập nhật trạng thái
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("đang frame sampler ...", video_file))
                    conn.commit()
                    conn.close()
                log_file = process_video(video_file)
                with db_rwlock.gen_wlock():  # Khóa khi cập nhật trạng thái cuối
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    if log_file:
                        cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("xong", video_file))
                        event_detector_event.set()  # Kích hoạt Event Detector sau mỗi video
                    else:
                        cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("lỗi", video_file))
                    conn.commit()
                    conn.close()
                
                # Tạm dừng sau khi xử lý xong một video
                print(f"Frame Sampler pausing after processing {video_file}, waiting for Event Detector...")
                while not event_detector_done.is_set():
                    time.sleep(1)  # Chờ Event Detector hoàn tất

            frame_sampler_event.clear()  # Xóa event sau khi xử lý hết file
        except Exception as e:
            print(f"Error in Frame Sampler thread: {str(e)}")
            frame_sampler_event.clear()  # Đảm bảo thread "ngủ" lại nếu có lỗi

def start_event_detector_thread():
    event_detector_thread = threading.Thread(target=run_event_detector)
    event_detector_thread.start()
    return event_detector_thread

def run_event_detector():
    while True:
        event_detector_event.wait()
        try:
            with db_rwlock.gen_rlock():  # Đồng bộ hóa truy cập database
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT log_file FROM processed_logs WHERE is_processed = 0")
                log_files = [row[0] for row in cursor.fetchall()]
                conn.close()

            if not log_files:
                event_detector_event.clear()
                event_detector_done.set()  # Báo hiệu Frame Sampler tiếp tục
                continue

            for log_file in log_files:
                print(f"Event Detector processing: {log_file}")
                process_single_log(log_file)
            event_detector_event.clear()
            event_detector_done.set()  # Báo hiệu Frame Sampler tiếp tục sau khi xử lý hết log
        except Exception as e:
            print(f"Error in Event Detector thread: {str(e)}")
            event_detector_event.clear()
            event_detector_done.set()  # Vẫn báo hiệu Frame Sampler tiếp tục nếu có lỗi
```
## 📄 File: `program.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/scheduler/program.py`

```python
from flask import Blueprint, request, jsonify
import os
import sqlite3
import json
from modules.db_utils import find_project_root, get_db_connection
from .file_lister import list_files
from .program_runner import start_frame_sampler_thread, start_event_detector_thread, running_state
from .db_sync import db_rwlock, frame_sampler_event, event_detector_event

program_bp = Blueprint('program', __name__)

BASE_DIR = find_project_root(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "../../database", "events.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

def get_db_path():
    default_db_path = DB_PATH
    try:
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT db_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            conn.close()
            return result[0] if result else default_db_path
    except Exception as e:
        print(f"Error getting DB_PATH from database: {e}")
        return default_db_path

DB_PATH = get_db_path()
print(f"Using DB_PATH: {DB_PATH}")

@program_bp.route('/program', methods=['POST'])
def program():
    global frame_sampler_thread, event_detector_thread
    data = request.json
    card = data.get('card')
    action = data.get('action')
    custom_path = data.get('custom_path', '')
    days = data.get('days')

    if card == "Lần đầu" and action == "run":
        try:
            with db_rwlock.gen_rlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute('SELECT value FROM program_status WHERE id = 1')
                result = cursor.fetchone()
                first_run_completed = result[0] == 'true' if result else False
                conn.close()
            if first_run_completed:
                return jsonify({"error": "Lần đầu đã chạy trước đó, không thể chạy lại"}), 400
        except Exception as e:
            return jsonify({"error": f"Failed to check first run status: {str(e)}"}), 500

    if action == "run":
        if card == "Lần đầu":
            if not days:
                return jsonify({"error": "Days required for Lần đầu"}), 400
            running_state["days"] = days
            running_state["custom_path"] = None
        elif card == "Chỉ định":
            if not custom_path:
                return jsonify({"error": "Custom path required for Chỉ định"}), 400
            custom_path = os.path.abspath(custom_path)
            if not os.path.exists(custom_path):
                try:
                    os.makedirs(custom_path, exist_ok=True)
                    print(f"Created custom directory: {custom_path}")
                except Exception as e:
                    return jsonify({"error": f"Failed to create custom path {custom_path}: {str(e)}"}), 400
            running_state["custom_path"] = custom_path
            running_state["days"] = None
        else:
            running_state["days"] = None
            running_state["custom_path"] = None

        running_state["current_running"] = card
        frame_sampler_thread = start_frame_sampler_thread()
        event_detector_thread = start_event_detector_thread()
        frame_sampler_event.set()
        event_detector_event.set()

    elif action == "stop":
        with db_rwlock.gen_wlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE program_status SET value = CURRENT_TIMESTAMP WHERE id = 2")
            conn.commit()
            conn.close()
        running_state["current_running"] = None
        running_state["days"] = None
        running_state["custom_path"] = None
        running_state["files"] = []
        frame_sampler_event.clear()

    return jsonify({
        "message": f"{card} {action} successfully",
        "current_running": running_state["current_running"],
        "days": running_state.get("days"),
        "custom_path": running_state.get("custom_path")
    }), 200

@program_bp.route('/program', methods=['GET'])
def get_program_status():
    return jsonify({
        "current_running": running_state["current_running"],
        "days": running_state.get("days"),
        "custom_path": running_state.get("custom_path")
    }), 200

@program_bp.route('/confirm-run', methods=['POST'])
def confirm_run():
    data = request.json
    card = data.get('card')

    try:
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT input_path FROM processing_config WHERE id = 1')
            config = cursor.fetchone()
            video_root = config[0] if config else os.path.join(BASE_DIR, "Inputvideo")
            conn.close()
    except Exception as e:
        return jsonify({"error": f"Failed to read processing_config: {str(e)}"}), 500

    if not os.path.exists(video_root):
        try:
            os.makedirs(video_root, exist_ok=True)
            print(f"Created video root directory: {video_root}")
        except Exception as e:
            print(f"Failed to create video root directory: {video_root}, error: {str(e)}")
            video_root = os.path.join(BASE_DIR, "Inputvideo")

    if card == "Lần đầu":
        try:
            with db_rwlock.gen_rlock():
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute('SELECT value FROM program_status WHERE id = 1')
                result = cursor.fetchone()
                first_run_completed = result[0] == 'true' if result else False
                conn.close()
            if first_run_completed:
                return jsonify({"error": "Lần đầu đã chạy trước đó, không thể chạy lại"}), 400
        except Exception as e:
            return jsonify({"error": f"Failed to check first run status: {str(e)}"}), 500

    scan_action = "first" if card == "Lần đầu" else "default" if card == "Mặc định" else "custom"
    days = running_state.get("days") if card == "Lần đầu" else None
    custom_path = running_state.get("custom_path", '') if card == "Chỉ định" else ''

    try:
        new_files = list_files(video_root, scan_action, custom_path, days, DB_PATH)
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT file_path FROM file_list WHERE is_processed = 0 ORDER BY priority DESC, created_at ASC")
            unprocessed_files = [row[0] for row in cursor.fetchall()]
            conn.close()
        video_files = list(set(new_files + unprocessed_files))
        if video_files:
            frame_sampler_event.set()
    except Exception as e:
        return jsonify({"error": f"Failed to list files: {str(e)}"}), 500

    return jsonify({
        "message": f"Files queued for {scan_action}",
        "files": video_files,
        "program_type": scan_action
    }), 200

@program_bp.route('/program-progress', methods=['GET'])
def get_program_progress():
    try:
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT file_path, status FROM file_list WHERE is_processed = 0 ORDER BY created_at ASC")
            files_status = [{"file": row[0], "status": row[1]} for row in cursor.fetchall()]
            conn.close()
        return jsonify({"files": files_status}), 200
    except Exception as e:
        return jsonify({"error": f"Failed to retrieve program progress: {str(e)}"}), 500

@program_bp.route('/check-first-run', methods=['GET'])
def check_first_run():
    try:
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT value FROM program_status WHERE id = 1')
            result = cursor.fetchone()
            conn.close()
            first_run_completed = result[0] == 'true' if result else False
        return jsonify({"first_run_completed": first_run_completed}), 200
    except Exception as e:
        return jsonify({"error": f"Failed to check first run status: {str(e)}"}), 500

@program_bp.route('/get-cameras', methods=['GET'])
def get_cameras():
    try:
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT selected_cameras FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            conn.close()
            cameras = result[0] if result else "[]"
            cameras_list = json.loads(cameras)
        return jsonify({"cameras": cameras_list}), 200
    except Exception as e:
        return jsonify({"error": f"Failed to retrieve cameras: {str(e)}"}), 500

@program_bp.route('/get-camera-folders', methods=['GET'])
def get_camera_folders():
    try:
        with db_rwlock.gen_rlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT input_path FROM processing_config WHERE id = 1")
            result = cursor.fetchone()
            video_root = result[0] if result else os.path.join(BASE_DIR, "Inputvideo")
            conn.close()

        if not os.path.exists(video_root):
            return jsonify({"folders": []}), 200

        folders = []
        for folder_name in os.listdir(video_root):
            folder_path = os.path.join(video_root, folder_name)
            if os.path.isdir(folder_path):
                folders.append({"name": folder_name, "path": folder_path})
        return jsonify({"folders": folders}), 200
    except Exception as e:
        return jsonify({"error": f"Failed to retrieve camera folders: {str(e)}"}), 500
```
## 📄 File: `file_parser.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/utils/file_parser.py`

```python
import pandas as pd
import base64
import os
from io import BytesIO
import logging
import csv

# Thiết lập logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def force_split_excel_text(df: pd.DataFrame) -> pd.DataFrame:
    if df.shape[1] == 1 and isinstance(df.columns[0], str) and "\t" in df.columns[0]:
        raw = df.to_csv(index=False, header=False)
        reader = csv.reader(raw.splitlines(), delimiter='\t')
        rows = list(reader)
        df_fixed = pd.DataFrame(rows[1:], columns=rows[0])
        logger.debug(f"[DEBUG] After force_split_excel_text - df.columns: {df_fixed.columns.tolist()}")
        logger.debug(f"[DEBUG] After force_split_excel_text - df.shape: {df_fixed.shape}")
        return df_fixed
    return df

def parse_uploaded_file(file_content: str = None, file_path: str = None, is_excel: bool = False) -> pd.DataFrame:
    """
    Decode base64-encoded file content or read from file path and return a pandas DataFrame.
    Supports both CSV and Excel formats.
    Raises detailed exceptions instead of falling back silently.
    """
    logger.debug(f"parse_uploaded_file called with is_excel={is_excel}, file_content={'provided' if file_content else 'not provided'}, file_path={file_path}")

    if not file_content and not file_path:
        raise ValueError("Either file_content or file_path must be provided.")

    if file_content:
        try:
            file_bytes = base64.b64decode(file_content)
        except Exception as e:
            raise ValueError(f"Failed to decode base64 content: {e}")
        buffer = BytesIO(file_bytes)
    elif file_path:
        if not os.path.exists(file_path):
            raise ValueError(f"File not found at path: {file_path}")
        buffer = file_path  # pandas can read directly from file path

    try:
        if is_excel:
            logger.debug("Reading file as Excel (pd.read_excel)")
            try:
                df = pd.read_excel(buffer, header=None, engine='openpyxl')  # Xóa encoding
            except Exception as e:
                logger.debug(f"Failed to read Excel with pd.read_excel: {str(e)}")
                logger.debug("Falling back to pd.read_csv")
                buffer.seek(0)  # Reset con trỏ file để đọc lại
                df = pd.read_csv(buffer, sep=",", encoding='utf-8-sig', engine='python')
            logger.debug(f"[DEBUG] Raw DataFrame before processing: {df.to_dict()}")
            logger.debug(f"[DEBUG] Raw first row (potential header): {df.iloc[0].tolist()}")
            if df.shape[0] > 1:
                df.columns = df.iloc[0].values.tolist()
                df = df[1:]
                df = force_split_excel_text(df)  # Fix nếu dính lỗi tab
            else:
                raise ValueError("Excel file missing header/data")
            logger.debug(f"[DEBUG] df.columns: {df.columns.tolist()}")
            logger.debug(f"[DEBUG] df.shape: {df.shape}")
            logger.debug(f"[DEBUG] df.head(2): {df.head(2).to_dict()}")
            return df
        else:
            logger.debug("Reading file as CSV (pd.read_csv)")
            try:
                df = pd.read_csv(buffer, sep=",", encoding='latin1', engine='python')  # Thử dấu phẩy trước
                # Kiểm tra nếu chỉ có 1 cột và cột đó chứa dấu ;
                if len(df.columns) == 1 and df.columns[0] and isinstance(df.columns[0], str) and ";" in df.columns[0]:
                    logger.debug("Detected single column with semicolon, retrying with sep=';'")
                    if file_content:
                        buffer.seek(0)  # Reset con trỏ file để đọc lại nếu dùng file_content
                    df = pd.read_csv(buffer, sep=";", encoding='latin1', engine='python')
                return df
            except pd.errors.ParserError:
                if file_content:
                    buffer.seek(0)  # Reset con trỏ file để đọc lại nếu dùng file_content
                return pd.read_csv(buffer, sep=";", encoding='latin1', engine='python')  # Nếu lỗi, thử dấu chấm phẩy
    except Exception as e:
        file_type = 'Excel' if is_excel else 'CSV'
        raise ValueError(f"Failed to read {file_type} file: {e}")
```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/utils/__init__.py`

```python

```
## 📄 File: `LicenseGuard.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/system/LicenseGuard.py`

```python
# LicenseGuard.py - Module kiểm tra bản quyền (QR watermark, MAC address)

```
## 📄 File: `SystemMonitor.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/system/SystemMonitor.py`

```python
# SystemMonitor.py - Module theo dõi hiệu suất và tài nguyên hệ thống

```
## 📄 File: `SystemCalendar.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/system/SystemCalendar.py`

```python
# SystemCalendar.py - Module quản lý lịch làm việc (ngày nghỉ, ca làm việc)

```
## 📄 File: `AuditLogger.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/system/AuditLogger.py`

```python
# AuditLogger.py - Module ghi log hệ thống (lịch sử xử lý, lỗi, người dùng)

```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/db_utils/__init__.py`

```python
from .db_utils import find_project_root, get_db_connection
```
## 📄 File: `db_utils.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/db_utils/db_utils.py`

```python
import sqlite3
import os

# Hàm tìm thư mục gốc dự án dựa trên tên thư mục
def find_project_root(start_path):
    current_path = os.path.abspath(start_path)
    while os.path.basename(current_path) != "V_Track":
        parent_path = os.path.dirname(current_path)
        if parent_path == current_path:  # Đã đến thư mục gốc của hệ thống (/)
            raise ValueError("Could not find project root (V_Track directory)")
        current_path = parent_path
    return current_path

# Xác định thư mục gốc của dự án
BASE_DIR = find_project_root(os.path.abspath(__file__))

# Định nghĩa DB_PATH mặc định dựa trên BASE_DIR
DEFAULT_DB_PATH = os.path.join(BASE_DIR, "backend/database", "events.db")
os.makedirs(os.path.dirname(DEFAULT_DB_PATH), exist_ok=True)  # Tạo thư mục database nếu chưa có

# Hàm lấy DB_PATH từ processing_config
def get_db_path():
    try:
        conn = sqlite3.connect(DEFAULT_DB_PATH)  # Kết nối tạm thời để truy vấn
        cursor = conn.cursor()
        cursor.execute("SELECT db_path FROM processing_config WHERE id = 1")
        result = cursor.fetchone()
        conn.close()
        return result[0] if result else DEFAULT_DB_PATH
    except Exception as e:
        print(f"Error getting DB_PATH from database: {e}")
        return DEFAULT_DB_PATH

DB_PATH = get_db_path()

def get_db_connection():
    if not os.path.exists(DB_PATH):
        raise FileNotFoundError(f"Database file not found: {DB_PATH}")
    if not os.access(DB_PATH, os.R_OK):
        raise PermissionError(f"No read permission for database: {DB_PATH}")
    if not os.access(DB_PATH, os.W_OK):
        raise PermissionError(f"No write permission for database: {DB_PATH}")
    return sqlite3.connect(DB_PATH, check_same_thread=False)
```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/account/__init__.py`

```python

```
## 📄 File: `account.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/account/account.py`

```python

```
## 📄 File: `query.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/query/query.py`

```python
from flask import Blueprint, request, jsonify
from datetime import datetime
import csv
import io
import os
import base64
import pandas as pd
import json
from io import BytesIO
from modules.db_utils import find_project_root, get_db_connection
from ..utils.file_parser import parse_uploaded_file
from modules.scheduler.db_sync import db_rwlock  # Thêm import db_rwlock

query_bp = Blueprint('query', __name__)

# Xác định thư mục gốc của dự án
BASE_DIR = find_project_root(os.path.abspath(__file__))

# Định nghĩa DB_PATH dựa trên BASE_DIR
DB_PATH = os.path.join(BASE_DIR, "database", "events.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

@query_bp.route('/get-csv-headers', methods=['POST'])
def get_csv_headers():
    data = request.get_json()
    file_content = data.get('file_content', '')
    file_path = data.get('file_path', '')
    is_excel = data.get('is_excel', False)

    if file_content:
        if not file_content.strip():
            return jsonify({"error": "File CSV is empty. Please provide a valid CSV file with content."}), 400

        try:
            df = parse_uploaded_file(file_content=file_content, is_excel=is_excel)
            rows = [df.columns.tolist()]
        except Exception as e:
            return jsonify({"error": f"Failed to read file content: {str(e)}. Ensure the content is properly formatted."}), 400
    elif file_path:
        if not os.path.exists(file_path):
            return jsonify({"error": f"File not found at path: {file_path}. Please check the file path and try again."}), 404

        try:
            with open(file_path, "rb") as f:
                file_content = base64.b64encode(f.read()).decode("utf-8")
            df = parse_uploaded_file(file_content=file_content, is_excel=is_excel)
            rows = [df.columns.tolist()]
        except Exception as e:
            return jsonify({"error": f"Failed to read file from path {file_path}: {str(e)}. Ensure the file is accessible and properly formatted."}), 400
    else:
        return jsonify({"error": "No file content or path provided. Please provide either file content or a valid file path."}), 400

    if not rows or len(rows) < 1:
        return jsonify({"error": "CSV file has no header. Please ensure the CSV file contains at least one row with headers."}), 400

    header = rows[0]
    if not header:
        return jsonify({"error": "CSV file header is empty. Please ensure the first row contains valid headers."}), 400

    return jsonify({"headers": header}), 200

@query_bp.route('/parse-csv', methods=['POST'])
def parse_csv():
    data = request.get_json()
    file_content = data.get('file_content', '')
    file_path = data.get('file_path', '')
    column_name = data.get('column_name', 'tracking_codes')
    is_excel = data.get('is_excel', False)

    try:
        if file_content:
            df = parse_uploaded_file(file_content=file_content, is_excel=is_excel)
        elif file_path:
            with open(file_path, "rb") as f:
                file_content = base64.b64encode(f.read()).decode("utf-8")
            df = parse_uploaded_file(file_content=file_content, is_excel=is_excel)
        else:
            return jsonify({"error": "No file provided"}), 400

        if column_name not in df.columns:
            return jsonify({"error": f"Cột '{column_name}' không tồn tại trong file."}), 400

        values = df[column_name].dropna().astype(str).tolist()
        codes = []
        for val in values:
            # Thử cắt chuỗi theo dấu phẩy trước
            split_vals = val.split(',')
            if len(split_vals) == 1:  # Nếu không cắt được, thử dấu chấm phẩy
                split_vals = val.split(';')
            codes.extend(v.strip() for v in split_vals if v.strip())
        codes = list(set(codes))  # Loại bỏ trùng lặp

        return jsonify({"tracking_codes": codes}), 200

    except Exception as e:
        return jsonify({"error": f"Failed to parse CSV: {str(e)}. Ensure the file and column name are valid."}), 500

@query_bp.route('/query', methods=['POST'])
def query_events():
    data = request.get_json()
    print(f"Received data: {data}")  # Log dữ liệu nhận được
    search_string = data.get('search_string', '')
    default_days = data.get('default_days', 7)  # Thêm giá trị mặc định 7 nếu không có trong request
    from_time = data.get('from_time')
    to_time = data.get('to_time')
    selected_cameras = data.get('selected_cameras', [])  # Lấy selected_cameras

    # Tách search_string theo dòng và loại bỏ số thứ tự
    tracking_codes = []
    if search_string:
        lines = search_string.splitlines()
        for line in lines:
            line = line.strip()
            if line:
                # Loại bỏ số thứ tự (e.g., "1. " hoặc "2. ")
                code = line.split('. ', 1)[-1].strip()
                if code:
                    tracking_codes.append(code)
    print(f"Parsed tracking_codes from search_string: {tracking_codes}")  # Log tracking_codes đã tách

    try:
        if from_time and to_time:
            try:
                from_timestamp = int(datetime.fromisoformat(from_time.replace('Z', '+00:00')).timestamp() * 1000)
                to_timestamp = int(datetime.fromisoformat(to_time.replace('Z', '+00:00')).timestamp() * 1000)
            except ValueError as e:
                return jsonify({"error": f"Invalid time format for from_time or to_time: {str(e)}. Use ISO format (e.g., 2023-10-01T00:00:00Z)."}), 400
        else:
            to_timestamp = int(datetime.now().timestamp() * 1000)
            from_timestamp = to_timestamp - (default_days * 24 * 60 * 60 * 1000)
        print(f"Time range: from_timestamp={from_timestamp}, to_timestamp={to_timestamp}")  # Log khoảng thời gian

        with db_rwlock.gen_rlock():  # Thêm khóa đọc
            conn = get_db_connection()
            cursor = conn.cursor()

            query = """
                SELECT event_id, ts, te, duration, tracking_codes, video_file, packing_time_start, packing_time_end
                FROM events
                WHERE is_processed = 0
            """
            params = []
            # Chỉ thêm điều kiện thời gian nếu packing_time_start không null
            if from_timestamp and to_timestamp:
                query += " AND (packing_time_start IS NULL OR (packing_time_start >= ? AND packing_time_start <= ?))"
                params.extend([from_timestamp, to_timestamp])
            if selected_cameras:
                query += " AND camera_name IN ({})".format(','.join('?' * len(selected_cameras)))
                params.extend(selected_cameras)

            print(f"Executing query: {query} with params: {params}")  # Log truy vấn
            cursor.execute(query, params)
            events = cursor.fetchall()
            print(f"Fetched events: {events}")  # Log kết quả truy vấn

            filtered_events = []
            for event in events:
                event_dict = {
                    'event_id': event[0],
                    'ts': event[1],
                    'te': event[2],
                    'duration': event[3],
                    'tracking_codes': event[4],
                    'video_file': event[5],
                    'packing_time_start': event[6],
                    'packing_time_end': event[7]
                }
                print(f"Raw tracking_codes for event {event[0]}: {event[4]}")  # Log giá trị thô của tracking_codes
                try:
                    tracking_codes_list = json.loads(event[4]) if event[4] else []
                    if not isinstance(tracking_codes_list, list):
                        raise ValueError("tracking_codes is not a list")
                except Exception:
                    print(f"[WARN] tracking_codes fallback for event {event[0]}")
                    tracking_codes_list = []
                    if event[4]:
                        raw = event[4].strip("[]").replace("'", "").replace('"', "")
                        tracking_codes_list = [code.strip() for code in raw.split(',')]
                print(f"Parsed tracking_codes for event {event[0]}: {tracking_codes_list}")  # Log tracking_codes đã parse
                if not tracking_codes:
                    filtered_events.append(event_dict)
                else:
                    for code in tracking_codes:
                        if code in tracking_codes_list:
                            filtered_events.append(event_dict)
                            break
            print(f"Filtered events: {filtered_events}")  # Log kết quả sau khi lọc

            conn.close()
        return jsonify({'events': filtered_events}), 200
    except Exception as e:
        print(f"Error in query_events: {str(e)}")  # Log lỗi chi tiết
        return jsonify({"error": f"Failed to query events: {str(e)}. Ensure the database is accessible and the events table exists."}), 500
```
## 📄 File: `results.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/query/results.py`

```python

```
## 📄 File: `__init__.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/query/__init__.py`

```python

```
## 📄 File: `heatmap.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/heatmap.py`

```python
import os
import sqlite3
from datetime import datetime
import pathlib

# Cấu hình khung
frame_width = 1280
frame_height = 720
qr_frames = []
frame_id = 1
MAX_BLOCKS = 90
EVALUATE_EVERY = 10
is_r1_confirmed = False

# Cấu hình vùng
R1 = []
R1_zones = []
R2_groups = []
R2_zone_lists = []
R2_MIN_QR = 5

def create_expanded_zone(x, y, size=100):
    return (x - size // 2, y - size // 2, size, size)

def is_overlapping_zone(x, y, zones):
    zx, zy, zw, zh = create_expanded_zone(x, y)
    for (ox, oy, ow, oh) in zones:
        if not (zx + zw < ox or ox + ow < zx or zy + zh < oy or oy + oh < zy):
            return True
    return False

def cluster_remaining_qrs(qrs):
    clusters, zones = [], []
    for (x, y) in qrs:
        added = False
        for idx, cluster in enumerate(clusters):
            if is_overlapping_zone(x, y, zones[idx]):
                cluster.append((x, y))
                zones[idx].append(create_expanded_zone(x, y))
                added = True
                break
        if not added:
            clusters.append([(x, y)])
            zones.append([create_expanded_zone(x, y)])
    return [(c, z) for c, z in zip(clusters, zones) if len(c) >= R2_MIN_QR]

def compute_bounding_box_from_zones(zones):
    if not zones:
        return (0, 0, 0, 0)
    x1s = [x for x, y, w, h in zones]
    y1s = [y for x, y, w, h in zones]
    x2s = [x + w for x, y, w, h in zones]
    y2s = [y + h for x, y, w, h in zones]
    return min(x1s), min(y1s), max(x2s) - min(x1s), max(y2s) - min(y1s)

def compute_area_percent(w, h):
    return round((w * h) / (frame_width * frame_height) * 100, 2)

def get_log_dir():
    """Lấy đường dẫn thư mục LOG từ processing_config hoặc mặc định."""
    # Tìm thư mục gốc V_Track
    base_dir = pathlib.Path(__file__).parent
    while base_dir.name != 'V_Track' and base_dir.parent != base_dir:
        base_dir = base_dir.parent
    
    # Đường dẫn đến events.db
    db_path = base_dir / "backend" / "database" / "events.db"

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT output_path FROM processing_config WHERE id = 1")
        result = cursor.fetchone()
        output_path = result[0] if result else None
        conn.close()
    except sqlite3.Error:
        output_path = None
    
    if not output_path:
        # Đường dẫn mặc định: resources/output_clips từ thư mục gốc V_Track
        output_path = base_dir / "resources" / "output_clips"

    log_dir = os.path.join(output_path, "LOG", "QR")
    os.makedirs(log_dir, exist_ok=True)
    return log_dir

def evaluate_regions_with_r1_correction():
    global R1, R1_zones, R2_groups, R2_zone_lists, is_r1_confirmed
    print("🔍 Đánh giá QR mới. R1 sẽ được hiệu chỉnh nếu cần.")
    all_qrs = [qr for frame in qr_frames for qr in frame['qr_points']]
    evaluated = set()

    clustered = cluster_remaining_qrs(all_qrs)
    if not clustered:
        print("⚠️ Không tìm thấy cụm nào đủ QR.")
        return
    clustered.sort(key=lambda c: len(c[0]), reverse=True)
    largest_cluster = clustered[0]

    if not is_r1_confirmed:
        R1 = largest_cluster[0]
        R1_zones = largest_cluster[1]
        is_r1_confirmed = True
        print(f"✅ Khởi tạo R1 từ cụm lớn nhất (QR: {len(R1)})")
    else:
        if len(largest_cluster[0]) > len(R1):
            print(f"🔁 Cập nhật R1 vì cụm mới lớn hơn ({len(largest_cluster[0])} > {len(R1)})")
            R1 = largest_cluster[0]
            R1_zones = largest_cluster[1]

    # Phân cụm còn lại cho R2
    R2_groups = []
    R2_zone_lists = []
    for c, z in clustered[1:]:
        if len(c) >= R2_MIN_QR:
            R2_groups.append(c)
            R2_zone_lists.append(z)

def load_qr_points_from_file(filepath):
    global qr_frames, frame_id
    qr_frames = []
    with open(filepath, "r") as f:
        lines = f.readlines()
    for idx, line in enumerate(lines):
        x, y = map(int, line.strip().split(","))
        qr_frames.append({'frame_id': idx + 1, 'qr_points': [(x, y)]})
    frame_id = len(qr_frames) + 1
    evaluate_regions_with_r1_correction()

    # Tính toán và lưu kết quả R1, R2, R3 vào log
    log_dir = get_log_dir()
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_filename = os.path.join(log_dir, f"heatmap_regions_{timestamp}.txt")
    
    total_area = frame_width * frame_height
    used_area = 0
    log_lines = [f"Heatmap Results (File: {filepath})"]

    # Tính R1
    if R1_zones:
        rx, ry, rw, rh = compute_bounding_box_from_zones(R1_zones)
        used_area += rw * rh
        r1_pct = compute_area_percent(rw, rh)
        log_lines.append(f"R1: Bounding Box [x={rx}, y={ry}, w={rw}, h={rh}], Area: {r1_pct}%")
    else:
        log_lines.append("R1: Not found")

    # Tính R2
    r2_total = 0
    for i, group in enumerate(R2_groups):
        rx, ry, rw, rh = compute_bounding_box_from_zones([create_expanded_zone(x, y) for (x, y) in group])
        area_pct = compute_area_percent(rw, rh)
        r2_total += rw * rh
        log_lines.append(f"R2.{i+1}: Bounding Box [x={rx}, y={ry}, w={rw}, h={rh}], Area: {area_pct}%")
    if not R2_groups:
        log_lines.append("R2: Not found")

    # Tính R3
    r3_area = total_area - used_area - r2_total
    r3_pct = round(r3_area / total_area * 100, 2)
    log_lines.append(f"R3: Area: {r3_pct}%")

    # Ghi log
    with open(log_filename, 'w') as f:
        for line in log_lines:
            f.write(f"{line}\n")

    print(f"Heatmap regions saved to: {log_filename}")
    return log_filename

def main():
    # Nhập đường dẫn file heatmap_input từ người dùng
    filepath = input("Enter heatmap input file path (e.g., /Users/annhu/vtrack_app/V_Track/resources/output_clips/LOG/QR/heatmap_input_YYYYMMDD_HHMMSS.txt): ")
    if not os.path.exists(filepath):
        print(f"Error: File {filepath} does not exist.")
        return
    log_file = load_qr_points_from_file(filepath)
    print(f"Results saved to: {log_file}")

if __name__ == "__main__":
    main()
```
## 📄 File: `event_detector.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/event_detector.py`

```python
from flask import Blueprint, jsonify
import os
import sqlite3
from datetime import datetime
from modules.db_utils import get_db_connection
from modules.scheduler.db_sync import db_rwlock  # Thêm import db_rwlock

event_detector_bp = Blueprint('event_detector', __name__)

def calculate_duration(ts, te):
    if ts is None or te is None:
        return None
    if te < ts:
        return None
    return te - ts

def process_single_log(log_file_path):
    try:
        with db_rwlock.gen_wlock():  # Thêm khóa ghi
            conn = get_db_connection()
            cursor = conn.cursor()

            with open(log_file_path, "r") as f:
                header = f.readline().strip()
                print(f"Header: {header}")
                start_time = int(header.split("Start: ")[1].split(",")[0])
                end_time = int(header.split("End: ")[1].split(",")[0])
                start_time_str = header.split("Start_Time: ")[1].split(",")[0].strip()
                camera_name = header.split("Camera_Name: ")[1].split(",")[0].strip()
                video_path = header.split("Video_File: ")[1].split(",")[0].strip()
                start_time_dt = datetime.strptime(start_time_str, "%Y-%m-%d %H:%M:%S")
                print(f"Parsed header - Start: {start_time}, End: {end_time}, Start_Time: {start_time_str}, Camera_Name: {camera_name}, Video_File: {video_path}")

                # Kiểm tra nếu file log rỗng
                first_data_line = f.readline().strip()
                if not first_data_line:
                    print(f"Log file {log_file_path} is empty, skipping")
                    cursor.execute("UPDATE processed_logs SET is_processed = 1, processed_at = ? WHERE log_file = ?", (datetime.now(), log_file_path))
                    conn.commit()
                    conn.close()
                    return

                # Nếu có dữ liệu, quay lại và xử lý
                f.seek(0)
                next(f)
                frame_sampler_data = []
                for line in f:
                    parts = line.strip().split(",")
                    try:
                        second, state = parts[0], parts[1]
                        codes = [parts[2]] if len(parts) > 2 and parts[2] else []
                        frame_sampler_data.append({"second": float(second), "state": state, "tracking_codes": codes})
                    except Exception as e:
                        print(f"Error parsing line '{line.strip()}': {str(e)}")
            print(f"Frame sampler data (first 5 entries): {frame_sampler_data[:5]}")
            print(f"Total entries in frame_sampler_data: {len(frame_sampler_data)}")

            # Lấy min_packing_time từ Processing_config
            cursor.execute("SELECT min_packing_time FROM Processing_config LIMIT 1")
            min_packing_time_row = cursor.fetchone()
            min_packing_time = min_packing_time_row[0] if min_packing_time_row else 0  # Mặc định 0 nếu không có
            print(f"Min packing time: {min_packing_time}")

            cursor.execute("SELECT event_id, ts, tracking_codes, video_file FROM events WHERE te IS NULL ORDER BY ts DESC LIMIT 1")
            pending_event = cursor.fetchone()
            print(f"Pending event: {pending_event}")
            ts = pending_event[1] if pending_event else None
            pending_tracking_codes = eval(pending_event[2]) if pending_event and pending_event[2] else []
            pending_video_file = pending_event[3] if pending_event else None
            event_id = pending_event[0] if pending_event else None
            segments = []
            prev_state = None
            has_pending = ts is not None

            for data in frame_sampler_data:
                current_state = data["state"]
                current_second = data["second"]
                current_tracking_codes = data["tracking_codes"]

                if has_pending and ts is not None:
                    if current_state == "On":
                        te = current_second
                        duration = calculate_duration(ts, te)
                        if pending_video_file == video_path:
                            segments.append((ts, te, duration, pending_tracking_codes + current_tracking_codes, video_path, event_id))
                        else:
                            segments.append((None, te, duration, pending_tracking_codes + current_tracking_codes, video_path, None))
                        ts = None
                        has_pending = False
                    elif current_state == "Off":
                        pending_tracking_codes.extend([code for code in current_tracking_codes if code and code not in pending_tracking_codes])
                elif not has_pending:
                    if prev_state == "On" and current_state == "Off":
                        ts = current_second
                        pending_tracking_codes = current_tracking_codes[:]
                        print(f"Phát hiện sự kiện Ts tại giây {current_second}")
                    elif prev_state == "Off" and current_state == "On" and ts is not None:
                        te = current_second
                        duration = calculate_duration(ts, te)
                        if duration >= min_packing_time:  # Loại bỏ nếu duration < min_packing_time
                            segments.append((ts, te, duration, pending_tracking_codes + current_tracking_codes, video_path, None))
                            print(f"Giây {current_second}: Ts={ts}, Te={te}, Duration={duration}")
                        else:
                            print(f"Loại bỏ sự kiện: Ts={ts}, Te={te}, Duration={duration} < min_packing_time={min_packing_time}")
                        ts = None
                        pending_tracking_codes = []
                    elif ts is not None and current_state == "Off":
                        pending_tracking_codes.extend([code for code in current_tracking_codes if code and code not in pending_tracking_codes])

                prev_state = current_state

            if ts is not None:
                segments.append((ts, None, None, pending_tracking_codes, video_path, None))
                print(f"Giây {frame_sampler_data[-1]['second']}: Ts={ts}, Te=Not finished")

            print(f"All segments detected: {segments}")

            for segment in segments:
                ts, te, duration, tracking_codes, segment_video_path, segment_event_id = segment
                packing_time_start = int((start_time_dt.timestamp() + ts) * 1000) if ts is not None else None
                packing_time_end = int((start_time_dt.timestamp() + te) * 1000) if te is not None else None
                if segment_event_id is not None:
                    cursor.execute("UPDATE events SET te=?, duration=?, tracking_codes=?, packing_time_end=? WHERE event_id=?",
                                   (te, duration, str(tracking_codes), packing_time_end, segment_event_id))
                    print(f"Updated event_id {segment_event_id}: ts={ts}, te={te}, duration={duration}")
                else:
                    cursor.execute('''INSERT INTO events (ts, te, duration, tracking_codes, video_file, buffer, camera_name, packing_time_start, packing_time_end)
                                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                                   (ts, te, duration, str(tracking_codes), segment_video_path, 0, camera_name, packing_time_start, packing_time_end))
                    print(f"Inserted new event: ts={ts}, te={te}, duration={duration}")

            cursor.execute("UPDATE processed_logs SET is_processed = 1, processed_at = ? WHERE log_file = ?", (datetime.now(), log_file_path))
            conn.commit()
            print("Database changes committed")

    except Exception as e:
        print(f"Error in process_single_log: {str(e)}")
        raise
    finally:
        conn.close()

@event_detector_bp.route('/process-events', methods=['GET'])
def process_events():
    try:
        with db_rwlock.gen_rlock():  # Thêm khóa đọc
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT log_file_path FROM file_list WHERE is_processed = 1 AND log_file_path IS NOT NULL")
            log_files = [row[0] for row in cursor.fetchall()]
            print(f"Log files to process: {log_files}")
            conn.close()

        for log_file in log_files:
            if os.path.exists(log_file):
                print(f"Starting to process file: {log_file}")
                process_single_log(log_file)
                print(f"Finished processing file: {log_file}")
            else:
                print(f"File not found: {log_file}")

        return jsonify({"message": "Event detection completed successfully"}), 200
    except Exception as e:
        print(f"Error in process_events: {str(e)}")
        return jsonify({"error": str(e)}), 500
```
## 📄 File: `PackingConfigDetector.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/PackingConfigDetector.py`

```python
import cv2
import pyzbar.pyzbar as pyzbar
import numpy as np
import logging
import argparse
import json
import sqlite3

# Cài đặt logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger()

def pixel_to_cm(pixels, pixel_per_cm):
    return pixels / pixel_per_cm

def find_timego_qr(frame, qr_real_size_cm):
    # Lấy kích thước khung hình
    height, width = frame.shape[:2]
    frame_center = (width // 2, height // 2)
    
    # Chuyển frame sang grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Bỏ CLAHE, chỉ dùng grayscale để nhận diện QR
    qr_codes = pyzbar.decode(gray)
    
    timego_qrs = []
    for qr in qr_codes:
        if qr.data.decode('utf-8').lower() == 'timego':
            x, y, w, h = qr.rect
            qr_center = (x + w // 2, y + h // 2)
            # Tính khoảng cách đến trung tâm khung hình
            distance = np.sqrt((qr_center[0] - frame_center[0])**2 + (qr_center[1] - frame_center[1])**2)
            timego_qrs.append({
                'rect': (x, y, w, h),
                'center': qr_center,
                'distance': distance
            })
    
    if len(timego_qrs) < 1:
        return {'qr_found': False}
    
    # Sắp xếp theo khoảng cách đến trung tâm
    timego_qrs.sort(key=lambda x: x['distance'])
    
    results = []
    for idx, qr in enumerate(timego_qrs[:2]):  # Chỉ xử lý tối đa 2 mã QR
        x, y, w, h = qr['rect']
        pixel_per_cm = w / qr_real_size_cm  # Giả sử QR vuông
        qr_width_cm = pixel_to_cm(w, pixel_per_cm)
        qr_height_cm = pixel_to_cm(h, pixel_per_cm)
        qr_center = qr['center']
        
        # Xác định loại QR và tỷ lệ mở rộng
        if idx == 0:  # QR Trigger (gần trung tâm nhất)
            qr_type = 'trigger'
            scale = 1.3  # Mở rộng 30%
        else:  # QR mã vận đơn
            qr_type = 'mvd'
            scale = 1.1  # Mở rộng 10%
        
        # Tính kích thước vùng (pixel)
        region_width_px = w * scale
        region_height_px = h * scale
        
        # Tính tọa độ vùng quét
        top_left = [int(qr_center[0] - region_width_px / 2), int(qr_center[1] - region_height_px / 2)]
        bottom_right = [int(qr_center[0] + region_width_px / 2), int(qr_center[1] + region_height_px / 2)]
        
        results.append({
            'qr_type': qr_type,
            'top_left': top_left,
            'bottom_right': bottom_right,
            'pixel_per_cm': pixel_per_cm
        })
    
    # Tính vùng đóng gói (dựa trên QR Trigger)
    if results:
        trigger = results[0]  # QR Trigger luôn là kết quả đầu tiên
        trigger_w_px = trigger['bottom_right'][0] - trigger['top_left'][0]
        trigger_h_px = trigger['bottom_right'][1] - trigger['top_left'][1]
        trigger_center = [
            (trigger['top_left'][0] + trigger['bottom_right'][0]) // 2,
            (trigger['top_left'][1] + trigger['bottom_right'][1]) // 2
        ]
        packing_scale = 2.0  # Mở rộng 200%
        packing_width_px = trigger_w_px * packing_scale
        packing_height_px = trigger_h_px * packing_scale
        packing_top_left = [int(trigger_center[0] - packing_width_px / 2), int(trigger_center[1] - packing_height_px / 2)]
        packing_bottom_right = [int(trigger_center[0] + packing_width_px / 2), int(trigger_center[1] + packing_height_px / 2)]
        
        results.append({
            'qr_type': 'packing',
            'top_left': packing_top_left,
            'bottom_right': packing_bottom_right,
            'pixel_per_cm': trigger['pixel_per_cm']
        })
    
    return {
        'qr_found': True,
        'qrs': results
    }

def main():
    # Nhận đường dẫn video và kích thước QR từ terminal
    parser = argparse.ArgumentParser(description="QR Timego Detector")
    parser.add_argument('--video', type=str, required=True, help="Đường dẫn đến video")
    parser.add_argument('--qr-size', type=float, required=True, help="Kích thước thực tế của QR (cm)")
    parser.add_argument('--profile-name', type=str, default='default_profile', help="Tên profile để lưu vào CSDL")
    parser.add_argument('--db-path', type=str, default='packing.db', help="Đường dẫn đến file CSDL SQLite")
    args = parser.parse_args()
    
    # Đọc video
    cap = cv2.VideoCapture(args.video)
    if not cap.isOpened():
        logger.error("Không mở được video")
        return
    
    # Lấy thông tin video
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = frame_count / fps if fps > 0 else 0
    
    # Kiểm tra độ dài video (5s đến 1 phút)
    if duration < 5 or duration > 60:
        logger.warning("Video không nằm trong khoảng 5s đến 1 phút")
        return
    else:
        logger.info("Video phù hợp")
    
    # Tính bước nhảy để đọc 10 frame/s
    target_fps = 10
    step = max(1, int(fps / target_fps)) if fps > 0 else 1
    
    # Lưu kết quả từ các frame
    trigger_results = []
    mvd_results = []
    packing_results = []
    frame_idx = 0
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        # Chỉ xử lý frame theo bước nhảy
        if frame_idx % step == 0:
            result = find_timego_qr(frame, args.qr_size)
            if result['qr_found']:
                for qr in result['qrs']:
                    if qr['qr_type'] == 'trigger':
                        trigger_results.append(qr)
                    elif qr['qr_type'] == 'mvd':
                        mvd_results.append(qr)
                    elif qr['qr_type'] == 'packing':
                        packing_results.append(qr)
        
        frame_idx += 1
        # Giới hạn tối đa 600 frame (1 phút ở 10 frame/s)
        if frame_idx >= 600 * step:
            break
    
    cap.release()
    
    # Tổng hợp kết quả
    if not trigger_results:
        logger.error("Không tìm thấy QR timego (Trigger) trong video")
        return
    
    # Tính trung bình tọa độ cho QR Trigger
    trigger_top_left_x = np.mean([r['top_left'][0] for r in trigger_results])
    trigger_top_left_y = np.mean([r['top_left'][1] for r in trigger_results])
    trigger_bottom_right_x = np.mean([r['bottom_right'][0] for r in trigger_results])
    trigger_bottom_right_y = np.mean([r['bottom_right'][1] for r in trigger_results])
    trigger_pixel_per_cm = np.mean([r['pixel_per_cm'] for r in trigger_results])
    
    # Tính trung bình tọa độ cho QR mã vận đơn (nếu có)
    mvd_top_left_x = np.mean([r['top_left'][0] for r in mvd_results]) if mvd_results else 0
    mvd_top_left_y = np.mean([r['top_left'][1] for r in mvd_results]) if mvd_results else 0
    mvd_bottom_right_x = np.mean([r['bottom_right'][0] for r in mvd_results]) if mvd_results else 0
    mvd_bottom_right_y = np.mean([r['bottom_right'][1] for r in mvd_results]) if mvd_results else 0
    mvd_pixel_per_cm = np.mean([r['pixel_per_cm'] for r in mvd_results]) if mvd_results else 0
    
    # Tính trung bình tọa độ cho vùng đóng gói
    packing_top_left_x = np.mean([r['top_left'][0] for r in packing_results])
    packing_top_left_y = np.mean([r['top_left'][1] for r in packing_results])
    packing_bottom_right_x = np.mean([r['bottom_right'][0] for r in packing_results])
    packing_bottom_right_y = np.mean([r['bottom_right'][1] for r in packing_results])
    packing_pixel_per_cm = np.mean([r['pixel_per_cm'] for r in packing_results])
    
    # Log kết quả theo định dạng yêu cầu
    logger.info("Xác định 3 vùng:")
    logger.info(f"Vùng QR Trigger: top_left=({trigger_top_left_x:.0f}, {trigger_top_left_y:.0f}), bottom_right=({trigger_bottom_right_x:.0f}, {trigger_bottom_right_y:.0f})")
    if mvd_results:
        logger.info(f"Vùng QR mã vận đơn: top_left=({mvd_top_left_x:.0f}, {mvd_top_left_y:.0f}), bottom_right=({mvd_bottom_right_x:.0f}, {mvd_bottom_right_y:.0f})")
    logger.info(f"Vùng đóng gói: top_left=({packing_top_left_x:.0f}, {packing_top_left_y:.0f}), bottom_right=({packing_bottom_right_x:.0f}, {packing_bottom_right_y:.0f})")
    
    # Chuẩn bị dữ liệu để lưu vào CSDL
    trigger_area = {
        "top_left": [int(trigger_top_left_x), int(trigger_top_left_y)],
        "bottom_right": [int(trigger_bottom_right_x), int(trigger_bottom_right_y)]
    }
    mvd_area = {
        "top_left": [int(mvd_top_left_x), int(mvd_top_left_y)],
        "bottom_right": [int(mvd_bottom_right_x), int(mvd_bottom_right_y)]
    } if mvd_results else {"top_left": [0, 0], "bottom_right": [0, 0]}
    packing_area = {
        "top_left": [int(packing_top_left_x), int(packing_top_left_y)],
        "bottom_right": [int(packing_bottom_right_x), int(packing_bottom_right_y)]
    }
    
    # Chuyển đổi thành JSON string
    trigger_area_json = json.dumps(trigger_area)
    mvd_area_json = json.dumps(mvd_area)
    packing_area_json = json.dumps(packing_area)
    
    # Kết nối và lưu vào CSDL SQLite
    try:
        conn = sqlite3.connect(args.db_path)
        cursor = conn.cursor()
        
        # Chèn dữ liệu vào bảng packing_profiles
        cursor.execute('''
            INSERT INTO packing_profiles (
                profile_name, qr_trigger_area, qr_mvd_area, packing_area, 
                min_packing_time, jump_time_ratio, scan_mode, fixed_threshold, margin, additional_params
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            args.profile_name,
            trigger_area_json,
            mvd_area_json,
            packing_area_json,
            0,  # min_packing_time
            0.0,  # jump_time_ratio
            'default',  # scan_mode
            0,  # fixed_threshold
            0,  # margin
            '{}'  # additional_params
        ))
        
        conn.commit()
        logger.info("Đã lưu thông tin vùng vào CSDL thành công")
    
    except sqlite3.Error as e:
        logger.error(f"Lỗi khi lưu vào CSDL: {e}")
    
    finally:
        conn.close()

if __name__ == "__main__":
    main()
```
## 📄 File: `analyze_regions.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/analyze_regions.py`

```python
from flask import Blueprint, request, jsonify
import os
import cv2
import numpy as np
import sqlite3
import json
from .PackingConfigDetector import find_timego_qr
from modules.scheduler.db_sync import db_rwlock  # Thêm import db_rwlock

# Xác định đường dẫn gốc dự án
def find_project_root(current_path):
    while not os.path.exists(os.path.join(current_path, 'backend')):
        current_path = os.path.dirname(current_path)
        if current_path == os.path.dirname(current_path):  # Đã tới root của hệ thống file
            raise FileNotFoundError("Không tìm thấy thư mục gốc của dự án")
    return current_path

BASE_DIR = find_project_root(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "backend", "database", "events.db")  # Đường dẫn tương đối tới events.db

# Định nghĩa Blueprint
analyze_regions_bp = Blueprint('analyze_regions', __name__)

@analyze_regions_bp.route('/analyze-regions', methods=['POST'])
def analyze_regions():
    try:
        # Lấy dữ liệu từ request
        data = request.get_json()
        video_path = data.get('video_path')
        qr_size = data.get('qr_size')

        # Validate input
        if not video_path:
            return jsonify({"success": False, "message": "Thiếu video_path"}), 400

        # Sử dụng trực tiếp video_path (đường dẫn đầy đủ) thay vì chỉ lấy tên file
        full_video_path = video_path

        # Kiểm tra file có tồn tại không
        if not os.path.exists(full_video_path):
            return jsonify({"success": False, "message": f"Video không tồn tại tại {full_video_path}"}), 400

        if qr_size is None or not isinstance(qr_size, (int, float)) or qr_size <= 0:
            return jsonify({"success": False, "message": "Kích thước QR Timego phải là số dương"}), 400

        # Đọc video
        cap = cv2.VideoCapture(full_video_path)
        if not cap.isOpened():
            return jsonify({"success": False, "message": "Không mở được video"}), 400

        # Lấy thông tin video
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = frame_count / fps if fps > 0 else 0

        # Kiểm tra độ dài video (5s đến 1 phút)
        if duration < 5 or duration > 60:
            cap.release()
            return jsonify({"success": False, "message": "Video không nằm trong khoảng 5s đến 1 phút"}), 400

        # Tính bước nhảy để đọc 10 frame/s
        target_fps = 10
        step = max(1, int(fps / target_fps)) if fps > 0 else 1

        # Lưu kết quả từ các frame
        trigger_results = []
        mvd_results = []
        packing_results = []
        frame_idx = 0

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            # Chỉ xử lý frame theo bước nhảy
            if frame_idx % step == 0:
                result = find_timego_qr(frame, qr_size)
                if result['qr_found']:
                    for qr in result['qrs']:
                        if qr['qr_type'] == 'trigger':
                            trigger_results.append(qr)
                        elif qr['qr_type'] == 'mvd':
                            mvd_results.append(qr)
                        elif qr['qr_type'] == 'packing':
                            packing_results.append(qr)

            frame_idx += 1
            # Giới hạn tối đa 600 frame (1 phút ở 10 frame/s)
            if frame_idx >= 600 * step:
                break

        cap.release()

        # Kiểm tra kết quả
        if not trigger_results:
            return jsonify({"success": False, "message": "Không tìm thấy QR timego (Trigger) trong video"}), 400

        # Tính trung bình tọa độ cho QR Trigger
        trigger_top_left = [
            int(np.mean([r['top_left'][0] for r in trigger_results])),
            int(np.mean([r['top_left'][1] for r in trigger_results]))
        ]
        trigger_bottom_right = [
            int(np.mean([r['bottom_right'][0] for r in trigger_results])),
            int(np.mean([r['bottom_right'][1] for r in trigger_results]))
        ]

        # Tính trung bình tọa độ cho QR mã vận đơn (nếu có)
        mvd_top_left = [
            int(np.mean([r['top_left'][0] for r in mvd_results])),
            int(np.mean([r['top_left'][1] for r in mvd_results]))
        ] if mvd_results else [0, 0]
        mvd_bottom_right = [
            int(np.mean([r['bottom_right'][0] for r in mvd_results])),
            int(np.mean([r['bottom_right'][1] for r in mvd_results]))
        ] if mvd_results else [0, 0]

        # Tính trung bình tọa độ cho vùng đóng gói
        packing_top_left = [
            int(np.mean([r['top_left'][0] for r in packing_results])),
            int(np.mean([r['top_left'][1] for r in packing_results]))
        ]
        packing_bottom_right = [
            int(np.mean([r['bottom_right'][0] for r in packing_results])),
            int(np.mean([r['bottom_right'][1] for r in packing_results]))
        ]

        # Định dạng kết quả trả về
        result = {
            "success": True,
            "regions": {
                "trigger": {
                    "top_left": trigger_top_left,
                    "bottom_right": trigger_bottom_right
                },
                "mvd": {
                    "top_left": mvd_top_left,
                    "bottom_right": mvd_bottom_right
                },
                "packing": {
                    "top_left": packing_top_left,
                    "bottom_right": packing_bottom_right
                }
            },
            "message": "Đã xác định vùng QR Trigger, mã vận đơn, đóng gói."
        }

        # Lưu kết quả vào database
        with db_rwlock.gen_wlock():  # Thêm khóa ghi
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            try:
                # Chuyển đổi regions thành JSON string
                trigger_area_json = json.dumps({
                    "top_left": trigger_top_left,
                    "bottom_right": trigger_bottom_right
                })
                mvd_area_json = json.dumps({
                    "top_left": mvd_top_left,
                    "bottom_right": mvd_bottom_right
                })
                packing_area_json = json.dumps({
                    "top_left": packing_top_left,
                    "bottom_right": packing_bottom_right
                })

                # Chèn dữ liệu vào bảng packing_profiles
                cursor.execute('''
                    INSERT INTO packing_profiles (
                        profile_name, qr_trigger_area, qr_mvd_area, packing_area, 
                        min_packing_time, jump_time_ratio, scan_mode, fixed_threshold, margin, additional_params
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    "default_profile",  # profile_name
                    trigger_area_json,
                    mvd_area_json,
                    packing_area_json,
                    0,  # min_packing_time
                    0.0,  # jump_time_ratio
                    'default',  # scan_mode
                    0,  # fixed_threshold
                    0,  # margin
                    '{}'  # additional_params
                ))

                conn.commit()
            except sqlite3.Error as e:
                return jsonify({"success": False, "message": f"Lỗi khi lưu vào database: {str(e)}"}), 500
            finally:
                conn.close()

        return jsonify(result), 200

    except Exception as e:
        return jsonify({"success": False, "message": f"Lỗi: {str(e)}"}), 500
```
## 📄 File: `Frame_Sampler.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/Frame_Sampler.py`

```python
# File: Frame_Sampler.py
import cv2
import pyzbar.pyzbar as pyzbar
import os
from datetime import datetime
import subprocess
from datetime import timezone, timedelta
import sqlite3
from modules.db_utils import get_db_connection
import threading  # Thêm import threading để dùng Event
from modules.scheduler.db_sync import frame_sampler_event, db_rwlock

# Lấy đường dẫn và cấu hình động từ database
with db_rwlock.gen_rlock():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Đường dẫn video gốc
    cursor.execute("SELECT input_path FROM processing_config WHERE id = 1")
    result = cursor.fetchone()
    video_root = result[0] if result else os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../Inputvideo")

    # Thư mục log
    cursor.execute("SELECT output_path FROM processing_config WHERE id = 1")
    result = cursor.fetchone()
    output_path = result[0] if result else os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../output_clips")
    log_dir = os.path.join(output_path, "LOG")
    os.makedirs(log_dir, exist_ok=True)

    # Múi giờ động
    cursor.execute("SELECT timezone FROM general_info WHERE id = 1")
    result = cursor.fetchone()
    tz_hours = int(result[0].split("+")[1]) if result and "+" in result[0] else 7
    VIDEO_TIMEZONE = timezone(timedelta(hours=tz_hours))

    # Cấu hình fps và frame_interval
    cursor.execute("SELECT frame_rate, frame_interval FROM processing_config WHERE id = 1")
    result = cursor.fetchone()
    fps, frame_interval = result if result else (30, 6)

    conn.close()

# Hàm lấy độ dài video bằng ffprobe
def get_video_duration(video_file):
    try:
        cmd = ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", video_file]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        return float(result.stdout.strip())
    except Exception:
        return None

# Đọc danh sách file video từ bảng file_list
def load_video_files():
    with db_rwlock.gen_rlock():  # Thêm khóa đọc
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT file_path FROM file_list WHERE is_processed = 0 ORDER BY priority DESC, created_at ASC")
        video_files = [row[0] for row in cursor.fetchall()]
        conn.close()
    if not video_files:
        print("Không có file video nào trong file_list với is_processed = 0.")
    return video_files

# Hàm xử lý từng video và trả về file log
def process_video(video_file):
    if not os.path.exists(video_file):
        print(f"Lỗi: File '{video_file}' không tồn tại.")
        with db_rwlock.gen_wlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("lỗi", video_file))
            conn.commit()
            conn.close()
        return None

    # Cập nhật trạng thái "đang frame sampler ..."
    with db_rwlock.gen_wlock():
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("đang frame sampler ...", video_file))
        conn.commit()

        # Lấy camera_name từ file_list
        cursor.execute("SELECT camera_name FROM file_list WHERE file_path = ?", (video_file,))
        result = cursor.fetchone()
        camera_name = result[0] if result else "Unknown"
        conn.close()

    video = cv2.VideoCapture(video_file)
    if not video.isOpened():
        print(f"Lỗi: Không thể mở video '{video_file}'. Kiểm tra định dạng hoặc quyền truy cập.")
        with db_rwlock.gen_wlock():
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE file_list SET status = ? WHERE file_path = ?", ("lỗi", video_file))
            conn.commit()
            conn.close()
        return None

    # Lấy thời gian từ metadata
    try:
        result = subprocess.check_output(['ffprobe', '-v', 'quiet', '-show_entries', 'format_tags=creation_time', '-of', 'default=noprint_wrappers=1:nokey=1', video_file])
        start_time_str = result.decode().strip()
        start_time = datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=timezone.utc).astimezone(VIDEO_TIMEZONE)
    except (subprocess.CalledProcessError, ValueError):
        try:
            result = subprocess.check_output(['exiftool', '-CreateDate', '-d', '%Y-%m-%d %H:%M:%S', video_file])
            start_time_str = result.decode().split('CreateDate')[1].strip().split('\n')[0].strip()
            start_time = datetime.strptime(start_time_str, '%Y-%m-%d %H:%M:%S').replace(tzinfo=VIDEO_TIMEZONE)
        except (subprocess.CalledProcessError, IndexError):
            try:
                result = subprocess.check_output(['exiftool', '-FileCreateDate', '-d', '%Y-%m-%d %H:%M:%S', video_file])
                start_time_str = result.decode().split('FileCreateDate')[1].strip().split('\n')[0].strip()
                start_time = datetime.strptime(start_time_str, '%Y-%m-%d %H:%M:%S').replace(tzinfo=VIDEO_TIMEZONE)
            except (subprocess.CalledProcessError, IndexError):
                print("Không tìm thấy metadata creation_time, CreateDate hoặc FileCreateDate, dùng thời gian tạo file hệ thống.")
                start_time = datetime.fromtimestamp(os.path.getctime(video_file), tz=VIDEO_TIMEZONE)

    frame_count = 0
    frame_states = []
    mvd_list = []
    last_state = None
    last_mvd = ""

    # Lấy độ dài video
    total_seconds = get_video_duration(video_file)
    if total_seconds is None:
        print(f"Lỗi: Không thể lấy độ dài video {video_file}")
        return None
    print(f"Độ dài video {video_file}: {total_seconds} giây")

    # Khởi tạo file log
    video_name = os.path.basename(video_file).replace(".mp4", "")
    current_start_second = 0
    current_end_second = 300  # 5 phút = 300 giây
    log_file = os.path.join(log_dir, f"log_{video_name}_{current_start_second:04d}_{current_end_second:04d}.txt")
    with open(log_file, 'w') as f:
        f.write(f"# Start: {current_start_second}, End: {current_end_second}, Start_Time: {start_time.strftime('%Y-%m-%d %H:%M:%S')}, Camera_Name: {camera_name}, Video_File: {video_file}\n")
        f.flush()

    # Ghi file log vào processed_logs
    with db_rwlock.gen_wlock():
        conn = get_db_connection()
        cursor = conn.cursor()
        # Kiểm tra xem log_file đã tồn tại chưa
        cursor.execute("SELECT 1 FROM processed_logs WHERE log_file = ?", (log_file,))
        log_exists = cursor.fetchone()
        if log_exists:
            print(f"Log file {log_file} đã tồn tại trong processed_logs, bỏ qua chèn mới.")
        else:
            cursor.execute("INSERT INTO processed_logs (log_file, is_processed) VALUES (?, 0)", (log_file,))
        conn.commit()
        conn.close()

    while video.isOpened():
        ret, frame = video.read()
        if not ret:
            break

        frame_count += 1
        if frame_count % frame_interval != 0:
            continue

        # Nhận diện QR
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        qr_codes = pyzbar.decode(gray)
        state = "Off"
        mvd = ""
        for qr in qr_codes:
            if qr.data.decode() == "TimeGo":
                state = "On"
            elif qr.type == "QRCODE":
                mvd = qr.data.decode()

        second_in_video = (frame_count - 1) / fps
        second = round(second_in_video)

        frame_states.append(state)
        mvd_list.append(mvd)

        if len(frame_states) == 5:
            final_state = "On"
            if all(s == "Off" for s in frame_states):
                final_state = "Off"
            mvd_result = mvd_list[-1] if mvd_list[-1] else ""

            # Chỉ ghi log khi trạng thái hoặc mã QR thay đổi
            if final_state != last_state or mvd_result != last_mvd:
                log_line = f"{second},{final_state},{mvd_result}\n"
                with open(log_file, 'a') as f:
                    f.write(log_line)
                    f.flush()
                print(f"Log giây {second}: {log_line.strip()}")
                last_state = final_state
                last_mvd = mvd_result

            if second_in_video >= current_end_second:
                current_start_second = current_end_second
                current_end_second += 300
                log_file = os.path.join(log_dir, f"log_{video_name}_{current_start_second:04d}_{current_end_second:04d}.txt")
                with open(log_file, 'w') as f:
                    f.write(f"# Start: {current_start_second}, End: {current_end_second}, Start_Time: {start_time.strftime('%Y-%m-%d %H:%M:%S')}, Camera_Name: {camera_name}, Video_File: {video_file}\n")
                    f.flush()

                # Ghi file log mới vào processed_logs
                with db_rwlock.gen_wlock():
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    # Kiểm tra xem log_file đã tồn tại chưa
                    cursor.execute("SELECT 1 FROM processed_logs WHERE log_file = ?", (log_file,))
                    log_exists = cursor.fetchone()
                    if log_exists:
                        print(f"Log file {log_file} đã tồn tại trong processed_logs, bỏ qua chèn mới.")
                    else:
                        cursor.execute("INSERT INTO processed_logs (log_file, processed_at, is_processed) VALUES (?, CURRENT_TIMESTAMP, 0)", (log_file,))
                    conn.commit()
                    conn.close()

            frame_states = []
            mvd_list = []

    video.release()

    # Cập nhật trạng thái và is_processed trong file_list
    with db_rwlock.gen_wlock():
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE file_list SET is_processed = 1, status = ? WHERE file_path = ?", ("xong", video_file))
        conn.commit()
        conn.close()

    return log_file

# Lấy danh sách video
video_files = load_video_files()
if not video_files:
    print(f"Không tìm thấy file video nào để xử lý.")

# Xử lý từng file video khi chạy độc lập
if __name__ == "__main__":
    frame_sampler_event = threading.Event()
    frame_sampler_event.set()  # Đặt event thành True để chạy
    for video_file in video_files:
        process_video(video_file)
    print(f"Hoàn tất lấy mẫu và lưu log vào {log_dir}.")
```
## 📄 File: `qr_mvd.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/qr_mvd.py`

```python
import cv2
import numpy as np
from pyzbar.pyzbar import decode
import os
import sqlite3
from datetime import datetime
import pathlib

def calculate_path_length(positions):
    """Tính quãng đường di chuyển của QR dựa trên tọa độ trung tâm."""
    if len(positions) < 2:
        return 0
    total_distance = 0
    for i in range(1, len(positions)):
        x1, y1 = positions[i-1]
        x2, y2 = positions[i]
        distance = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        total_distance += distance
    return total_distance

def get_log_dir():
    """Lấy đường dẫn thư mục LOG từ processing_config hoặc mặc định."""
    # Tìm thư mục gốc V_Track
    base_dir = pathlib.Path(__file__).parent
    while base_dir.name != 'V_Track' and base_dir.parent != base_dir:
        base_dir = base_dir.parent
    
    # Đường dẫn đến events.db
    db_path = base_dir / "backend" / "database" / "events.db"

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT output_path FROM processing_config WHERE id = 1")
        result = cursor.fetchone()
        output_path = result[0] if result else None
        conn.close()
    except sqlite3.Error:
        output_path = None
    
    if not output_path:
        # Đường dẫn mặc định: resources/output_clips từ thư mục gốc V_Track
        output_path = base_dir / "resources" / "output_clips"

    log_dir = os.path.join(output_path, "LOG", "QR")
    os.makedirs(log_dir, exist_ok=True)
    return log_dir

def process_video_for_qr_mvd(video_path, block_duration=10, frames_per_block=20, num_blocks=20):
    """Xác định QR MVD chính cho từng block (mỗi block 10s) trong video."""
    # Mở video
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: Cannot open video {video_path}")
        return None, None, None

    # Lấy thông tin video
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    block_frames = int(block_duration * fps)
    total_blocks = min(num_blocks, total_frames // block_frames)  # Đảm bảo không vượt quá độ dài video

    # Lưu trữ tọa độ QR MVD chính của từng block cho heatmap
    heatmap_positions = []
    detailed_log = []  # Log chi tiết cho tất cả block

    # Xử lý từng block
    for block_idx in range(total_blocks):
        block_start_frame = block_idx * block_frames
        block_end_frame = min(block_start_frame + block_frames, total_frames)

        # Tính bước nhảy để lấy 20 frame cách đều trong block
        frame_step = max(1, (block_end_frame - block_start_frame) // frames_per_block)
        frame_indices = list(range(block_start_frame, block_end_frame, frame_step))[:frames_per_block]

        # Lưu trữ thông tin QR trong block
        qr_positions = {}  # {qr_code: [(x, y), ...]}
        qr_counts = {}     # {qr_code: số lần xuất hiện}
        frame_log = []     # Lưu thông tin QR mỗi frame

        # Đọc và xử lý từng frame trong block
        for idx in frame_indices:
            cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ret, frame = cap.read()
            if not ret:
                frame_log.append(f"Frame {idx}: Failed to read")
                continue

            # Chuyển sang grayscale để tăng tốc pyzbar
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            qrs = decode(gray)

            frame_info = f"Frame {idx}: "
            if not qrs:
                frame_info += "No QR detected"
            else:
                for qr in qrs:
                    qr_code = qr.data.decode('utf-8')
                    # Tính tọa độ trung tâm
                    x, y, w, h = qr.rect
                    center_x, center_y = x + w // 2, y + h // 2

                    # Lưu thông tin
                    if qr_code not in qr_positions:
                        qr_positions[qr_code] = []
                        qr_counts[qr_code] = 0
                    qr_positions[qr_code].append((center_x, center_y))
                    qr_counts[qr_code] += 1

                    frame_info += f"QR: {qr_code}, Center: ({center_x}, {center_y}) | "
            frame_log.append(frame_info.rstrip(" | "))

        # Phân tích QR để chọn QR MVD chính trong block
        if not qr_positions:
            detailed_log.append(f"\nBlock {block_idx + 1} (Frames {block_start_frame}-{block_end_frame-1}):\nNo QR codes detected in this block.")
            continue

        qr_metrics = []
        for qr_code, positions in qr_positions.items():
            path_length = calculate_path_length(positions)
            count = qr_counts[qr_code]
            qr_metrics.append({
                'code': qr_code,
                'path_length': path_length,
                'count': count,
                'positions': positions
            })

        # Sắp xếp theo quãng đường di chuyển, rồi số lần xuất hiện
        qr_metrics.sort(key=lambda x: (x['path_length'], x['count']), reverse=True)
        selected_qr = qr_metrics[0]

        # Tính vị trí đại diện (trung bình tọa độ)
        avg_x = int(np.mean([pos[0] for pos in selected_qr['positions']]))
        avg_y = int(np.mean([pos[1] for pos in selected_qr['positions']]))

        # Lưu tọa độ cho heatmap
        heatmap_positions.append((avg_x, avg_y))

        # Ghi log chi tiết cho block này
        detailed_log.append(f"\nBlock {block_idx + 1} (Frames {block_start_frame}-{block_end_frame-1}):")
        detailed_log.append(f"Selected QR MVD: {selected_qr['code']}")
        detailed_log.append(f"Representative Position: ({avg_x}, {avg_y})")
        detailed_log.append(f"Path Length: {selected_qr['path_length']}")
        detailed_log.append(f"Count: {selected_qr['count']}")
        detailed_log.append("Frame-by-Frame QR Detection:")
        for log in frame_log:
            detailed_log.append(log)
        detailed_log.append("All QR Codes Detected in Block:")
        for qr in qr_metrics:
            detailed_log.append(f"QR: {qr['code']}, Path: {qr['path_length']}, Count: {qr['count']}")

    cap.release()

    if not heatmap_positions:
        print("No QR codes detected in any block.")
        return None, None, None

    # Ghi log chi tiết
    log_dir = get_log_dir()
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_filename = os.path.join(log_dir, f"qr_mvd_log_{timestamp}.txt")
    with open(log_filename, 'w') as f:
        f.write(f"Video: {video_path}\n")
        f.write(f"Total Blocks Processed: {total_blocks}\n")
        for log_entry in detailed_log:
            f.write(f"{log_entry}\n")

    # Ghi file tọa độ cho heatmap
    heatmap_filename = os.path.join(log_dir, f"heatmap_input_{timestamp}.txt")
    with open(heatmap_filename, 'w') as f:
        for x, y in heatmap_positions:
            f.write(f"{x},{y}\n")

    return heatmap_positions, log_filename, heatmap_filename

def main():
    video_path = input("Enter video path: ")
    heatmap_positions, log_file, heatmap_file = process_video_for_qr_mvd(video_path)
    if heatmap_positions:
        print(f"Heatmap Positions: {heatmap_positions}")
        print(f"Detailed Log saved to: {log_file}")
        print(f"Heatmap Input saved to: {heatmap_file}")
    else:
        print("No QR MVD positions extracted.")

if __name__ == "__main__":
    main()
```
## 📄 File: `cutter_complete.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/cutter/cutter_complete.py`

```python
import subprocess

def cut_complete_event(event, video_buffer, video_length, output_file):
    """Cắt video cho sự kiện hoàn chỉnh (có cả ts và te)."""
    ts = event.get("ts")
    te = event.get("te")
    video_file = event.get("video_file")

    start_time = max(0, ts - video_buffer)  # Thêm buffer trước ts
    end_time = min(te + video_buffer, video_length)  # Thêm buffer sau te
    duration = end_time - start_time

    if duration <= 0:
        print(f"Bỏ qua: Duration không hợp lệ ({duration}s) cho sự kiện {event.get('event_id')}")
        return False

    try:
        cmd = [
            "ffmpeg",
            "-i", video_file,
            "-ss", str(start_time),
            "-t", str(duration),
            "-c:v", "copy",
            "-c:a", "copy",
            "-y",
            output_file
        ]
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print(f"Đã cắt video: {output_file}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Lỗi khi cắt video {video_file}: {e}")
        return False
    except Exception as e:
        print(f"Lỗi không xác định: {e}")
        return False
```
## 📄 File: `cutter.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/cutter/cutter.py`

```python
import sqlite3
import os
from datetime import datetime
import subprocess
from flask import Blueprint, request, jsonify
from modules.db_utils import get_db_connection
import ast
from .cutter_complete import cut_complete_event
from .cutter_incomplete import cut_incomplete_event, merge_incomplete_events
from .cutter_utils import generate_output_filename, generate_merged_filename, update_event_in_db
from modules.scheduler.db_sync import db_rwlock  # Thêm import db_rwlock
from ..analyze_regions import analyze_regions_bp

# Định nghĩa Blueprint
cutter_bp = Blueprint('cutter', __name__)
cutter_bp.register_blueprint(analyze_regions_bp)  # Đăng ký Blueprint

# Đường dẫn CSDL và thư mục đầu ra
with db_rwlock.gen_rlock():  # Thêm khóa đọc
    conn = get_db_connection()
    cursor = conn.cursor()

    # Đường dẫn output_dir tương đối
    cursor.execute("SELECT output_path FROM processing_config LIMIT 1")
    result = cursor.fetchone()
    output_dir = result[0] if result else os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../resources/output_clips")

    # Đảm bảo thư mục output_clips tồn tại
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    conn.close()

# Hàm lấy độ dài video bằng ffprobe
def get_video_duration(video_file):
    try:
        cmd = ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", video_file]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        return float(result.stdout.strip())
    except Exception:
        return None

# Hàm cắt video và cập nhật CSDL
def cut_and_update_events(selected_events, tracking_codes_filter, brand_name="Alan"):
    """Cắt video từ danh sách sự kiện đã chọn và cập nhật trạng thái trong CSDL."""
    with db_rwlock.gen_wlock():  # Thêm khóa ghi
        conn = get_db_connection()
        cursor = conn.cursor()

        # Lấy video_buffer và max_packing_time từ processing_config
        cursor.execute("SELECT video_buffer, max_packing_time FROM processing_config LIMIT 1")
        result = cursor.fetchone()
        video_buffer = result[0] if result else 5  # Giây
        max_packing_time = result[1] if result else 120  # Giây

        # Danh sách lưu các file đã cắt
        cut_files = []

        for event in selected_events:
            # Truy cập qua key
            event_id = event.get("event_id")
            ts = event.get("ts")
            te = event.get("te")
            video_file = event.get("video_file")

            # Kiểm tra nếu sự kiện đã được xử lý
            cursor.execute("SELECT is_processed FROM events WHERE event_id = ?", (event_id,))
            is_processed = cursor.fetchone()[0]
            if is_processed:
                print(f"Bỏ qua: Sự kiện {event_id} đã được xử lý trước đó")
                continue

            # Kiểm tra sự kiện dở dang
            has_ts = ts is not None
            has_te = te is not None
            is_incomplete = (has_ts and not has_te) or (not has_ts and has_te)

            # Xử lý sự kiện dở dang
            if is_incomplete:
                # Tìm sự kiện liền kề trong CSDL
                next_event = None
                if has_ts and not has_te:  # Thiếu te, tìm event_id + 1
                    cursor.execute("SELECT event_id, ts, te, video_file, packing_time_start, packing_time_end, tracking_codes, is_processed FROM events WHERE event_id = ? AND is_processed = 0", (event_id + 1,))
                    next_event_row = cursor.fetchone()
                    if next_event_row:
                        next_event = {
                            "event_id": next_event_row[0],
                            "ts": next_event_row[1],
                            "te": next_event_row[2],
                            "video_file": next_event_row[3],
                            "packing_time_start": next_event_row[4],
                            "packing_time_end": next_event_row[5],
                            "tracking_codes": next_event_row[6],
                            "is_processed": next_event_row[7]
                        }
                elif not has_ts and has_te:  # Thiếu ts, tìm event_id - 1
                    cursor.execute("SELECT event_id, ts, te, video_file, packing_time_start, packing_time_end, tracking_codes, is_processed FROM events WHERE event_id = ? AND is_processed = 0", (event_id - 1,))
                    prev_event_row = cursor.fetchone()
                    if prev_event_row:
                        next_event = {
                            "event_id": prev_event_row[0],
                            "ts": prev_event_row[1],
                            "te": prev_event_row[2],
                            "video_file": prev_event_row[3],
                            "packing_time_start": prev_event_row[4],
                            "packing_time_end": prev_event_row[5],
                            "tracking_codes": prev_event_row[6],
                            "is_processed": prev_event_row[7]
                        }

                # Kiểm tra nếu tìm thấy sự kiện liền kề và có thể ghép
                if next_event:
                    next_event_id = next_event.get("event_id")
                    next_ts = next_event.get("ts")
                    next_te = next_event.get("te")
                    next_video_file = next_event.get("video_file")
                    next_has_ts = next_ts is not None
                    next_has_te = next_te is not None

                    # Kiểm tra điều kiện ghép
                    can_merge = (has_ts and not has_te and not next_has_ts and next_has_te) or (not has_ts and has_te and next_has_ts and not next_has_te)

                    if can_merge:
                        # Lấy độ dài video
                        video_length_a = get_video_duration(video_file)
                        video_length_b = get_video_duration(next_video_file)
                        if video_length_a is None or video_length_b is None:
                            print(f"Lỗi: Không thể lấy độ dài video {video_file} hoặc {next_video_file}")
                            continue

                        # Cắt video cho event hiện tại (event)
                        output_file_a = generate_output_filename(event, tracking_codes_filter, output_dir, brand_name)
                        print(f"Đang xử lý sự kiện {event_id}: output_file={output_file_a}, packing_time_start={event.get('packing_time_start')}, packing_time_end={event.get('packing_time_end')}")
                        if cut_incomplete_event(event, video_buffer, video_length_a, output_file_a):
                            update_event_in_db(cursor, event_id, output_file_a)
                            # Không thêm output_file_a vào cut_files

                        # Cắt video cho event liền kề (next_event)
                        output_file_b = generate_output_filename(next_event, tracking_codes_filter, output_dir, brand_name)
                        print(f"Đang xử lý sự kiện {next_event_id}: output_file={output_file_b}, packing_time_start={next_event.get('packing_time_start')}, packing_time_end={next_event.get('packing_time_end')}")
                        if cut_incomplete_event(next_event, video_buffer, video_length_b, output_file_b):
                            update_event_in_db(cursor, next_event_id, output_file_b)
                            # Không thêm output_file_b vào cut_files

                        # Quy định event_a là sự kiện có ts, không te; event_b là sự kiện có te, không ts
                        if has_ts and not has_te:  # event hiện tại là event_a
                            event_a = event
                            event_b = next_event
                            video_length_event_a = video_length_a
                            video_length_event_b = video_length_b
                        else:  # event hiện tại là event_b
                            event_a = next_event
                            event_b = event
                            video_length_event_a = video_length_b
                            video_length_event_b = video_length_a

                        # Log thông tin event_a và event_b trước khi gọi merge_incomplete_events
                        print(f"Gọi merge_incomplete_events: event_a (ID: {event_a.get('event_id')}, ts: {event_a.get('ts')}, te: {event_a.get('te')}), event_b (ID: {event_b.get('event_id')}, ts: {event_b.get('ts')}, te: {event_b.get('te')})")

                        # Ghép 2 file dở dang thành file mới
                        merged_file = merge_incomplete_events(event_a, event_b, video_buffer, video_length_event_a, video_length_event_b, output_dir, max_packing_time, brand_name)
                        if merged_file:
                            # Cập nhật CSDL cho cả 2 sự kiện với file ghép
                            update_event_in_db(cursor, event_id, merged_file)
                            update_event_in_db(cursor, next_event_id, merged_file)
                            cut_files.append(merged_file)

                        continue

            # Xử lý độc lập nếu không ghép
            video_length = get_video_duration(video_file)
            if video_length is None:
                print(f"Lỗi: Không thể lấy độ dài video {video_file}")
                continue

            # Tạo tên file đầu ra
            output_file = generate_output_filename(event, tracking_codes_filter, output_dir, brand_name)
            print(f"Đang xử lý sự kiện {event_id}: output_file={output_file}, packing_time_start={event.get('packing_time_start')}, packing_time_end={event.get('packing_time_end')}")

            # Xử lý ts/te
            if has_ts and has_te:  # Hoàn chỉnh
                if cut_complete_event(event, video_buffer, video_length, output_file):
                    update_event_in_db(cursor, event_id, output_file)
                    cut_files.append(output_file)
            elif is_incomplete:  # Dở dang
                if cut_incomplete_event(event, video_buffer, video_length, output_file):
                    update_event_in_db(cursor, event_id, output_file)
                    cut_files.append(output_file)
            else:
                print(f"Bỏ qua: Sự kiện {event_id} không có ts hoặc te")
                continue

        # Lưu thay đổi và đóng kết nối
        conn.commit()
        conn.close()
    return cut_files  # Trả về danh sách file đã cắt

# API endpoint /cut-videos
@cutter_bp.route('/cut-videos', methods=['POST'])
def cut_videos():
    data = request.get_json()
    selected_events = data.get('selected_events', [])
    tracking_codes_filter = data.get('tracking_codes_filter', [])

    if not selected_events:
        return jsonify({"error": "No selected events provided"}), 400

    try:
        cut_files = cut_and_update_events(selected_events, tracking_codes_filter)
        return jsonify({"message": "Videos cut successfully", "cut_files": cut_files}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
```
## 📄 File: `cutter_incomplete.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/cutter/cutter_incomplete.py`

```python
import os
import subprocess
from .cutter_utils import generate_merged_filename, generate_output_filename

def cut_incomplete_event(event, video_buffer, video_length, output_file):
    """Cắt video cho sự kiện dở dang (thiếu ts hoặc te)."""
    ts = event.get("ts")
    te = event.get("te")
    video_file = event.get("video_file")

    # Log độ dài video gốc
    print(f"Video gốc {video_file} có độ dài: {video_length} giây")

    # Log giá trị video_buffer
    print(f"Sử dụng video_buffer: {video_buffer} giây")

    if ts is not None and te is None:  # Chỉ có ts
        start_time = max(0, ts - video_buffer)
        duration = video_length - start_time
    elif ts is None and te is not None:  # Chỉ có te
        start_time = 0
        duration = min(te + video_buffer, video_length)
    else:
        print(f"Bỏ qua: Sự kiện {event.get('event_id')} không có ts hoặc te")
        return False

    if duration <= 0:
        print(f"Bỏ qua: Duration không hợp lệ ({duration}s) cho sự kiện {event.get('event_id')}")
        return False

    try:
        cmd = [
            "ffmpeg",
            "-i", video_file,
            "-ss", str(start_time),
            "-t", str(duration),
            "-c:v", "copy",
            "-c:a", "copy",
            "-y",
            output_file
        ]
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print(f"Đã cắt video: {output_file}")

        # Log độ dài của file dở dang vừa tạo
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", output_file],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        duration = float(probe.stdout.strip())
        print(f"File dở dang {output_file} có độ dài: {duration} giây")

        event["cut_video_file"] = output_file
        return True
    except subprocess.CalledProcessError as e:
        print(f"Lỗi khi cắt video {video_file}: {e}")
        return False
    except Exception as e:
        print(f"Lỗi không xác định: {e}")
        return False

def merge_incomplete_events(event_a, event_b, video_buffer, video_length_a, video_length_b, output_dir, max_packing_time, brand_name="Alan"):
    """Ghép nối hai sự kiện dở dang (A có ts, B có te) và tạo file ghép với tên tối ưu."""
    video_file_a = event_a.get("video_file")
    video_file_b = event_b.get("video_file")

    # Kiểm tra nếu file đã được cắt sẵn
    temp_file_a = event_a.get("cut_video_file")
    temp_file_b = event_b.get("cut_video_file")
    files_to_cleanup = []

    # Tạo thư mục temp_clips để lưu file tạm
    temp_clips_dir = os.path.join(os.path.dirname(output_dir), "temp_clips")
    if not os.path.exists(temp_clips_dir):
        os.makedirs(temp_clips_dir)

    # Nếu không có file cắt sẵn, cắt ngay lập tức và lưu vào temp_clips_dir
    if not temp_file_a or not os.path.exists(temp_file_a):
        temp_file_a = os.path.join(temp_clips_dir, f"temp_a_{event_a.get('event_id')}_incomplete.mp4")
        if not cut_incomplete_event(event_a, video_buffer, video_length_a, temp_file_a):
            print(f"Lỗi: Không thể cắt file tạm cho sự kiện {event_a.get('event_id')}")
            return None
    if not temp_file_b or not os.path.exists(temp_file_b):
        temp_file_b = os.path.join(temp_clips_dir, f"temp_b_{event_b.get('event_id')}_incomplete.mp4")
        if not cut_incomplete_event(event_b, video_buffer, video_length_b, temp_file_b):
            print(f"Lỗi: Không thể cắt file tạm cho sự kiện {event_b.get('event_id')}")
            return None

    # Tạo tên file đầu ra tối ưu dựa trên temp_file_a và temp_file_b
    file_name_a = os.path.basename(temp_file_a)
    file_name_b = os.path.basename(temp_file_b)
    parts_a = file_name_a.split("_")
    parts_b = file_name_b.split("_")

    # Lấy Brand từ file đầu tiên
    brand_name = parts_a[0]

    # Lấy mã vận đơn từ cả hai file, loại bỏ "NoCode"
    tracking_codes = []
    if len(parts_a) >= 2 and parts_a[1] != "NoCode":
        tracking_codes.append(parts_a[1])
    if len(parts_b) >= 2 and parts_b[1] != "NoCode":
        tracking_codes.append(parts_b[1])

    # Lấy thời gian từ file đầu tiên
    date = parts_a[2] if len(parts_a) >= 3 else "unknown"
    hour = parts_a[3].split(".")[0] if len(parts_a) >= 4 else "0000"
    time_str = f"{date}_{hour}"

    # Tạo tên mã vận đơn: dùng một mã hoặc ghép nhiều mã bằng "-"
    tracking_str = "-".join(tracking_codes) if tracking_codes else "unknown"

    # Tạo tên file đầu ra
    output_file = os.path.join(output_dir, f"{brand_name}_{tracking_str}_{time_str}.mp4")

    # Ghép nối video A và B
    concat_list_file = os.path.join(output_dir, f"concat_list_{event_a.get('event_id')}.txt")
    try:
        with open(concat_list_file, 'w') as f:
            f.write(f"file '{temp_file_a}'\nfile '{temp_file_b}'\n")

        cmd_concat = [
            "ffmpeg",
            "-f", "concat",
            "-safe", "0",
            "-i", concat_list_file,
            "-c", "copy",
            "-y",
            output_file
        ]
        subprocess.run(cmd_concat, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        print(f"Đã ghép và cắt video: {output_file}")

        # Log độ dài của file ghép
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", output_file],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        duration = float(probe.stdout.strip())
        print(f"File ghép {output_file} có độ dài: {duration} giây")

        # Xóa các file tạm và file concat_list sau khi ghép thành công
        if os.path.exists(temp_file_a):
            os.remove(temp_file_a)
        if os.path.exists(temp_file_b):
            os.remove(temp_file_b)
        if os.path.exists(concat_list_file):
            os.remove(concat_list_file)

        return output_file

    except subprocess.CalledProcessError as e:
        print(f"Lỗi khi ghép video: {e}")
        # Xóa các file tạm và file concat_list trong trường hợp lỗi
        if os.path.exists(temp_file_a):
            os.remove(temp_file_a)
        if os.path.exists(temp_file_b):
            os.remove(temp_file_b)
        if os.path.exists(concat_list_file):
            os.remove(concat_list_file)
        return None
    except Exception as e:
        print(f"Lỗi không xác định khi ghép video: {e}")
        # Xóa các file tạm và file concat_list trong trường hợp lỗi
        if os.path.exists(temp_file_a):
            os.remove(temp_file_a)
        if os.path.exists(temp_file_b):
            os.remove(temp_file_b)
        if os.path.exists(concat_list_file):
            os.remove(concat_list_file)
        return None
```
## 📄 File: `cutter_utils.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/technician/cutter/cutter_utils.py`

```python
import os
from datetime import datetime
import ast

def is_reasonable_timestamp(ts):
    """Kiểm tra xem timestamp có hợp lệ không (lớn hơn năm 2020)."""
    return ts and int(ts) > 1577836800000  # Trên năm 2020

def generate_output_filename(event, tracking_codes_filter, output_dir, brand_name="Alan"):
    """Tạo tên file đầu ra dựa trên tracking code và thời gian ưu tiên: packing_time_start > packing_time_end."""
    tracking_codes_str = event.get("tracking_codes")
    packing_time_start = event.get("packing_time_start")
    packing_time_end = event.get("packing_time_end")

    try:
        tracking_codes = ast.literal_eval(tracking_codes_str) if tracking_codes_str else []
    except (ValueError, SyntaxError) as e:
        print(f"Lỗi parse tracking_codes_str cho event {event.get('event_id')}: {e}")
        tracking_codes = []

    # Chọn tracking code ưu tiên
    if tracking_codes_filter:
        selected_tracking_code = next((code for code in tracking_codes_filter if code in tracking_codes), "NoCode")
    else:
        selected_tracking_code = tracking_codes[-1] if tracking_codes else "NoCode"

    # Ưu tiên chọn thời gian: packing_time_start > packing_time_end > fallback
    timestamp = next(
        (t for t in [packing_time_start, packing_time_end] if is_reasonable_timestamp(t)),
        0  # Fallback
    )
    try:
        time_str = datetime.fromtimestamp(int(timestamp) / 1000).strftime("%Y%m%d_%H%M")
    except Exception:
        time_str = "19700101_0000"

    return os.path.join(output_dir, f"{brand_name}_{selected_tracking_code}_{time_str}.mp4")

def generate_merged_filename(event_a, event_b, output_dir, brand_name="Alan"):
    """Tạo tên file ghép cho hai sự kiện dở dang, ưu tiên thời gian: packing_time_start > packing_time_end."""
    tracking_codes_a_str = event_a.get("tracking_codes")
    tracking_codes_b_str = event_b.get("tracking_codes")
    packing_time_start_a = event_a.get("packing_time_start")
    packing_time_end_b = event_b.get("packing_time_end")

    # Chọn tracking code (ưu tiên sự kiện có mã vận đơn)
    try:
        tracking_codes_a = ast.literal_eval(tracking_codes_a_str) if tracking_codes_a_str else []
    except (ValueError, SyntaxError):
        tracking_codes_a = []
    try:
        tracking_codes_b = ast.literal_eval(tracking_codes_b_str) if tracking_codes_b_str else []
    except (ValueError, SyntaxError):
        tracking_codes_b = []

    selected_tracking_code = tracking_codes_b[-1] if tracking_codes_b else (tracking_codes_a[-1] if tracking_codes_a else "NoCode")

    # Ưu tiên chọn thời gian: packing_time_start > packing_time_end > fallback
    timestamp = next(
        (t for t in [packing_time_start_a, packing_time_end_b] if is_reasonable_timestamp(t)),
        0  # Fallback
    )
    try:
        time_str = datetime.fromtimestamp(int(timestamp) / 1000).strftime("%Y%m%d_%H%M")
    except Exception:
        time_str = "19700101_0000"

    return os.path.join(output_dir, f"{brand_name}_{selected_tracking_code}_{time_str}.mp4")

def update_event_in_db(cursor, event_id, output_file):
    """Cập nhật CSDL cho một sự kiện."""
    cursor.execute("""
        UPDATE events 
        SET is_processed = 1, output_file = ? 
        WHERE event_id = ?
    """, (output_file, event_id))
```
## 📄 File: `IdleMonitor.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/supervisor/IdleMonitor.py`

```python
# IdleMonitor.py - Module giám sát hoạt động (tick-based, buffer RAM, gọi EventAnalyzer)

```
## 📄 File: `EventAnalyzer.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/supervisor/EventAnalyzer.py`

```python
# EventAnalyzer.py - Module phân tích chi tiết sự kiện (tách từ event_detector.py sau này)

```
## 📄 File: `IdleStopDetector.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/backend/modules/supervisor/IdleStopDetector.py`

```python
# IdleStopDetector.py - Module xác định thời điểm Stop và chuyển về Idle

```
## 📄 File: `a5.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/docs/Tien ich/a5.py`

```python
import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar

image_path = "/Users/annhu/Desktop/a55.jpg"
frame = cv2.imread(image_path)
if frame is None:
    raise FileNotFoundError(f"❌ Không đọc được ảnh: {image_path}")

# Bước 1: Tìm QR code "timego"
gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
# Resize + CLAHE tăng độ tương phản
resized = cv2.resize(gray, None, fx=2.0, fy=2.0)
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
enhanced = clahe.apply(resized)
qr_codes = pyzbar.decode(enhanced)
pixel_per_cm = None
qr_bbox = None

print(f"🔍 Đã phát hiện {len(qr_codes)} mã QR")

for qr in qr_codes:
    data = qr.data.decode('utf-8').lower()
    if data == 'timego':
        x, y, w, h = [v // 2 for v in qr.rect]  # Do đã resize x2
        pixel_per_cm = w / 19.0  # QR thực tế 19cm
        qr_bbox = (x, y, w, h)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
        print(f"✅ QR 'timego' phát hiện tại: x={x}, y={y}, w={w}, h={h}, pixel/cm={pixel_per_cm:.2f}")
        break

if pixel_per_cm is None:
    raise ValueError("❌ Không tìm thấy QR 'timego' trong ảnh")

# Bước 2: Dò vùng A5
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
enhanced = clahe.apply(gray)
edges = cv2.Canny(enhanced, 50, 150)
contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

a5_min_area = (14.8 * pixel_per_cm) * (21 * pixel_per_cm)
a5_max_area = a5_min_area * 2.0
print(f"ℹ️ Diện tích A5 min: {a5_min_area:.0f}, max: {a5_max_area:.0f} (px²)")

best_contour = None
best_score = -1

for i, contour in enumerate(contours):
    approx = cv2.approxPolyDP(contour, 0.02 * cv2.arcLength(contour, True), True)
    if len(approx) != 4:
        continue

    area = cv2.contourArea(contour)
    if not (a5_min_area <= area <= a5_max_area):
        print(f"❌ [Contour {i}] Bỏ qua - Diện tích {area:.0f} ngoài vùng")
        continue

    x, y, w, h = cv2.boundingRect(contour)
    aspect_ratio = max(w/h, h/w)
    if not (1.2 <= aspect_ratio <= 1.7):
        print(f"❌ [Contour {i}] Bỏ qua - Aspect ratio {aspect_ratio:.2f} không hợp lệ")
        continue

    roi = frame[y:y+h, x:x+w]
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    yellow_mask = cv2.inRange(hsv, (20, 60, 60), (40, 255, 255))
    black_mask = cv2.inRange(hsv, (0, 0, 0), (180, 255, 40))
    yellow_black_ratio = (np.sum(yellow_mask) + np.sum(black_mask)) / (w * h * 255)

    print(f"[Contour {i}] Diện tích: {area:.0f}, Tỷ lệ vàng-đen: {yellow_black_ratio:.4f}")
    if yellow_black_ratio < 0.0005:
        print(f"❌ [Contour {i}] Bỏ qua - Tỷ lệ vàng-đen quá thấp")
        continue

    score = -abs(area - a5_min_area)
    if score > best_score:
        best_score = score
        best_contour = contour

if best_contour is not None:
    x, y, w, h = cv2.boundingRect(best_contour)
    a5_crop = frame[y:y+h, x:x+w]
    cv2.imwrite("a5_crop.png", a5_crop)
    cv2.drawContours(frame, [best_contour], -1, (0, 255, 0), 3)
    cv2.imwrite("a5_final_detected.png", frame)
    print("✅ Tìm thấy vùng A5 và QR 'timego'. Đã lưu 'a5_crop.png' và 'a5_final_detected.png'")
else:
    print("❌ Không tìm thấy vùng A5 phù hợp (đã in debug từng contour)")

```
## 📄 File: `Generate Qr Pdf.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/docs/Tien ich/Generate Qr Pdf.py`

```python
import qrcode

def generate_qr(text: str, filename: str):
    img = qrcode.make(text)
    img.save(filename)
    print(f"✅ Đã tạo: {filename}")

generate_qr("Trigger", "trigger_qr.png")
generate_qr("Vùng mã vận đơn", "vung_ma_van_don_qr.png")

```
## 📄 File: `Cat Video.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/docs/Tien ich/Cat Video.py`

```python
import os
import ffmpeg

def split_video(input_path, split_time):
    # Kiểm tra xem file đầu vào có tồn tại không
    if not os.path.exists(input_path):
        print("Lỗi: File video không tồn tại!")
        return

    # Lấy thư mục và tên file gốc
    input_dir = os.path.dirname(input_path)
    input_filename = os.path.splitext(os.path.basename(input_path))[0]
    file_extension = os.path.splitext(input_path)[1]

    # Tạo tên file đầu ra
    output1 = os.path.join(input_dir, f"{input_filename}_part1{file_extension}")
    output2 = os.path.join(input_dir, f"{input_filename}_part2{file_extension}")

    try:
        # Lấy thông tin video
        probe = ffmpeg.probe(input_path)
        duration = float(probe['format']['duration'])

        # Kiểm tra thời gian cắt hợp lệ
        split_time_sec = convert_to_seconds(split_time)
        if split_time_sec <= 0 or split_time_sec >= duration:
            print(f"Lỗi: Thời gian cắt phải nằm trong khoảng 0 đến {duration} giây")
            return

        # Cắt phần đầu video (từ 0 đến split_time)
        stream = ffmpeg.input(input_path)
        stream = ffmpeg.output(stream, output1, t=split_time_sec, c='copy')
        ffmpeg.run(stream, overwrite_output=True)

        # Cắt phần sau video (từ split_time đến hết)
        stream = ffmpeg.input(input_path, ss=split_time_sec)
        stream = ffmpeg.output(stream, output2, c='copy')
        ffmpeg.run(stream, overwrite_output=True)

        print(f"Đã cắt video thành công!")
        print(f"Phần 1: {output1}")
        print(f"Phần 2: {output2}")

    except ffmpeg.Error as e:
        print(f"Lỗi khi cắt video: {e.stderr.decode()}")

def convert_to_seconds(time_str):
    # Chuyển đổi thời gian từ định dạng HH:MM:SS hoặc số giây sang giây
    try:
        if ':' in time_str:
            h, m, s = map(int, time_str.split(':'))
            return h * 3600 + m * 60 + s
        return float(time_str)
    except ValueError:
        raise ValueError("Định dạng thời gian không hợp lệ. Sử dụng HH:MM:SS hoặc số giây")

def main():
    # Nhập thông tin từ người dùng
    print("Chương trình cắt video thành 2 phần")
    video_path = input("Nhập đường dẫn đến file video: ").strip()
    split_time = input("Nhập thời gian cắt (HH:MM:SS hoặc số giây): ").strip()

    # Gọi hàm cắt video
    split_video(video_path, split_time)

if __name__ == "__main__":
    main()
```
## 📄 File: `Tonghop.py`
**Đường dẫn:** `/Users/annhu/vtrack_app/V_Track/docs/Tien ich/Tonghop.py`

```python
import os
from datetime import datetime

# Lấy thư mục chứa script (thư mục gốc)
input_folder = os.path.dirname(os.path.abspath(__file__))

# Tạo tên file đầu ra với ngày giờ (dd:hh)
current_time = datetime.now().strftime("%m_%d_%H")
output_file = os.path.join(input_folder, f"Vtrack_{current_time}.txt")
# Danh sách phần mở rộng file cần tìm
extensions = (".py", ".js")

# Thư mục cần loại trừ
exclude_dirs = {"node_modules", "dist", "build", "__pycache__"}

# Tên script hiện tại để loại trừ
script_name = os.path.basename(__file__)

# Biến đếm số lượng file
py_count = 0
js_count = 0

# Danh sách để lưu nội dung
content = []

# Duyệt qua tất cả file trong thư mục và thư mục con
for root, dirs, files in os.walk(input_folder):
    # Loại trừ thư mục không mong muốn
    if any(exclude_dir in root.split(os.sep) for exclude_dir in exclude_dirs):
        continue
    for file in files:
        if file.endswith(extensions) and file != script_name:
            file_path = os.path.join(root, file)
            if file.endswith(".py"):
                py_count += 1
            elif file.endswith(".js"):
                js_count += 1
            content.append(f"\n{'='*50}\n")
            content.append(f"Đường dẫn: {file_path}\n")
            content.append(f"Tên file: {file}\n")
            content.append(f"{'='*50}\n\n")
            try:
                with open(file_path, "r", encoding="utf-8") as infile:
                    content.append(infile.read())
                    content.append("\n")
            except Exception as e:
                content.append(f"Lỗi khi đọc {file_path}: {str(e)}\n")

# Ghi tất cả vào file đầu ra
with open(output_file, "w", encoding="utf-8") as outfile:
    outfile.write(f"Tổng kết: {py_count} file .py, {js_count} file .js\n")
    outfile.write(f"{'-'*50}\n\n")
    outfile.writelines(content)

print(f"Đã lưu vào {output_file}")
```